import { useState, useRef, useEffect } from "react";

// ─── THEME ────────────────────────────────────────────────────────────────────
const T = {
  navy: "#0d1b2a", navyLight: "#1b2d42", accent: "#e05c2a",
  gold: "#f5a623", teal: "#0f9b8e", green: "#10b981", red: "#ef4444",
  blue: "#3b82f6", soft: "#f4f1ec", card: "#ffffff",
  border: "#e5e7eb", muted: "#6b7280", text: "#1a1a2a",
};

// ─── STORAGE HELPERS ─────────────────────────────────────────────────────────
const useStore = (key, init) => {
  const [val, setVal] = useState(() => {
    try { const s = localStorage.getItem(key); return s ? JSON.parse(s) : init; } catch { return init; }
  });
  const update = (v) => {
    const next = typeof v === "function" ? v(val) : v;
    setVal(next);
    try { localStorage.setItem(key, JSON.stringify(next)); } catch {}
  };
  return [val, update];
};

// ─── CONSTANTS ───────────────────────────────────────────────────────────────
const BRANCHES = ["CSE", "ISE", "EC", "AIML"];
const YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year"];
const SEMS = { "1st Year": ["Sem 1", "Sem 2"], "2nd Year": ["Sem 3", "Sem 4"], "3rd Year": ["Sem 5", "Sem 6"], "4th Year": ["Sem 7", "Sem 8"] };
const SUBJECTS = {
  CSE: { "Sem 1": ["Engineering Mathematics-I","Engineering Physics","Engineering Chemistry","Engineering Graphics","Basic Electronics"],
         "Sem 2": ["Engineering Mathematics-II","Data Structures","Computer Organization","Programming in C","Environmental Science"],
         "Sem 3": ["Discrete Mathematics","OOP with Java","Digital Electronics","Computer Architecture","Database Management"],
         "Sem 4": ["Design & Analysis of Algorithms","Operating Systems","Microprocessors","Software Engineering","Computer Networks"],
         "Sem 5": ["Automata Theory","System Software","Computer Graphics","Web Technologies","Elective-I"],
         "Sem 6": ["Compiler Design","Artificial Intelligence","Cloud Computing","Information Security","Elective-II"],
         "Sem 7": ["Machine Learning","Big Data Analytics","Mobile Computing","Project Work","Elective-III"],
         "Sem 8": ["Deep Learning","Internet of Things","Blockchain Technology","Major Project","Elective-IV"] },
  ISE: { "Sem 1": ["Engineering Mathematics-I","Engineering Physics","Programming Fundamentals","Engineering Graphics","Basic Electronics"],
         "Sem 2": ["Engineering Mathematics-II","Data Structures","Digital Logic Design","Programming in C++","Environmental Science"],
         "Sem 3": ["Discrete Mathematics","OOP with Java","System Analysis & Design","Database Management","Computer Networks-I"],
         "Sem 4": ["DAA","Operating Systems","Software Engineering","Computer Networks-II","Information Theory"],
         "Sem 5": ["Software Testing","Network Security","Web Programming","Data Warehousing","Elective-I"],
         "Sem 6": ["Enterprise Computing","Information Retrieval","Service Oriented Architecture","Software Project Management","Elective-II"],
         "Sem 7": ["Machine Learning","Knowledge Management","Mobile Application Development","Project Work","Elective-III"],
         "Sem 8": ["AI & Expert Systems","Big Data","Cyber Security","Major Project","Elective-IV"] },
  EC: { "Sem 1": ["Engineering Mathematics-I","Engineering Physics","Basic Electronics","Engineering Graphics","Workshop"],
        "Sem 2": ["Engineering Mathematics-II","Circuit Theory","Electronic Devices","Network Analysis","Environmental Science"],
        "Sem 3": ["Engineering Mathematics-III","Analog Electronics","Digital Circuits","Signals & Systems","Field Theory"],
        "Sem 4": ["Linear ICs","Microcontrollers","Digital Signal Processing","Communication Theory","VLSI Design"],
        "Sem 5": ["Antenna & Wave Propagation","Embedded Systems","Digital Communication","Control Systems","Elective-I"],
        "Sem 6": ["Wireless Communication","MEMS","Optical Fiber Communication","RF & Microwave","Elective-II"],
        "Sem 7": ["Advanced Communication","IoT","Image Processing","Project Work","Elective-III"],
        "Sem 8": ["5G Networks","Radar Systems","Satellite Communication","Major Project","Elective-IV"] },
  AIML: { "Sem 1": ["Engineering Mathematics-I","Engineering Physics","Programming Fundamentals","Engineering Graphics","Basic Electronics"],
           "Sem 2": ["Engineering Mathematics-II","Data Structures","Statistics & Probability","Python Programming","Environmental Science"],
           "Sem 3": ["Linear Algebra","OOP Concepts","Database Management","Data Science Fundamentals","Computer Networks"],
           "Sem 4": ["Machine Learning Basics","Computer Vision Intro","Natural Language Processing","Big Data Analytics","Software Engineering"],
           "Sem 5": ["Deep Learning","Reinforcement Learning","AI Ethics","Data Visualization","Elective-I"],
           "Sem 6": ["Neural Networks","Robot Process Automation","Time Series Analysis","Cloud AI Services","Elective-II"],
           "Sem 7": ["Advanced ML","Generative AI","MLOps","Project Work","Elective-III"],
           "Sem 8": ["AI Applications","Edge AI","Research Methodology","Major Project","Elective-IV"] },
};
const BRANCH_COLORS = { CSE: T.blue, ISE: T.teal, EC: T.gold, AIML: T.accent };
const BRANCH_ICONS = { CSE: "💻", ISE: "🔒", EC: "📡", AIML: "🤖" };

// ─── SMALL UI ─────────────────────────────────────────────────────────────────
const Avatar = ({ initials, size = 36, color = T.accent }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", background: color + "20", border: `2px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 800, fontSize: size * 0.32, color, flexShrink: 0, fontFamily: "Georgia,serif" }}>{initials}</div>
);

const Badge = ({ text, color = T.blue }) => (
  <span style={{ background: color + "20", color, padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>{text}</span>
);

const Inp = ({ label, ...p }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
    {label && <label style={{ fontSize: 12, fontWeight: 700, color: T.muted, letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</label>}
    <input style={{ padding: "10px 14px", borderRadius: 10, border: `1.5px solid ${T.border}`, fontSize: 14, fontFamily: "inherit", outline: "none", background: "#fff" }} {...p} />
  </div>
);

const Sel = ({ label, children, ...p }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
    {label && <label style={{ fontSize: 12, fontWeight: 700, color: T.muted, letterSpacing: 0.5, textTransform: "uppercase" }}>{label}</label>}
    <select style={{ padding: "10px 14px", borderRadius: 10, border: `1.5px solid ${T.border}`, fontSize: 14, fontFamily: "inherit", outline: "none", background: "#fff" }} {...p}>{children}</select>
  </div>
);

const Btn = ({ children, variant = "primary", ...p }) => {
  const styles = {
    primary: { background: T.accent, color: "#fff", border: "none" },
    secondary: { background: T.soft, color: T.text, border: `1.5px solid ${T.border}` },
    danger: { background: T.red, color: "#fff", border: "none" },
    success: { background: T.green, color: "#fff", border: "none" },
    navy: { background: T.navy, color: "#fff", border: "none" },
  };
  return <button style={{ padding: "10px 20px", borderRadius: 10, cursor: "pointer", fontSize: 14, fontWeight: 700, fontFamily: "inherit", ...styles[variant] }} {...p}>{children}</button>;
};

const Card = ({ children, style }) => (
  <div style={{ background: T.card, borderRadius: 16, padding: 20, border: `1px solid ${T.border}`, ...style }}>{children}</div>
);

const STitle = ({ children, small }) => (
  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: small ? 12 : 18 }}>
    <div style={{ width: 4, height: small ? 18 : 22, borderRadius: 2, background: T.accent }} />
    <h2 style={{ margin: 0, fontSize: small ? 15 : 18, fontWeight: 800, color: T.text, fontFamily: "Georgia,serif" }}>{children}</h2>
  </div>
);

// ─── LOGIN / REGISTER ─────────────────────────────────────────────────────────
function AuthScreen({ onLogin }) {
  const [mode, setMode] = useState("login"); // login | register | faculty-register
  const [role, setRole] = useState("student");
  const [form, setForm] = useState({});
  const [err, setErr] = useState("");

  const f = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const handleLogin = () => {
    if (form.username === "admin" && form.password === "admin123") { onLogin({ role: "admin", name: "Admin", branch: "ALL" }); return; }
    const users = JSON.parse(localStorage.getItem("gec_users") || "[]");
    const u = users.find(x => x.username === form.username && x.password === form.password);
    if (!u) { setErr("Invalid credentials."); return; }
    if (u.role === "student" && u.status !== "approved") { setErr("Your account is pending admin approval."); return; }
    onLogin(u);
  };

  const handleRegister = () => {
    if (!form.name || !form.username || !form.password || !form.branch) { setErr("Please fill all required fields."); return; }
    const users = JSON.parse(localStorage.getItem("gec_users") || "[]");
    if (users.find(x => x.username === form.username)) { setErr("Username already taken."); return; }
    const newUser = { ...form, role: "student", status: "pending", id: Date.now(), joinedDate: new Date().toLocaleDateString("en-IN") };
    localStorage.setItem("gec_users", JSON.stringify([...users, newUser]));
    setErr(""); setMode("registered");
  };

  const handleFacultyRegister = () => {
    if (!form.name || !form.username || !form.password || !form.branch || !form.subject || !form.designation) { setErr("Please fill all required fields."); return; }
    const users = JSON.parse(localStorage.getItem("gec_users") || "[]");
    if (users.find(x => x.username === form.username)) { setErr("Username already taken."); return; }
    const newUser = { ...form, role: "faculty", status: "pending", id: Date.now(), joinedDate: new Date().toLocaleDateString("en-IN") };
    localStorage.setItem("gec_users", JSON.stringify([...users, newUser]));
    setErr(""); setMode("faculty-registered");
  };

  if (mode === "registered" || mode === "faculty-registered") return (
    <div style={{ minHeight: "100vh", background: T.navy, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <Card style={{ maxWidth: 420, textAlign: "center", padding: 40 }}>
        <div style={{ fontSize: 52, marginBottom: 16 }}>⏳</div>
        <h2 style={{ margin: "0 0 10px", color: T.text, fontFamily: "Georgia,serif" }}>Registration Submitted!</h2>
        <p style={{ color: T.muted, margin: "0 0 20px" }}>Your account is pending admin approval. You'll be notified once approved.</p>
        <Btn onClick={() => { setMode("login"); setForm({}); setErr(""); }}>Back to Login</Btn>
      </Card>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: T.navy, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ width: "100%", maxWidth: 480 }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <div style={{ width: 64, height: 64, borderRadius: 18, background: T.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, margin: "0 auto 14px" }}>🎓</div>
          <h1 style={{ margin: "0 0 4px", color: "#fff", fontSize: 24, fontFamily: "Georgia,serif", fontWeight: 800 }}>GEC Arsikere</h1>
          <p style={{ margin: 0, color: "rgba(255,255,255,0.5)", fontSize: 14 }}>Government Engineering College · Campus Portal</p>
        </div>

        <Card>
          {mode === "login" && (
            <>
              <STitle>Welcome Back 👋</STitle>
              <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
                {["student","faculty"].map(r => (
                  <button key={r} onClick={() => setRole(r)} style={{ flex: 1, padding: "8px", borderRadius: 8, border: `2px solid ${role === r ? T.accent : T.border}`, background: role === r ? T.accent + "15" : "#fff", color: role === r ? T.accent : T.muted, fontWeight: 700, cursor: "pointer", fontSize: 13, textTransform: "capitalize" }}>{r === "student" ? "🎓 Student" : "👩‍🏫 Faculty"}</button>
                ))}
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <Inp label="Username / USN" placeholder="e.g. 4AR22CS001" value={form.username || ""} onChange={e => f("username", e.target.value)} />
                <Inp label="Password" type="password" placeholder="Enter password" value={form.password || ""} onChange={e => f("password", e.target.value)} />
                {err && <p style={{ margin: 0, color: T.red, fontSize: 13 }}>⚠ {err}</p>}
                <Btn onClick={handleLogin} variant="navy">Login →</Btn>
                <p style={{ margin: 0, textAlign: "center", fontSize: 12, color: T.muted }}>Admin login: <strong>admin / admin123</strong></p>
              </div>
              <div style={{ borderTop: `1px solid ${T.border}`, marginTop: 20, paddingTop: 16, display: "flex", gap: 10, justifyContent: "center" }}>
                <button onClick={() => { setMode("register"); setErr(""); setForm({}); }} style={{ background: "none", border: "none", color: T.accent, cursor: "pointer", fontSize: 13, fontWeight: 700 }}>New Student? Register</button>
                <span style={{ color: T.border }}>|</span>
                <button onClick={() => { setMode("faculty-register"); setErr(""); setForm({}); }} style={{ background: "none", border: "none", color: T.teal, cursor: "pointer", fontSize: 13, fontWeight: 700 }}>Faculty Registration</button>
              </div>
            </>
          )}

          {mode === "register" && (
            <>
              <STitle>Student Registration 🎓</STitle>
              <div style={{ display: "grid", gap: 14 }}>
                <Inp label="Full Name *" placeholder="Your full name" value={form.name || ""} onChange={e => f("name", e.target.value)} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Inp label="USN *" placeholder="4AR22CS001" value={form.username || ""} onChange={e => f("username", e.target.value.toUpperCase())} />
                  <Inp label="Password *" type="password" placeholder="Create password" value={form.password || ""} onChange={e => f("password", e.target.value)} />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Sel label="Branch *" value={form.branch || ""} onChange={e => f("branch", e.target.value)}>
                    <option value="">Select Branch</option>
                    {BRANCHES.map(b => <option key={b}>{b}</option>)}
                  </Sel>
                  <Sel label="Year *" value={form.year || ""} onChange={e => { f("year", e.target.value); f("semester", ""); }}>
                    <option value="">Select Year</option>
                    {YEARS.map(y => <option key={y}>{y}</option>)}
                  </Sel>
                </div>
                {form.year && (
                  <Sel label="Current Semester *" value={form.semester || ""} onChange={e => f("semester", e.target.value)}>
                    <option value="">Select Semester</option>
                    {SEMS[form.year]?.map(s => <option key={s}>{s}</option>)}
                  </Sel>
                )}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Inp label="Phone" placeholder="10-digit number" value={form.phone || ""} onChange={e => f("phone", e.target.value)} />
                  <Inp label="Email" type="email" placeholder="you@example.com" value={form.email || ""} onChange={e => f("email", e.target.value)} />
                </div>
                <Inp label="Date of Birth" type="date" value={form.dob || ""} onChange={e => f("dob", e.target.value)} />
                <Inp label="Address" placeholder="City, District, State" value={form.address || ""} onChange={e => f("address", e.target.value)} />
                <Inp label="Parent/Guardian Name" placeholder="Guardian full name" value={form.guardian || ""} onChange={e => f("guardian", e.target.value)} />
                <Inp label="Parent Phone" placeholder="Parent contact number" value={form.parentPhone || ""} onChange={e => f("parentPhone", e.target.value)} />
                {err && <p style={{ margin: 0, color: T.red, fontSize: 13 }}>⚠ {err}</p>}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <Btn variant="secondary" onClick={() => { setMode("login"); setErr(""); }}>← Back</Btn>
                  <Btn onClick={handleRegister}>Submit Registration</Btn>
                </div>
              </div>
            </>
          )}

          {mode === "faculty-register" && (
            <>
              <STitle>Faculty Registration 👩‍🏫</STitle>
              <div style={{ display: "grid", gap: 14 }}>
                <Inp label="Full Name *" placeholder="Dr. / Prof. Your Name" value={form.name || ""} onChange={e => f("name", e.target.value)} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Inp label="Username *" placeholder="e.g. rameshkumar" value={form.username || ""} onChange={e => f("username", e.target.value)} />
                  <Inp label="Password *" type="password" placeholder="Create password" value={form.password || ""} onChange={e => f("password", e.target.value)} />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Sel label="Department *" value={form.branch || ""} onChange={e => f("branch", e.target.value)}>
                    <option value="">Select Dept</option>
                    {BRANCHES.map(b => <option key={b}>{b}</option>)}
                  </Sel>
                  <Sel label="Designation *" value={form.designation || ""} onChange={e => f("designation", e.target.value)}>
                    <option value="">Select</option>
                    {["Professor","Associate Professor","Assistant Professor","HOD","Principal"].map(d => <option key={d}>{d}</option>)}
                  </Sel>
                </div>
                <Inp label="Subject(s) Teaching *" placeholder="e.g. Data Structures, DBMS" value={form.subject || ""} onChange={e => f("subject", e.target.value)} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  <Inp label="Employee ID" placeholder="GEC/CSE/001" value={form.empId || ""} onChange={e => f("empId", e.target.value)} />
                  <Inp label="Phone" placeholder="10-digit number" value={form.phone || ""} onChange={e => f("phone", e.target.value)} />
                </div>
                <Inp label="Email" type="email" placeholder="faculty@gecarsikere.ac.in" value={form.email || ""} onChange={e => f("email", e.target.value)} />
                <Inp label="Qualification" placeholder="M.Tech / Ph.D / M.E" value={form.qualification || ""} onChange={e => f("qualification", e.target.value)} />
                <Inp label="Experience (years)" type="number" placeholder="Years of teaching experience" value={form.experience || ""} onChange={e => f("experience", e.target.value)} />
                {err && <p style={{ margin: 0, color: T.red, fontSize: 13 }}>⚠ {err}</p>}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <Btn variant="secondary" onClick={() => { setMode("login"); setErr(""); }}>← Back</Btn>
                  <Btn onClick={handleFacultyRegister} variant="navy">Submit for Approval</Btn>
                </div>
              </div>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─── ADMIN PANEL ──────────────────────────────────────────────────────────────
function AdminPanel({ onLogout }) {
  const [tab, setTab] = useState("pending");
  const [users, setUsers] = useState(() => JSON.parse(localStorage.getItem("gec_users") || "[]"));
  const [announcements, setAnnouncements] = useStore("gec_announcements", []);
  const [annForm, setAnnForm] = useState({ title: "", body: "", type: "general", branch: "ALL" });

  const refresh = () => setUsers(JSON.parse(localStorage.getItem("gec_users") || "[]"));

  const approve = (id) => {
    const updated = users.map(u => u.id === id ? { ...u, status: "approved" } : u);
    localStorage.setItem("gec_users", JSON.stringify(updated)); refresh();
  };
  const reject = (id) => {
    const updated = users.filter(u => u.id !== id);
    localStorage.setItem("gec_users", JSON.stringify(updated)); refresh();
  };
  const postAnn = () => {
    if (!annForm.title.trim()) return;
    setAnnouncements(p => [{ ...annForm, id: Date.now(), date: new Date().toLocaleDateString("en-IN"), author: "Admin Office", pinned: false }, ...p]);
    setAnnForm({ title: "", body: "", type: "general", branch: "ALL" });
  };

  const pending = users.filter(u => u.status === "pending");
  const approved = users.filter(u => u.status === "approved");
  const byBranch = (b) => approved.filter(u => u.branch === b);

  const ADMIN_TABS = [
    { id: "pending", label: `⏳ Pending (${pending.length})` },
    { id: "students", label: "🎓 Students" },
    { id: "faculty", label: "👩‍🏫 Faculty" },
    { id: "announcements", label: "📢 Announcements" },
    { id: "branches", label: "🏫 Branches" },
  ];

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: T.soft }}>
      {/* Sidebar */}
      <div style={{ width: 220, background: T.navy, display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "22px 16px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: "0 0 2px", color: "#fff", fontWeight: 800, fontSize: 15, fontFamily: "Georgia,serif" }}>GEC Arsikere</p>
          <Badge text="Admin Panel" color={T.accent} />
        </div>
        <nav style={{ flex: 1, padding: "12px 10px" }}>
          {ADMIN_TABS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderRadius: 10, marginBottom: 4, background: tab === t.id ? T.accent : "transparent", border: "none", cursor: "pointer", color: tab === t.id ? "#fff" : "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: 700, textAlign: "left" }}>{t.label}</button>
          ))}
        </nav>
        <div style={{ padding: "14px 16px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <button onClick={onLogout} style={{ width: "100%", padding: "8px", borderRadius: 8, background: "rgba(239,68,68,0.2)", border: "1px solid rgba(239,68,68,0.4)", color: "#fca5a5", cursor: "pointer", fontSize: 13, fontWeight: 700 }}>🚪 Logout</button>
        </div>
      </div>

      <div style={{ flex: 1, padding: 28, overflow: "auto" }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14, marginBottom: 24 }}>
          {BRANCHES.map(b => (
            <Card key={b} style={{ textAlign: "center" }}>
              <span style={{ fontSize: 28 }}>{BRANCH_ICONS[b]}</span>
              <p style={{ margin: "6px 0 2px", fontSize: 22, fontWeight: 800, color: BRANCH_COLORS[b], fontFamily: "Georgia,serif" }}>{byBranch(b).filter(u => u.role === "student").length}</p>
              <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: T.text }}>{b} Students</p>
            </Card>
          ))}
        </div>

        {/* Pending Approvals */}
        {tab === "pending" && (
          <div>
            <STitle>Pending Approvals</STitle>
            {pending.length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No pending registrations 🎉</p></Card> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {pending.map(u => (
                  <Card key={u.id} style={{ display: "flex", alignItems: "center", gap: 16 }}>
                    <Avatar initials={u.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={44} color={u.role === "faculty" ? T.teal : T.accent} />
                    <div style={{ flex: 1 }}>
                      <p style={{ margin: "0 0 2px", fontWeight: 800, fontSize: 15, color: T.text }}>{u.name}</p>
                      <p style={{ margin: "0 0 4px", fontSize: 13, color: T.muted }}>{u.username} · {u.branch} · {u.role === "faculty" ? u.designation : u.year + " " + u.semester}</p>
                      <div style={{ display: "flex", gap: 6 }}>
                        <Badge text={u.role.toUpperCase()} color={u.role === "faculty" ? T.teal : T.blue} />
                        <Badge text="⏳ Pending" color={T.gold} />
                        {u.email && <span style={{ fontSize: 12, color: T.muted }}>{u.email}</span>}
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <Btn variant="success" onClick={() => approve(u.id)}>✓ Approve</Btn>
                      <Btn variant="danger" onClick={() => reject(u.id)}>✗ Reject</Btn>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Students */}
        {tab === "students" && (
          <div>
            <STitle>All Registered Students</STitle>
            {BRANCHES.map(b => {
              const studs = byBranch(b).filter(u => u.role === "student");
              if (!studs.length) return null;
              return (
                <div key={b} style={{ marginBottom: 24 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
                    <span style={{ fontSize: 18 }}>{BRANCH_ICONS[b]}</span>
                    <h3 style={{ margin: 0, fontSize: 16, fontWeight: 800, color: BRANCH_COLORS[b] }}>{b} Branch — {studs.length} Students</h3>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
                    {studs.map(s => (
                      <Card key={s.id} style={{ padding: 16 }}>
                        <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 10 }}>
                          <Avatar initials={s.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={38} color={BRANCH_COLORS[b]} />
                          <div>
                            <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: T.text }}>{s.name}</p>
                            <p style={{ margin: 0, fontSize: 12, color: T.muted }}>{s.username}</p>
                          </div>
                        </div>
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          <Badge text={s.year || "N/A"} color={BRANCH_COLORS[b]} />
                          <Badge text={s.semester || ""} color={T.muted} />
                        </div>
                        {s.phone && <p style={{ margin: "8px 0 0", fontSize: 12, color: T.muted }}>📱 {s.phone}</p>}
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Faculty */}
        {tab === "faculty" && (
          <div>
            <STitle>Faculty Directory</STitle>
            {BRANCHES.map(b => {
              const fac = byBranch(b).filter(u => u.role === "faculty");
              if (!fac.length) return null;
              return (
                <div key={b} style={{ marginBottom: 24 }}>
                  <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 800, color: BRANCH_COLORS[b] }}>{BRANCH_ICONS[b]} {b} Department</h3>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 12 }}>
                    {fac.map(f => (
                      <Card key={f.id} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                        <Avatar initials={f.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={44} color={T.teal} />
                        <div style={{ flex: 1 }}>
                          <p style={{ margin: "0 0 2px", fontWeight: 800, fontSize: 14, color: T.text }}>{f.name}</p>
                          <p style={{ margin: "0 0 6px", fontSize: 12, color: T.muted }}>{f.designation} · {f.qualification || ""}</p>
                          <p style={{ margin: "0 0 6px", fontSize: 12, color: T.teal }}>📚 {f.subject}</p>
                          <div style={{ display: "flex", gap: 6 }}>
                            {f.empId && <Badge text={f.empId} color={T.muted} />}
                            {f.experience && <Badge text={`${f.experience} yrs exp`} color={T.teal} />}
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
            {BRANCHES.every(b => !byBranch(b).filter(u => u.role === "faculty").length) && (
              <Card><p style={{ color: T.muted, textAlign: "center" }}>No faculty registered yet. Share the faculty registration link!</p></Card>
            )}
          </div>
        )}

        {/* Announcements */}
        {tab === "announcements" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20 }}>
            <div>
              <STitle>All Announcements</STitle>
              {announcements.length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No announcements posted yet.</p></Card> : (
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {announcements.map(a => (
                    <Card key={a.id}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                        <div>
                          <p style={{ margin: "0 0 4px", fontWeight: 800, fontSize: 15, color: T.text }}>{a.title}</p>
                          <p style={{ margin: "0 0 8px", fontSize: 13, color: T.muted, lineHeight: 1.6 }}>{a.body}</p>
                          <div style={{ display: "flex", gap: 6 }}>
                            <Badge text={a.type} color={T.teal} />
                            <Badge text={`Branch: ${a.branch}`} color={T.blue} />
                            <span style={{ fontSize: 12, color: T.muted }}>{a.date}</span>
                          </div>
                        </div>
                        <button onClick={() => setAnnouncements(p => p.filter(x => x.id !== a.id))} style={{ background: "none", border: "none", color: T.red, cursor: "pointer", fontSize: 18 }}>🗑</button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
            <div>
              <STitle small>Post Announcement</STitle>
              <Card>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  <Inp label="Title *" placeholder="Announcement title" value={annForm.title} onChange={e => setAnnForm(p => ({ ...p, title: e.target.value }))} />
                  <div>
                    <label style={{ fontSize: 12, fontWeight: 700, color: T.muted, letterSpacing: 0.5, textTransform: "uppercase" }}>Body</label>
                    <textarea value={annForm.body} onChange={e => setAnnForm(p => ({ ...p, body: e.target.value }))} rows={4} placeholder="Full announcement details..." style={{ width: "100%", padding: "10px 14px", borderRadius: 10, border: `1.5px solid ${T.border}`, fontSize: 14, fontFamily: "inherit", outline: "none", resize: "vertical", boxSizing: "border-box", marginTop: 5 }} />
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                    <Sel label="Type" value={annForm.type} onChange={e => setAnnForm(p => ({ ...p, type: e.target.value }))}>
                      {["general","exam","event","holiday","important"].map(t => <option key={t}>{t}</option>)}
                    </Sel>
                    <Sel label="Branch" value={annForm.branch} onChange={e => setAnnForm(p => ({ ...p, branch: e.target.value }))}>
                      <option value="ALL">All Branches</option>
                      {BRANCHES.map(b => <option key={b}>{b}</option>)}
                    </Sel>
                  </div>
                  <Btn onClick={postAnn}>📢 Post Announcement</Btn>
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* Branches Overview */}
        {tab === "branches" && (
          <div>
            <STitle>Branch Overview</STitle>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 20 }}>
              {BRANCHES.map(b => {
                const studs = byBranch(b).filter(u => u.role === "student");
                const facs = byBranch(b).filter(u => u.role === "faculty");
                return (
                  <Card key={b}>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                      <div style={{ width: 48, height: 48, borderRadius: 14, background: BRANCH_COLORS[b] + "20", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24 }}>{BRANCH_ICONS[b]}</div>
                      <div>
                        <h3 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: BRANCH_COLORS[b], fontFamily: "Georgia,serif" }}>{b}</h3>
                        <p style={{ margin: 0, fontSize: 13, color: T.muted }}>
                          {{ CSE: "Computer Science & Engineering", ISE: "Information Science & Engineering", EC: "Electronics & Communication", AIML: "Artificial Intelligence & Machine Learning" }[b]}
                        </p>
                      </div>
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 8 }}>
                      {YEARS.map(y => {
                        const cnt = studs.filter(s => s.year === y).length;
                        return (
                          <div key={y} style={{ textAlign: "center", padding: 10, borderRadius: 10, background: T.soft }}>
                            <p style={{ margin: "0 0 2px", fontWeight: 800, fontSize: 18, color: BRANCH_COLORS[b] }}>{cnt}</p>
                            <p style={{ margin: 0, fontSize: 11, color: T.muted }}>{y.replace(" Year","")}</p>
                          </div>
                        );
                      })}
                    </div>
                    <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
                      <Badge text={`${studs.length} Students`} color={BRANCH_COLORS[b]} />
                      <Badge text={`${facs.length} Faculty`} color={T.teal} />
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── STUDENT DASHBOARD ────────────────────────────────────────────────────────
function StudentDashboard({ user, onLogout }) {
  const [tab, setTab] = useState("home");
  const [announcements] = useStore("gec_announcements", []);
  const [assignments, setAssignments] = useStore("gec_assignments", [
    { id: 1, title: "Lab Cycle Record", subject: "Data Structures", branch: "CSE", semester: "Sem 3", due: "2026-06-10", status: "pending" },
    { id: 2, title: "DBMS Mini Project", subject: "Database Management", branch: "CSE", semester: "Sem 3", due: "2026-06-15", status: "pending" },
    { id: 3, title: "Network Diagram", subject: "Computer Networks", branch: "CSE", semester: "Sem 4", due: "2026-06-08", status: "overdue" },
  ]);
  const [attendance, setAttendance] = useStore("gec_attendance_" + user.username, {});
  const [marks, setMarks] = useStore("gec_marks_" + user.username, {});
  const [markEntry, setMarkEntry] = useState({});
  const [attEntry, setAttEntry] = useState({ subject: "", date: "", status: "present" });
  const [chatMsgs, setChatMsgs] = useStore("gec_chat_" + user.branch + "_" + user.username, []);
  const [groupMsgs, setGroupMsgs] = useStore("gec_group_" + user.branch + "_" + (user.semester || "Sem 1"), []);
  const [chatText, setChatText] = useState("");
  const [groupText, setGroupText] = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const chatBottom = useRef(null);
  const groupBottom = useRef(null);

  useEffect(() => { chatBottom.current?.scrollIntoView({ behavior: "smooth" }); }, [chatMsgs]);
  useEffect(() => { groupBottom.current?.scrollIntoView({ behavior: "smooth" }); }, [groupMsgs]);

  const mySubjects = (SUBJECTS[user.branch] || {})[user.semester] || [];
  const myAnn = announcements.filter(a => a.branch === "ALL" || a.branch === user.branch);
  const myAssign = assignments.filter(a => a.branch === user.branch && a.semester === user.semester);

  const addAttendance = () => {
    if (!attEntry.subject || !attEntry.date) return;
    setAttendance(p => ({ ...p, [attEntry.date + "_" + attEntry.subject]: attEntry }));
    setAttEntry({ subject: "", date: "", status: "present" });
  };

  const attRecords = Object.values(attendance);
  const presentCount = attRecords.filter(r => r.status === "present").length;
  const attPct = attRecords.length ? Math.round((presentCount / attRecords.length) * 100) : 0;

  const saveMarks = () => {
    setMarks(p => ({ ...p, ...markEntry }));
    setMarkEntry({});
  };

  const sendChat = async () => {
    if (!chatText.trim()) return;
    const msg = { from: "student", text: chatText, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) };
    const newMsgs = [...chatMsgs, msg];
    setChatMsgs(newMsgs);
    setChatText("");
    setChatLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 1000,
          system: `You are a helpful, experienced faculty member at GEC Arsikere (Government Engineering College, Arsikere, Karnataka). The student talking to you is ${user.name} from ${user.branch} branch, ${user.year}, ${user.semester}. Answer their academic questions in a warm, encouraging, and knowledgeable way. Keep responses concise. Address them by first name.`,
          messages: newMsgs.map(m => ({ role: m.from === "student" ? "user" : "assistant", content: m.text }))
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "I'll get back to you soon!";
      setChatMsgs(p => [...p, { from: "faculty", text: reply, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }]);
    } catch { setChatMsgs(p => [...p, { from: "faculty", text: "Sorry, connectivity issue. Please try again!", time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }]); }
    setChatLoading(false);
  };

  const sendGroup = async () => {
    if (!groupText.trim()) return;
    const msg = { sender: user.name, avatar: user.name.split(" ").map(x => x[0]).join("").slice(0,2), role: "student", text: groupText, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), file: null };
    const newMsgs = [...groupMsgs, msg];
    setGroupMsgs(newMsgs);
    setGroupText("");
  };

  const NAV_ITEMS = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "profile", label: "My Profile", icon: "👤" },
    { id: "attendance", label: "Attendance", icon: "📅" },
    { id: "academics", label: "Academics", icon: "📊" },
    { id: "assignments", label: "Assignments", icon: "📝" },
    { id: "announcements", label: "Announcements", icon: "📢" },
    { id: "chat", label: "Ask Faculty", icon: "💬" },
    { id: "group", label: "Class Group", icon: "👥" },
  ];

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: T.soft }}>
      <div style={{ width: 220, background: T.navy, display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "18px 14px 16px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: "0 0 2px", color: "#fff", fontWeight: 800, fontSize: 14, fontFamily: "Georgia,serif" }}>GEC Arsikere</p>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            <Badge text={user.branch} color={BRANCH_COLORS[user.branch] || T.accent} />
            <Badge text={user.semester || ""} color={T.muted} />
          </div>
        </div>
        <nav style={{ flex: 1, padding: "10px 8px" }}>
          {NAV_ITEMS.map(n => (
            <button key={n.id} onClick={() => setTab(n.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderRadius: 10, marginBottom: 3, background: tab === n.id ? T.accent : "transparent", border: "none", cursor: "pointer", color: tab === n.id ? "#fff" : "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: 700, textAlign: "left" }}>{n.icon} {n.label}</button>
          ))}
        </nav>
        <div style={{ padding: "12px 14px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}>
            <Avatar initials={user.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={30} color={BRANCH_COLORS[user.branch] || T.accent} />
            <div>
              <p style={{ margin: 0, color: "#fff", fontSize: 12, fontWeight: 700 }}>{user.name}</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>{user.username}</p>
            </div>
          </div>
          <button onClick={onLogout} style={{ width: "100%", padding: "7px", borderRadius: 8, background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>🚪 Logout</button>
        </div>
      </div>

      <div style={{ flex: 1, padding: 24, overflow: "auto" }}>
        {/* HOME */}
        {tab === "home" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ background: `linear-gradient(135deg, ${T.navy} 0%, ${T.navyLight} 100%)`, borderRadius: 20, padding: "26px 30px", color: "#fff" }}>
              <p style={{ margin: "0 0 4px", fontSize: 12, opacity: 0.5, letterSpacing: 1, textTransform: "uppercase" }}>Government Engineering College, Arsikere</p>
              <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, fontFamily: "Georgia,serif" }}>Welcome, {user.name.split(" ")[0]}! 👋</h1>
              <p style={{ margin: 0, fontSize: 13, opacity: 0.7 }}>{user.branch} · {user.year} · {user.semester} · USN: {user.username}</p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 14 }}>
              <Card style={{ textAlign: "center" }}>
                <p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: attPct >= 75 ? T.green : T.red, fontFamily: "Georgia,serif" }}>{attPct}%</p>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: T.text }}>Attendance</p>
                <p style={{ margin: "2px 0 0", fontSize: 11, color: T.muted }}>{presentCount}/{attRecords.length} classes</p>
              </Card>
              <Card style={{ textAlign: "center" }}>
                <p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: T.blue, fontFamily: "Georgia,serif" }}>{mySubjects.length}</p>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: T.text }}>Subjects</p>
                <p style={{ margin: "2px 0 0", fontSize: 11, color: T.muted }}>{user.semester}</p>
              </Card>
              <Card style={{ textAlign: "center" }}>
                <p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: T.gold, fontFamily: "Georgia,serif" }}>{myAssign.filter(a => a.status === "pending").length}</p>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: T.text }}>Pending</p>
                <p style={{ margin: "2px 0 0", fontSize: 11, color: T.muted }}>Assignments</p>
              </Card>
              <Card style={{ textAlign: "center" }}>
                <p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: T.accent, fontFamily: "Georgia,serif" }}>{myAnn.length}</p>
                <p style={{ margin: 0, fontSize: 13, fontWeight: 700, color: T.text }}>Notices</p>
                <p style={{ margin: "2px 0 0", fontSize: 11, color: T.muted }}>Announcements</p>
              </Card>
            </div>
            {/* Latest Announcements on home */}
            <Card>
              <STitle small>Latest Notices 📢</STitle>
              {myAnn.slice(0,3).length === 0 ? <p style={{ color: T.muted, fontSize: 13 }}>No announcements yet.</p> : myAnn.slice(0,3).map(a => (
                <div key={a.id} style={{ padding: "10px 12px", borderRadius: 10, background: T.soft, border: `1px solid ${T.border}`, marginBottom: 10 }}>
                  <p style={{ margin: "0 0 2px", fontWeight: 700, fontSize: 14, color: T.text }}>{a.title}</p>
                  <p style={{ margin: "0 0 4px", fontSize: 13, color: T.muted }}>{a.body}</p>
                  <p style={{ margin: 0, fontSize: 11, color: T.muted }}>{a.author} · {a.date}</p>
                </div>
              ))}
            </Card>
          </div>
        )}

        {/* PROFILE */}
        {tab === "profile" && (
          <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20 }}>
            <Card style={{ textAlign: "center" }}>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 14 }}>
                <Avatar initials={user.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={80} color={BRANCH_COLORS[user.branch] || T.accent} />
              </div>
              <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, fontFamily: "Georgia,serif", color: T.text }}>{user.name}</h2>
              <p style={{ margin: "0 0 12px", color: T.muted, fontSize: 13 }}>{user.username}</p>
              <div style={{ display: "flex", justifyContent: "center", gap: 6, flexWrap: "wrap" }}>
                <Badge text={user.branch} color={BRANCH_COLORS[user.branch] || T.accent} />
                <Badge text={user.year} color={T.blue} />
                <Badge text={user.semester} color={T.teal} />
                <Badge text="✅ Approved" color={T.green} />
              </div>
            </Card>
            <Card>
              <STitle small>Personal Information</STitle>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
                {[["Full Name", user.name], ["USN", user.username], ["Branch", user.branch], ["Year", user.year], ["Semester", user.semester], ["Phone", user.phone || "Not provided"], ["Email", user.email || "Not provided"], ["Date of Birth", user.dob || "Not provided"], ["Address", user.address || "Not provided"], ["Guardian", user.guardian || "Not provided"], ["Guardian Phone", user.parentPhone || "Not provided"], ["Joined", user.joinedDate || "N/A"]].map(([k, v]) => (
                  <div key={k} style={{ padding: "10px 14px", borderRadius: 10, background: T.soft }}>
                    <p style={{ margin: "0 0 2px", fontSize: 11, color: T.muted, fontWeight: 700, textTransform: "uppercase" }}>{k}</p>
                    <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: T.text }}>{v || "—"}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}

        {/* ATTENDANCE */}
        {tab === "attendance" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
            <div>
              <STitle>Attendance Records</STitle>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12, marginBottom: 20 }}>
                <Card style={{ textAlign: "center" }}>
                  <p style={{ margin: "0 0 4px", fontSize: 26, fontWeight: 800, color: attPct >= 75 ? T.green : T.red, fontFamily: "Georgia,serif" }}>{attPct}%</p>
                  <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Overall</p>
                  {attPct < 75 && <p style={{ margin: "4px 0 0", fontSize: 11, color: T.red }}>⚠ Below 75% threshold!</p>}
                </Card>
                <Card style={{ textAlign: "center" }}>
                  <p style={{ margin: "0 0 4px", fontSize: 26, fontWeight: 800, color: T.green, fontFamily: "Georgia,serif" }}>{presentCount}</p>
                  <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Present</p>
                </Card>
                <Card style={{ textAlign: "center" }}>
                  <p style={{ margin: "0 0 4px", fontSize: 26, fontWeight: 800, color: T.red, fontFamily: "Georgia,serif" }}>{attRecords.length - presentCount}</p>
                  <p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Absent</p>
                </Card>
              </div>
              <Card>
                <STitle small>Subject-wise Attendance</STitle>
                {mySubjects.map(subj => {
                  const recs = attRecords.filter(r => r.subject === subj);
                  const pres = recs.filter(r => r.status === "present").length;
                  const pct = recs.length ? Math.round((pres / recs.length) * 100) : 0;
                  return (
                    <div key={subj} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
                      <span style={{ fontSize: 13, flex: 1, fontWeight: 600, color: T.text }}>{subj}</span>
                      <span style={{ fontSize: 12, color: T.muted, minWidth: 60 }}>{pres}/{recs.length} cls</span>
                      <div style={{ width: 120, height: 8, borderRadius: 4, background: T.border }}>
                        <div style={{ width: `${pct}%`, height: "100%", background: pct >= 75 ? T.green : T.red, borderRadius: 4 }} />
                      </div>
                      <span style={{ fontSize: 12, fontWeight: 800, color: pct >= 75 ? T.green : T.red, minWidth: 36 }}>{pct}%</span>
                    </div>
                  );
                })}
                {mySubjects.length === 0 && <p style={{ color: T.muted, fontSize: 13 }}>Subjects load based on your semester selection.</p>}
              </Card>
              {attRecords.length > 0 && (
                <Card style={{ marginTop: 16 }}>
                  <STitle small>All Records</STitle>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: 300, overflowY: "auto" }}>
                    {[...attRecords].reverse().map((r, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 12px", borderRadius: 8, background: r.status === "present" ? T.green + "0d" : T.red + "0d" }}>
                        <span>{r.status === "present" ? "✅" : "❌"}</span>
                        <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: T.text }}>{r.subject}</span>
                        <span style={{ fontSize: 12, color: T.muted }}>{r.date}</span>
                        <Badge text={r.status} color={r.status === "present" ? T.green : T.red} />
                      </div>
                    ))}
                  </div>
                </Card>
              )}
            </div>
            <Card style={{ height: "fit-content" }}>
              <STitle small>Mark Attendance</STitle>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Sel label="Subject" value={attEntry.subject} onChange={e => setAttEntry(p => ({ ...p, subject: e.target.value }))}>
                  <option value="">Select Subject</option>
                  {mySubjects.map(s => <option key={s}>{s}</option>)}
                </Sel>
                <Inp label="Date" type="date" value={attEntry.date} onChange={e => setAttEntry(p => ({ ...p, date: e.target.value }))} />
                <Sel label="Status" value={attEntry.status} onChange={e => setAttEntry(p => ({ ...p, status: e.target.value }))}>
                  <option value="present">✅ Present</option>
                  <option value="absent">❌ Absent</option>
                </Sel>
                <Btn onClick={addAttendance}>Add Record</Btn>
              </div>
            </Card>
          </div>
        )}

        {/* ACADEMICS */}
        {tab === "academics" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 20 }}>
            <div>
              <STitle>Academic Performance</STitle>
              <Card style={{ marginBottom: 16 }}>
                <STitle small>Subject-wise Marks</STitle>
                {mySubjects.length === 0 ? <p style={{ color: T.muted, fontSize: 13 }}>No subjects for this semester.</p> : (
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    {mySubjects.map(subj => {
                      const m = marks[subj];
                      const ia1 = parseFloat(m?.ia1 || 0), ia2 = parseFloat(m?.ia2 || 0), ia3 = parseFloat(m?.ia3 || 0);
                      const avg = m ? Math.round((ia1 + ia2 + ia3) / 3) : null;
                      return (
                        <div key={subj} style={{ padding: "12px 14px", borderRadius: 12, background: T.soft, border: `1px solid ${T.border}` }}>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                            <span style={{ fontWeight: 700, fontSize: 14, color: T.text }}>{subj}</span>
                            {avg !== null && <Badge text={`Avg: ${avg}/100`} color={avg >= 50 ? T.teal : T.red} />}
                          </div>
                          {m ? (
                            <div style={{ display: "flex", gap: 10 }}>
                              {[["IA-1", ia1], ["IA-2", ia2], ["IA-3", ia3]].map(([label, val]) => (
                                <div key={label} style={{ flex: 1, textAlign: "center", padding: "6px", borderRadius: 8, background: "#fff" }}>
                                  <p style={{ margin: "0 0 2px", fontSize: 11, color: T.muted }}>{label}</p>
                                  <p style={{ margin: 0, fontSize: 18, fontWeight: 800, color: val >= 50 ? T.teal : T.red }}>{val}</p>
                                </div>
                              ))}
                            </div>
                          ) : <p style={{ margin: 0, fontSize: 12, color: T.muted }}>Marks not entered yet</p>}
                        </div>
                      );
                    })}
                  </div>
                )}
              </Card>
            </div>
            <Card style={{ height: "fit-content" }}>
              <STitle small>Enter Marks</STitle>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Sel label="Subject" value={markEntry._subj || ""} onChange={e => setMarkEntry(p => ({ ...p, _subj: e.target.value }))}>
                  <option value="">Select Subject</option>
                  {mySubjects.map(s => <option key={s}>{s}</option>)}
                </Sel>
                {markEntry._subj && (
                  <>
                    <Inp label="IA-1 Marks (/100)" type="number" min="0" max="100" placeholder="e.g. 78" value={markEntry[markEntry._subj]?.ia1 || ""} onChange={e => setMarkEntry(p => ({ ...p, [p._subj]: { ...p[p._subj], ia1: e.target.value } }))} />
                    <Inp label="IA-2 Marks (/100)" type="number" min="0" max="100" placeholder="e.g. 82" value={markEntry[markEntry._subj]?.ia2 || ""} onChange={e => setMarkEntry(p => ({ ...p, [p._subj]: { ...p[p._subj], ia2: e.target.value } }))} />
                    <Inp label="IA-3 Marks (/100)" type="number" min="0" max="100" placeholder="e.g. 75" value={markEntry[markEntry._subj]?.ia3 || ""} onChange={e => setMarkEntry(p => ({ ...p, [p._subj]: { ...p[p._subj], ia3: e.target.value } }))} />
                    <Btn onClick={() => { if (!markEntry._subj) return; setMarks(p => ({ ...p, [markEntry._subj]: { ia1: markEntry[markEntry._subj]?.ia1 || 0, ia2: markEntry[markEntry._subj]?.ia2 || 0, ia3: markEntry[markEntry._subj]?.ia3 || 0 } })); setMarkEntry({}); }}>Save Marks</Btn>
                  </>
                )}
              </div>
              <div style={{ marginTop: 20 }}>
                <STitle small>Subjects This Semester</STitle>
                {mySubjects.map((s, i) => <p key={s} style={{ margin: "0 0 6px", fontSize: 13, color: T.text }}>{i + 1}. {s}</p>)}
              </div>
            </Card>
          </div>
        )}

        {/* ASSIGNMENTS */}
        {tab === "assignments" && (
          <div>
            <STitle>Assignments</STitle>
            {myAssign.length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No assignments for your branch/semester yet.</p></Card> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {myAssign.map(a => {
                  const sColor = { pending: T.gold, overdue: T.red, completed: T.green, upcoming: T.blue }[a.status];
                  return (
                    <Card key={a.id} style={{ display: "flex", gap: 16, alignItems: "center" }}>
                      <div style={{ width: 52, height: 52, borderRadius: 14, background: sColor + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, flexShrink: 0 }}>
                        {{ pending: "🟡", overdue: "🔴", completed: "✅", upcoming: "🔵" }[a.status]}
                      </div>
                      <div style={{ flex: 1 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 4 }}>
                          <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: T.text }}>{a.title}</h3>
                          <Badge text={a.status} color={sColor} />
                        </div>
                        <p style={{ margin: 0, fontSize: 13, color: T.muted }}>{a.subject} · Due: {a.due}</p>
                      </div>
                      {a.status !== "completed" && (
                        <Btn variant="success" onClick={() => setAssignments(p => p.map(x => x.id === a.id ? { ...x, status: "completed" } : x))}>Mark Submitted</Btn>
                      )}
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ANNOUNCEMENTS */}
        {tab === "announcements" && (
          <div>
            <STitle>Announcements & Notices</STitle>
            {myAnn.length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No announcements yet. Check back soon!</p></Card> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {myAnn.map(a => {
                  const typeIcon = { exam: "📝", event: "🎉", general: "📣", holiday: "🏖", important: "🚨" };
                  return (
                    <Card key={a.id}>
                      <div style={{ display: "flex", gap: 14 }}>
                        <span style={{ fontSize: 30 }}>{typeIcon[a.type] || "📣"}</span>
                        <div style={{ flex: 1 }}>
                          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 800, color: T.text }}>{a.title}</h3>
                            <Badge text={a.type} color={T.teal} />
                            {a.branch !== "ALL" && <Badge text={a.branch} color={BRANCH_COLORS[a.branch] || T.blue} />}
                          </div>
                          <p style={{ margin: "0 0 8px", fontSize: 13, color: T.text, lineHeight: 1.6 }}>{a.body}</p>
                          <p style={{ margin: 0, fontSize: 12, color: T.muted }}>Posted by <strong>{a.author}</strong> · {a.date}</p>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* CHAT WITH FACULTY */}
        {tab === "chat" && (
          <div>
            <STitle>Ask Faculty (AI-Powered) 💬</STitle>
            <Card style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "14px 18px", borderBottom: `1px solid ${T.border}`, background: T.navy, display: "flex", gap: 10, alignItems: "center" }}>
                <Avatar initials="GF" size={38} color={T.teal} />
                <div>
                  <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#fff" }}>GEC Faculty Assistant</p>
                  <p style={{ margin: 0, fontSize: 12, color: T.green }}>● Always here to help you</p>
                </div>
              </div>
              <div style={{ height: 380, overflowY: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: 10, background: "#f8fafc" }}>
                {chatMsgs.length === 0 && (
                  <div style={{ textAlign: "center", padding: 40, color: T.muted }}>
                    <p style={{ fontSize: 36, margin: "0 0 10px" }}>💬</p>
                    <p style={{ fontSize: 14, fontWeight: 600 }}>Ask your faculty anything!</p>
                    <p style={{ fontSize: 13 }}>Doubt about a subject? Need assignment help? Just type!</p>
                  </div>
                )}
                {chatMsgs.map((m, i) => (
                  <div key={i} style={{ display: "flex", justifyContent: m.from === "student" ? "flex-end" : "flex-start", gap: 8, alignItems: "flex-end" }}>
                    {m.from === "faculty" && <Avatar initials="GF" size={28} color={T.teal} />}
                    <div style={{ maxWidth: "70%" }}>
                      <div style={{ background: m.from === "student" ? T.accent : T.card, color: m.from === "student" ? "#fff" : T.text, padding: "10px 14px", borderRadius: m.from === "student" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", fontSize: 14, lineHeight: 1.5, border: m.from === "student" ? "none" : `1px solid ${T.border}` }}>
                        {m.text}
                      </div>
                      <p style={{ margin: "3px 4px 0", fontSize: 11, color: T.muted, textAlign: m.from === "student" ? "right" : "left" }}>{m.time}</p>
                    </div>
                    {m.from === "student" && <Avatar initials={user.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={28} color={BRANCH_COLORS[user.branch] || T.accent} />}
                  </div>
                ))}
                {chatLoading && <div style={{ display: "flex", gap: 8 }}><Avatar initials="GF" size={28} color={T.teal} /><div style={{ background: T.card, padding: "10px 14px", borderRadius: "18px 18px 18px 4px", border: `1px solid ${T.border}`, color: T.muted, fontSize: 13 }}>typing...</div></div>}
                <div ref={chatBottom} />
              </div>
              <div style={{ padding: "12px 14px", borderTop: `1px solid ${T.border}`, display: "flex", gap: 10 }}>
                <input value={chatText} onChange={e => setChatText(e.target.value)} onKeyDown={e => e.key === "Enter" && sendChat()} placeholder="Ask a question to your faculty..." style={{ flex: 1, padding: "10px 14px", borderRadius: 24, border: `1px solid ${T.border}`, fontSize: 14, fontFamily: "inherit", outline: "none" }} />
                <Btn onClick={sendChat} variant="navy">Send →</Btn>
              </div>
            </Card>
          </div>
        )}

        {/* CLASS GROUP */}
        {tab === "group" && (
          <div>
            <STitle>Class Group — {user.branch} {user.semester} 👥</STitle>
            <Card style={{ padding: 0, overflow: "hidden" }}>
              <div style={{ padding: "12px 18px", borderBottom: `1px solid ${T.border}`, background: T.navyLight, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: "#fff" }}>📚 {user.branch} · {user.semester} Group</p>
                  <p style={{ margin: 0, fontSize: 12, color: "rgba(255,255,255,0.5)" }}>Share notes, PDFs, questions with your class</p>
                </div>
                <Badge text="Class Group" color={BRANCH_COLORS[user.branch] || T.accent} />
              </div>
              <div style={{ height: 360, overflowY: "auto", padding: "14px 18px", display: "flex", flexDirection: "column", gap: 12, background: "#f8fafc" }}>
                {groupMsgs.length === 0 && (
                  <div style={{ textAlign: "center", padding: 40, color: T.muted }}>
                    <p style={{ fontSize: 36, margin: "0 0 10px" }}>👥</p>
                    <p style={{ fontSize: 14, fontWeight: 600 }}>Group chat is empty</p>
                    <p style={{ fontSize: 13 }}>Be the first to share notes or ask a question!</p>
                  </div>
                )}
                {groupMsgs.map((m, i) => (
                  <div key={i} style={{ display: "flex", gap: 10 }}>
                    <Avatar initials={m.avatar} size={34} color={m.sender === user.name ? BRANCH_COLORS[user.branch] || T.accent : T.teal} />
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 3 }}>
                        <span style={{ fontSize: 13, fontWeight: 700, color: T.text }}>{m.sender}</span>
                        <span style={{ fontSize: 11, color: T.muted }}>{m.time}</span>
                      </div>
                      {m.text && <p style={{ margin: "0 0 6px", fontSize: 14, color: T.text, lineHeight: 1.5 }}>{m.text}</p>}
                      {m.file && (
                        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "8px 12px", borderRadius: 10, background: T.blue + "15", border: `1px solid ${T.blue + "33"}` }}>
                          <span>📄</span>
                          <div>
                            <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: T.blue }}>{m.file.name}</p>
                            <p style={{ margin: 0, fontSize: 11, color: T.muted }}>{m.file.size}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                <div ref={groupBottom} />
              </div>
              <div style={{ padding: "12px 14px", borderTop: `1px solid ${T.border}`, display: "flex", gap: 10 }}>
                <input value={groupText} onChange={e => setGroupText(e.target.value)} onKeyDown={e => e.key === "Enter" && sendGroup()} placeholder={`Message ${user.branch} ${user.semester} group...`} style={{ flex: 1, padding: "10px 14px", borderRadius: 24, border: `1px solid ${T.border}`, fontSize: 14, fontFamily: "inherit", outline: "none" }} />
                <Btn onClick={sendGroup} variant="navy">Send →</Btn>
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── FACULTY DASHBOARD ────────────────────────────────────────────────────────
function FacultyDashboard({ user, onLogout }) {
  const [tab, setTab] = useState("home");
  const [announcements] = useStore("gec_announcements", []);
  const [assignments, setAssignments] = useStore("gec_assignments", []);
  const [newAssign, setNewAssign] = useState({ title: "", subject: "", branch: user.branch, semester: "Sem 1", due: "", status: "pending" });

  const allStudents = JSON.parse(localStorage.getItem("gec_users") || "[]").filter(u => u.role === "student" && u.status === "approved" && u.branch === user.branch);
  const myAnn = announcements.filter(a => a.branch === "ALL" || a.branch === user.branch);

  const addAssignment = () => {
    if (!newAssign.title || !newAssign.subject || !newAssign.due) return;
    setAssignments(p => [{ ...newAssign, id: Date.now() }, ...p]);
    setNewAssign({ title: "", subject: "", branch: user.branch, semester: "Sem 1", due: "", status: "pending" });
  };

  const NAV = [
    { id: "home", label: "Home", icon: "🏠" },
    { id: "profile", label: "My Profile", icon: "👤" },
    { id: "students", label: "My Students", icon: "🎓" },
    { id: "assignments", label: "Assignments", icon: "📝" },
    { id: "announcements", label: "Notices", icon: "📢" },
  ];

  return (
    <div style={{ minHeight: "100vh", display: "flex", background: T.soft }}>
      <div style={{ width: 220, background: T.navy, display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "18px 14px 16px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: "0 0 2px", color: "#fff", fontWeight: 800, fontSize: 14, fontFamily: "Georgia,serif" }}>GEC Arsikere</p>
          <Badge text="Faculty Portal" color={T.teal} />
        </div>
        <nav style={{ flex: 1, padding: "10px 8px" }}>
          {NAV.map(n => (
            <button key={n.id} onClick={() => setTab(n.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderRadius: 10, marginBottom: 3, background: tab === n.id ? T.teal : "transparent", border: "none", cursor: "pointer", color: tab === n.id ? "#fff" : "rgba(255,255,255,0.6)", fontSize: 13, fontWeight: 700, textAlign: "left" }}>{n.icon} {n.label}</button>
          ))}
        </nav>
        <div style={{ padding: "12px 14px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 10 }}>
            <Avatar initials={user.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={30} color={T.teal} />
            <div>
              <p style={{ margin: 0, color: "#fff", fontSize: 12, fontWeight: 700 }}>{user.name}</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>{user.designation || "Faculty"}</p>
            </div>
          </div>
          <button onClick={onLogout} style={{ width: "100%", padding: "7px", borderRadius: 8, background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", color: "#fca5a5", cursor: "pointer", fontSize: 12, fontWeight: 700 }}>🚪 Logout</button>
        </div>
      </div>

      <div style={{ flex: 1, padding: 24, overflow: "auto" }}>
        {tab === "home" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ background: `linear-gradient(135deg, ${T.navyLight} 0%, ${T.navy} 100%)`, borderRadius: 20, padding: "26px 30px", color: "#fff" }}>
              <p style={{ margin: "0 0 4px", fontSize: 12, opacity: 0.5, textTransform: "uppercase", letterSpacing: 1 }}>Faculty Portal · GEC Arsikere</p>
              <h1 style={{ margin: "0 0 6px", fontSize: 22, fontWeight: 800, fontFamily: "Georgia,serif" }}>Welcome, {user.name}! 👩‍🏫</h1>
              <p style={{ margin: 0, fontSize: 13, opacity: 0.7 }}>{user.designation} · {user.branch} Dept · {user.subject}</p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 14 }}>
              <Card style={{ textAlign: "center" }}><p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: BRANCH_COLORS[user.branch] || T.accent, fontFamily: "Georgia,serif" }}>{allStudents.length}</p><p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Students in {user.branch}</p></Card>
              <Card style={{ textAlign: "center" }}><p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: T.gold, fontFamily: "Georgia,serif" }}>{assignments.filter(a => a.branch === user.branch && a.status === "pending").length}</p><p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Pending Assignments</p></Card>
              <Card style={{ textAlign: "center" }}><p style={{ margin: "0 0 4px", fontSize: 28, fontWeight: 800, color: T.teal, fontFamily: "Georgia,serif" }}>{myAnn.length}</p><p style={{ margin: 0, fontSize: 13, fontWeight: 700 }}>Announcements</p></Card>
            </div>
            <Card>
              <STitle small>My Students — {user.branch}</STitle>
              {allStudents.length === 0 ? <p style={{ color: T.muted, fontSize: 13 }}>No students registered yet in your branch.</p> : (
                <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 10 }}>
                  {allStudents.map(s => (
                    <div key={s.id} style={{ padding: "10px 12px", borderRadius: 10, background: T.soft, border: `1px solid ${T.border}` }}>
                      <Avatar initials={s.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={32} color={BRANCH_COLORS[user.branch] || T.accent} />
                      <p style={{ margin: "6px 0 2px", fontSize: 13, fontWeight: 700, color: T.text }}>{s.name}</p>
                      <p style={{ margin: 0, fontSize: 11, color: T.muted }}>{s.username} · {s.year}</p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        )}

        {tab === "profile" && (
          <div>
            <STitle>Faculty Profile</STitle>
            <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 20 }}>
              <Card style={{ textAlign: "center" }}>
                <div style={{ display: "flex", justifyContent: "center", marginBottom: 14 }}>
                  <Avatar initials={user.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={70} color={T.teal} />
                </div>
                <h2 style={{ margin: "0 0 4px", fontFamily: "Georgia,serif", fontSize: 18, color: T.text }}>{user.name}</h2>
                <p style={{ margin: "0 0 10px", color: T.muted, fontSize: 13 }}>{user.designation}</p>
                <Badge text={user.branch + " Dept"} color={BRANCH_COLORS[user.branch] || T.teal} />
              </Card>
              <Card>
                <STitle small>Professional Details</STitle>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                  {[["Name", user.name], ["Employee ID", user.empId || "N/A"], ["Department", user.branch], ["Designation", user.designation || "N/A"], ["Subjects", user.subject || "N/A"], ["Qualification", user.qualification || "N/A"], ["Experience", user.experience ? user.experience + " years" : "N/A"], ["Phone", user.phone || "N/A"], ["Email", user.email || "N/A"], ["Joined", user.joinedDate || "N/A"]].map(([k, v]) => (
                    <div key={k} style={{ padding: "10px 14px", borderRadius: 10, background: T.soft }}>
                      <p style={{ margin: "0 0 2px", fontSize: 11, color: T.muted, fontWeight: 700, textTransform: "uppercase" }}>{k}</p>
                      <p style={{ margin: 0, fontSize: 14, fontWeight: 600, color: T.text }}>{v}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        )}

        {tab === "students" && (
          <div>
            <STitle>Students in {user.branch} Department</STitle>
            {YEARS.map(y => {
              const stu = allStudents.filter(s => s.year === y);
              if (!stu.length) return null;
              return (
                <div key={y} style={{ marginBottom: 22 }}>
                  <h3 style={{ margin: "0 0 12px", fontSize: 16, fontWeight: 800, color: T.text }}>{y} — {stu.length} students</h3>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 12 }}>
                    {stu.map(s => (
                      <Card key={s.id} style={{ padding: 16 }}>
                        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                          <Avatar initials={s.name.split(" ").map(x => x[0]).join("").slice(0,2)} size={38} color={BRANCH_COLORS[user.branch] || T.accent} />
                          <div>
                            <p style={{ margin: 0, fontWeight: 700, fontSize: 14, color: T.text }}>{s.name}</p>
                            <p style={{ margin: 0, fontSize: 12, color: T.muted }}>{s.username} · {s.semester}</p>
                            {s.phone && <p style={{ margin: "2px 0 0", fontSize: 12, color: T.muted }}>📱 {s.phone}</p>}
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
            {allStudents.length === 0 && <Card><p style={{ color: T.muted, textAlign: "center" }}>No approved students in your branch yet.</p></Card>}
          </div>
        )}

        {tab === "assignments" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 20 }}>
            <div>
              <STitle>Assignments</STitle>
              {assignments.filter(a => a.branch === user.branch).length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No assignments created yet.</p></Card> : (
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {assignments.filter(a => a.branch === user.branch).map(a => (
                    <Card key={a.id} style={{ display: "flex", gap: 14, alignItems: "center" }}>
                      <div style={{ flex: 1 }}>
                        <p style={{ margin: "0 0 2px", fontWeight: 700, fontSize: 15, color: T.text }}>{a.title}</p>
                        <p style={{ margin: "0 0 6px", fontSize: 13, color: T.muted }}>{a.subject} · {a.semester} · Due: {a.due}</p>
                        <Badge text={a.status} color={{ pending: T.gold, overdue: T.red, completed: T.green, upcoming: T.blue }[a.status]} />
                      </div>
                      <button onClick={() => setAssignments(p => p.filter(x => x.id !== a.id))} style={{ background: "none", border: "none", color: T.red, cursor: "pointer", fontSize: 18 }}>🗑</button>
                    </Card>
                  ))}
                </div>
              )}
            </div>
            <Card style={{ height: "fit-content" }}>
              <STitle small>Create Assignment</STitle>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Inp label="Title *" placeholder="Assignment title" value={newAssign.title} onChange={e => setNewAssign(p => ({ ...p, title: e.target.value }))} />
                <Inp label="Subject *" placeholder="Subject name" value={newAssign.subject} onChange={e => setNewAssign(p => ({ ...p, subject: e.target.value }))} />
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
                  <Sel label="Branch" value={newAssign.branch} onChange={e => setNewAssign(p => ({ ...p, branch: e.target.value }))}>
                    {BRANCHES.map(b => <option key={b}>{b}</option>)}
                  </Sel>
                  <Sel label="Semester" value={newAssign.semester} onChange={e => setNewAssign(p => ({ ...p, semester: e.target.value }))}>
                    {Object.values(SEMS).flat().map(s => <option key={s}>{s}</option>)}
                  </Sel>
                </div>
                <Inp label="Due Date *" type="date" value={newAssign.due} onChange={e => setNewAssign(p => ({ ...p, due: e.target.value }))} />
                <Sel label="Status" value={newAssign.status} onChange={e => setNewAssign(p => ({ ...p, status: e.target.value }))}>
                  <option value="upcoming">Upcoming</option>
                  <option value="pending">Pending</option>
                  <option value="overdue">Overdue</option>
                </Sel>
                <Btn onClick={addAssignment}>+ Create Assignment</Btn>
              </div>
            </Card>
          </div>
        )}

        {tab === "announcements" && (
          <div>
            <STitle>Notices & Announcements</STitle>
            {myAnn.length === 0 ? <Card><p style={{ color: T.muted, textAlign: "center" }}>No announcements from admin yet.</p></Card> : (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {myAnn.map(a => (
                  <Card key={a.id}>
                    <p style={{ margin: "0 0 4px", fontWeight: 800, fontSize: 15, color: T.text }}>{a.title}</p>
                    <p style={{ margin: "0 0 8px", fontSize: 13, color: T.muted, lineHeight: 1.6 }}>{a.body}</p>
                    <div style={{ display: "flex", gap: 6 }}>
                      <Badge text={a.type} color={T.teal} />
                      <span style={{ fontSize: 12, color: T.muted }}>{a.author} · {a.date}</span>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [currentUser, setCurrentUser] = useState(null);

  const handleLogin = (user) => setCurrentUser(user);
  const handleLogout = () => setCurrentUser(null);

  if (!currentUser) return <AuthScreen onLogin={handleLogin} />;
  if (currentUser.role === "admin") return <AdminPanel onLogout={handleLogout} />;
  if (currentUser.role === "faculty") return <FacultyDashboard user={currentUser} onLogout={handleLogout} />;
  return <StudentDashboard user={currentUser} onLogout={handleLogout} />;
}
