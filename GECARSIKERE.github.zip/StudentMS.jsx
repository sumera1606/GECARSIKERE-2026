import { useState, useRef, useEffect } from "react";

const COLORS = {
  primary: "#1a1a2e",
  accent: "#e94560",
  warm: "#f5a623",
  teal: "#0f9b8e",
  soft: "#f8f4ef",
  card: "#ffffff",
  muted: "#6b7280",
  border: "#e5e7eb",
  success: "#10b981",
  info: "#3b82f6",
};

const STUDENTS = [
  { id: 1, name: "Priya Sharma", roll: "CS2301", class: "CS-A", avatar: "PS", attendance: 92, cgpa: 8.7, email: "priya@college.edu", phone: "9876543210", dob: "2003-04-12", address: "Bangalore, KA" },
  { id: 2, name: "Arjun Mehta", roll: "CS2302", class: "CS-A", avatar: "AM", attendance: 78, cgpa: 7.4, email: "arjun@college.edu", phone: "9876543211", dob: "2003-07-22", address: "Mumbai, MH" },
  { id: 3, name: "Sneha Reddy", roll: "CS2303", class: "CS-B", avatar: "SR", attendance: 95, cgpa: 9.1, email: "sneha@college.edu", phone: "9876543212", dob: "2003-01-15", address: "Hyderabad, TS" },
  { id: 4, name: "Rahul Gupta", roll: "CS2304", class: "CS-B", avatar: "RG", attendance: 65, cgpa: 6.8, email: "rahul@college.edu", phone: "9876543213", dob: "2002-11-30", address: "Delhi, DL" },
  { id: 5, name: "Kavya Nair", roll: "CS2305", class: "CS-A", avatar: "KN", attendance: 88, cgpa: 8.2, email: "kavya@college.edu", phone: "9876543214", dob: "2003-09-08", address: "Kochi, KL" },
];

const FACULTY = [
  { id: 1, name: "Dr. Ramesh Kumar", subject: "Data Structures", dept: "CS", avatar: "RK", classes: ["CS-A", "CS-B"], email: "ramesh@college.edu" },
  { id: 2, name: "Prof. Anita Singh", subject: "DBMS", dept: "CS", avatar: "AS", classes: ["CS-A"], email: "anita@college.edu" },
  { id: 3, name: "Dr. Vijay Patel", subject: "Computer Networks", dept: "CS", avatar: "VP", classes: ["CS-B"], email: "vijay@college.edu" },
  { id: 4, name: "Ms. Lakshmi Iyer", subject: "Web Development", dept: "CS", avatar: "LI", classes: ["CS-A", "CS-B"], email: "lakshmi@college.edu" },
];

const ASSIGNMENTS = [
  { id: 1, title: "Binary Tree Implementation", subject: "Data Structures", due: "2026-06-10", class: "CS-A", status: "pending", submissions: 18, total: 30 },
  { id: 2, title: "ER Diagram Design", subject: "DBMS", due: "2026-06-08", class: "CS-A", status: "overdue", submissions: 25, total: 30 },
  { id: 3, title: "Network Topology Report", subject: "Computer Networks", due: "2026-06-15", class: "CS-B", status: "pending", submissions: 10, total: 28 },
  { id: 4, title: "React Portfolio Website", subject: "Web Development", due: "2026-06-20", class: "CS-A", status: "upcoming", submissions: 0, total: 30 },
  { id: 5, title: "Sorting Algorithm Analysis", subject: "Data Structures", due: "2026-05-28", class: "CS-B", status: "completed", submissions: 28, total: 28 },
];

const ANNOUNCEMENTS = [
  { id: 1, title: "Mid-Semester Exam Schedule Released", body: "The mid-semester examinations will be held from June 15–22. Timetable is now available on the portal.", author: "Principal Office", date: "2026-06-01", type: "exam", pinned: true },
  { id: 2, title: "Hackathon 2026 — Registrations Open!", body: "Annual inter-college hackathon registrations are open. Teams of 3–4. Last date: June 10. Register at the CS department office.", author: "CS Department", date: "2026-05-30", type: "event", pinned: false },
  { id: 3, title: "Library Timing Change", body: "Library will now remain open till 9 PM on weekdays. Weekend timing: 10 AM – 5 PM.", author: "Library Admin", date: "2026-05-29", type: "general", pinned: false },
  { id: 4, title: "Sports Day 2026", body: "Annual Sports Day scheduled for June 25. Register for events at the Physical Education office by June 12.", author: "Sports Committee", date: "2026-05-28", type: "event", pinned: false },
];

const ATTENDANCE_DATA = {
  CS2301: [
    { date: "2026-05-26", subject: "Data Structures", status: "present" },
    { date: "2026-05-27", subject: "DBMS", status: "present" },
    { date: "2026-05-28", subject: "Web Development", status: "absent" },
    { date: "2026-05-29", subject: "Data Structures", status: "present" },
    { date: "2026-05-30", subject: "Computer Networks", status: "present" },
  ],
};

const MESSAGES = {
  "1-1": [
    { from: "faculty", text: "Hi Priya! How's the Binary Tree assignment going?", time: "10:30 AM" },
    { from: "student", text: "Almost done sir! Just finishing the traversal methods.", time: "10:45 AM" },
    { from: "faculty", text: "Great! Make sure to include the time complexity analysis too.", time: "10:46 AM" },
  ],
};

const GROUP_MSGS = {
  "CS-A": [
    { sender: "Dr. Ramesh Kumar", avatar: "RK", role: "faculty", text: "Good morning everyone! Today's lecture notes are attached below.", time: "9:00 AM", file: { name: "DSA_Lecture12.pdf", size: "2.3 MB" } },
    { sender: "Priya Sharma", avatar: "PS", role: "student", text: "Sir, will we cover AVL trees today?", time: "9:15 AM", file: null },
    { sender: "Dr. Ramesh Kumar", avatar: "RK", role: "faculty", text: "Yes! AVL trees + Red-Black trees. Come prepared.", time: "9:17 AM", file: null },
    { sender: "Arjun Mehta", avatar: "AM", role: "student", text: "Here are the practice problems from last week for reference!", time: "9:30 AM", file: { name: "Practice_Problems_Week5.pdf", size: "1.1 MB" } },
    { sender: "Kavya Nair", avatar: "KN", role: "student", text: "Thanks Arjun! Really helpful 😊", time: "9:35 AM", file: null },
  ],
};

function Avatar({ initials, size = 36, color = COLORS.accent }) {
  const bg = color + "22";
  return (
    <div style={{ width: size, height: size, borderRadius: "50%", background: bg, border: `2px solid ${color}`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: size * 0.33, color, flexShrink: 0, fontFamily: "Georgia, serif" }}>
      {initials}
    </div>
  );
}

function Badge({ text, type = "info" }) {
  const colors = { info: [COLORS.info + "22", COLORS.info], success: [COLORS.success + "22", COLORS.success], warning: [COLORS.warm + "22", COLORS.warm], danger: [COLORS.accent + "22", COLORS.accent], neutral: [COLORS.muted + "22", COLORS.muted] };
  const [bg, fg] = colors[type] || colors.info;
  return <span style={{ background: bg, color: fg, padding: "2px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600, letterSpacing: 0.5 }}>{text}</span>;
}

function StatCard({ label, value, sub, icon, color = COLORS.accent }) {
  return (
    <div style={{ background: COLORS.card, borderRadius: 16, padding: "18px 20px", border: `1px solid ${COLORS.border}`, display: "flex", flexDirection: "column", gap: 6, position: "relative", overflow: "hidden" }}>
      <div style={{ position: "absolute", top: -10, right: -10, width: 60, height: 60, borderRadius: "50%", background: color + "15" }} />
      <span style={{ fontSize: 26 }}>{icon}</span>
      <span style={{ fontSize: 26, fontWeight: 800, color: COLORS.primary, fontFamily: "Georgia, serif" }}>{value}</span>
      <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.primary }}>{label}</span>
      {sub && <span style={{ fontSize: 11, color: COLORS.muted }}>{sub}</span>}
    </div>
  );
}

function SectionTitle({ children }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
      <div style={{ width: 4, height: 22, borderRadius: 2, background: COLORS.accent }} />
      <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: COLORS.primary, fontFamily: "Georgia, serif" }}>{children}</h2>
    </div>
  );
}

// ── Dashboard ──────────────────────────────────────────────────────────────────
function Dashboard() {
  const lowAtt = STUDENTS.filter(s => s.attendance < 75).length;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Welcome Banner */}
      <div style={{ background: `linear-gradient(135deg, ${COLORS.primary} 0%, #16213e 100%)`, borderRadius: 20, padding: "28px 32px", color: "#fff", position: "relative", overflow: "hidden" }}>
        <div style={{ position: "absolute", top: -30, right: -30, width: 180, height: 180, borderRadius: "50%", background: COLORS.accent + "20" }} />
        <div style={{ position: "absolute", bottom: -50, right: 60, width: 140, height: 140, borderRadius: "50%", background: COLORS.teal + "20" }} />
        <p style={{ margin: "0 0 4px", fontSize: 13, opacity: 0.7, letterSpacing: 1, textTransform: "uppercase" }}>Monday, June 1, 2026</p>
        <h1 style={{ margin: "0 0 6px", fontSize: 26, fontWeight: 800, fontFamily: "Georgia, serif" }}>Good Morning, Faculty! 👋</h1>
        <p style={{ margin: 0, fontSize: 14, opacity: 0.75 }}>Here's what's happening at your college today.</p>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14 }}>
        <StatCard label="Total Students" value={STUDENTS.length} sub="Across all classes" icon="🎓" color={COLORS.info} />
        <StatCard label="Faculty Members" value={FACULTY.length} sub="Active this semester" icon="👩‍🏫" color={COLORS.teal} />
        <StatCard label="Pending Assignments" value={ASSIGNMENTS.filter(a => a.status === "pending").length} sub="Across all classes" icon="📋" color={COLORS.warm} />
        <StatCard label="Low Attendance" value={lowAtt} sub="Below 75% threshold" icon="⚠️" color={COLORS.accent} />
      </div>

      {/* Announcements + Quick Attendance */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {/* Pinned Announcement */}
        <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
          <SectionTitle>📢 Latest Announcements</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {ANNOUNCEMENTS.slice(0, 3).map(a => (
              <div key={a.id} style={{ padding: "12px 14px", borderRadius: 10, background: a.pinned ? COLORS.accent + "0d" : COLORS.soft, border: `1px solid ${a.pinned ? COLORS.accent + "33" : COLORS.border}` }}>
                {a.pinned && <Badge text="📌 Pinned" type="danger" />}
                <p style={{ margin: "6px 0 2px", fontWeight: 700, fontSize: 14, color: COLORS.primary }}>{a.title}</p>
                <p style={{ margin: 0, fontSize: 12, color: COLORS.muted }}>{a.author} · {a.date}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Today's Attendance Snapshot */}
        <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
          <SectionTitle>📊 Attendance Snapshot</SectionTitle>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {STUDENTS.map(s => (
              <div key={s.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <Avatar initials={s.avatar} size={30} color={s.attendance >= 75 ? COLORS.success : COLORS.accent} />
                <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: COLORS.primary }}>{s.name}</span>
                <div style={{ width: 100, height: 8, borderRadius: 4, background: COLORS.border, overflow: "hidden" }}>
                  <div style={{ width: `${s.attendance}%`, height: "100%", background: s.attendance >= 75 ? COLORS.success : COLORS.accent, borderRadius: 4 }} />
                </div>
                <span style={{ fontSize: 12, fontWeight: 700, color: s.attendance >= 75 ? COLORS.success : COLORS.accent, minWidth: 36 }}>{s.attendance}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Assignment Overview */}
      <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
        <SectionTitle>📝 Assignment Overview</SectionTitle>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12 }}>
          {ASSIGNMENTS.map(a => {
            const pct = Math.round((a.submissions / a.total) * 100);
            const statusColor = { pending: COLORS.warm, overdue: COLORS.accent, upcoming: COLORS.info, completed: COLORS.success }[a.status];
            return (
              <div key={a.id} style={{ padding: 14, borderRadius: 12, border: `1px solid ${COLORS.border}`, background: COLORS.soft }}>
                <Badge text={a.status} type={{ pending: "warning", overdue: "danger", upcoming: "info", completed: "success" }[a.status]} />
                <p style={{ margin: "8px 0 2px", fontSize: 13, fontWeight: 700, color: COLORS.primary, lineHeight: 1.3 }}>{a.title}</p>
                <p style={{ margin: "0 0 8px", fontSize: 11, color: COLORS.muted }}>{a.subject}</p>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
                  <span style={{ fontSize: 11, color: COLORS.muted }}>{a.submissions}/{a.total} submitted</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: statusColor }}>{pct}%</span>
                </div>
                <div style={{ height: 6, borderRadius: 3, background: COLORS.border }}>
                  <div style={{ width: `${pct}%`, height: "100%", background: statusColor, borderRadius: 3, transition: "width 0.5s" }} />
                </div>
                <p style={{ margin: "6px 0 0", fontSize: 11, color: COLORS.muted }}>Due: {a.due}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ── Students ───────────────────────────────────────────────────────────────────
function Students() {
  const [selected, setSelected] = useState(null);
  const [filter, setFilter] = useState("All");

  const filtered = filter === "All" ? STUDENTS : STUDENTS.filter(s => s.class === filter);

  if (selected) {
    const s = selected;
    const att = ATTENDANCE_DATA[s.roll] || [];
    return (
      <div>
        <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", gap: 6, color: COLORS.muted, fontSize: 14, marginBottom: 20, padding: 0 }}>
          ← Back to Students
        </button>
        <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20 }}>
          {/* Profile Card */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ background: COLORS.card, borderRadius: 16, padding: 24, border: `1px solid ${COLORS.border}`, textAlign: "center" }}>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 12 }}>
                <Avatar initials={s.avatar} size={72} color={COLORS.accent} />
              </div>
              <h2 style={{ margin: "0 0 4px", fontSize: 20, fontWeight: 800, color: COLORS.primary, fontFamily: "Georgia, serif" }}>{s.name}</h2>
              <p style={{ margin: "0 0 12px", color: COLORS.muted, fontSize: 13 }}>{s.roll} · {s.class}</p>
              <div style={{ display: "flex", justifyContent: "center", gap: 8 }}>
                <Badge text={s.attendance >= 75 ? "✓ Good Attendance" : "⚠ Low Attendance"} type={s.attendance >= 75 ? "success" : "danger"} />
              </div>
            </div>
            <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
              <h3 style={{ margin: "0 0 14px", fontSize: 15, fontWeight: 700, color: COLORS.primary }}>General Information</h3>
              {[["📧 Email", s.email], ["📱 Phone", s.phone], ["🎂 DOB", s.dob], ["📍 Address", s.address]].map(([k, v]) => (
                <div key={k} style={{ display: "flex", flexDirection: "column", padding: "8px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                  <span style={{ fontSize: 11, color: COLORS.muted, marginBottom: 2 }}>{k}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.primary }}>{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {/* Academic Performance */}
            <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
              <SectionTitle>Academic Performance</SectionTitle>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginBottom: 20 }}>
                <StatCard label="CGPA" value={s.cgpa} sub="Current Semester" icon="🏆" color={COLORS.teal} />
                <StatCard label="Attendance" value={`${s.attendance}%`} sub="This Semester" icon="📅" color={s.attendance >= 75 ? COLORS.success : COLORS.accent} />
                <StatCard label="Assignments" value={`${ASSIGNMENTS.filter(a => a.class === s.class && a.status === "completed").length}/${ASSIGNMENTS.filter(a => a.class === s.class).length}`} sub="Submitted" icon="📝" color={COLORS.info} />
              </div>
              <h3 style={{ margin: "0 0 12px", fontSize: 14, fontWeight: 700, color: COLORS.primary }}>Subject-wise Performance</h3>
              {[["Data Structures", 85], ["DBMS", 78], ["Computer Networks", 82], ["Web Development", 90]].map(([subj, marks]) => (
                <div key={subj} style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                  <span style={{ fontSize: 13, flex: 1, color: COLORS.primary }}>{subj}</span>
                  <div style={{ width: 160, height: 8, borderRadius: 4, background: COLORS.border }}>
                    <div style={{ width: `${marks}%`, height: "100%", background: COLORS.teal, borderRadius: 4 }} />
                  </div>
                  <span style={{ fontSize: 12, fontWeight: 700, color: COLORS.teal, minWidth: 32 }}>{marks}</span>
                </div>
              ))}
            </div>
            {/* Attendance Records */}
            <div style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}` }}>
              <SectionTitle>Recent Attendance Records</SectionTitle>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {att.length > 0 ? att.map((r, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 14px", borderRadius: 10, background: r.status === "present" ? COLORS.success + "0d" : COLORS.accent + "0d", border: `1px solid ${r.status === "present" ? COLORS.success + "33" : COLORS.accent + "33"}` }}>
                    <span style={{ fontSize: 16 }}>{r.status === "present" ? "✅" : "❌"}</span>
                    <span style={{ flex: 1, fontSize: 13, fontWeight: 600, color: COLORS.primary }}>{r.subject}</span>
                    <span style={{ fontSize: 12, color: COLORS.muted }}>{r.date}</span>
                    <Badge text={r.status} type={r.status === "present" ? "success" : "danger"} />
                  </div>
                )) : <p style={{ color: COLORS.muted, fontSize: 13 }}>No attendance records available.</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <SectionTitle>Student Directory</SectionTitle>
        <div style={{ display: "flex", gap: 8 }}>
          {["All", "CS-A", "CS-B"].map(f => (
            <button key={f} onClick={() => setFilter(f)} style={{ padding: "6px 16px", borderRadius: 20, border: `1px solid ${filter === f ? COLORS.accent : COLORS.border}`, background: filter === f ? COLORS.accent : "white", color: filter === f ? "white" : COLORS.primary, cursor: "pointer", fontSize: 13, fontWeight: 600 }}>
              {f}
            </button>
          ))}
        </div>
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
        {filtered.map(s => (
          <div key={s.id} onClick={() => setSelected(s)} style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}`, cursor: "pointer", transition: "transform 0.2s, box-shadow 0.2s" }}
            onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.1)"; }}
            onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}>
            <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 14 }}>
              <Avatar initials={s.avatar} size={44} color={s.attendance >= 75 ? COLORS.teal : COLORS.accent} />
              <div>
                <p style={{ margin: 0, fontWeight: 700, fontSize: 15, color: COLORS.primary }}>{s.name}</p>
                <p style={{ margin: 0, fontSize: 12, color: COLORS.muted }}>{s.roll} · {s.class}</p>
              </div>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div style={{ padding: "10px 12px", borderRadius: 10, background: COLORS.soft }}>
                <p style={{ margin: 0, fontSize: 11, color: COLORS.muted }}>Attendance</p>
                <p style={{ margin: "2px 0 0", fontSize: 18, fontWeight: 800, color: s.attendance >= 75 ? COLORS.success : COLORS.accent }}>{s.attendance}%</p>
              </div>
              <div style={{ padding: "10px 12px", borderRadius: 10, background: COLORS.soft }}>
                <p style={{ margin: 0, fontSize: 11, color: COLORS.muted }}>CGPA</p>
                <p style={{ margin: "2px 0 0", fontSize: 18, fontWeight: 800, color: COLORS.teal }}>{s.cgpa}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Assignments ────────────────────────────────────────────────────────────────
function Assignments() {
  const tabs = ["All", "pending", "overdue", "upcoming", "completed"];
  const [tab, setTab] = useState("All");
  const shown = tab === "All" ? ASSIGNMENTS : ASSIGNMENTS.filter(a => a.status === tab);

  return (
    <div>
      <SectionTitle>Assignments & Submissions</SectionTitle>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)} style={{ padding: "6px 16px", borderRadius: 20, border: `1px solid ${tab === t ? COLORS.accent : COLORS.border}`, background: tab === t ? COLORS.accent : "white", color: tab === t ? "white" : COLORS.primary, cursor: "pointer", fontSize: 13, fontWeight: 600, textTransform: "capitalize" }}>
            {t}
          </button>
        ))}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {shown.map(a => {
          const pct = Math.round((a.submissions / a.total) * 100);
          const sColor = { pending: COLORS.warm, overdue: COLORS.accent, upcoming: COLORS.info, completed: COLORS.success }[a.status];
          return (
            <div key={a.id} style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${COLORS.border}`, display: "flex", gap: 20, alignItems: "center" }}>
              <div style={{ width: 56, height: 56, borderRadius: 14, background: sColor + "15", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 24, flexShrink: 0 }}>
                {a.status === "completed" ? "✅" : a.status === "overdue" ? "🔴" : a.status === "upcoming" ? "🔵" : "🟡"}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                  <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: COLORS.primary }}>{a.title}</h3>
                  <Badge text={a.status} type={{ pending: "warning", overdue: "danger", upcoming: "info", completed: "success" }[a.status]} />
                </div>
                <p style={{ margin: "0 0 8px", fontSize: 13, color: COLORS.muted }}>{a.subject} · Class {a.class} · Due: {a.due}</p>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ flex: 1, height: 8, borderRadius: 4, background: COLORS.border }}>
                    <div style={{ width: `${pct}%`, height: "100%", background: sColor, borderRadius: 4 }} />
                  </div>
                  <span style={{ fontSize: 12, color: COLORS.muted, minWidth: 100 }}>{a.submissions}/{a.total} submitted ({pct}%)</span>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                <button style={{ padding: "8px 16px", borderRadius: 10, background: COLORS.primary, color: "white", border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>View Details</button>
                <button style={{ padding: "8px 16px", borderRadius: 10, background: COLORS.soft, color: COLORS.primary, border: `1px solid ${COLORS.border}`, cursor: "pointer", fontSize: 13, fontWeight: 600 }}>Remind Class</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Faculty ────────────────────────────────────────────────────────────────────
function FacultyPage() {
  return (
    <div>
      <SectionTitle>Faculty Information</SectionTitle>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
        {FACULTY.map(f => (
          <div key={f.id} style={{ background: COLORS.card, borderRadius: 16, padding: 22, border: `1px solid ${COLORS.border}` }}>
            <div style={{ display: "flex", gap: 14, alignItems: "center", marginBottom: 16 }}>
              <Avatar initials={f.avatar} size={52} color={COLORS.teal} />
              <div>
                <h3 style={{ margin: 0, fontSize: 16, fontWeight: 800, color: COLORS.primary, fontFamily: "Georgia, serif" }}>{f.name}</h3>
                <p style={{ margin: 0, fontSize: 13, color: COLORS.muted }}>{f.subject} · {f.dept} Dept.</p>
                <p style={{ margin: 0, fontSize: 12, color: COLORS.info }}>{f.email}</p>
              </div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <span style={{ fontSize: 12, color: COLORS.muted, marginRight: 4 }}>Classes:</span>
              {f.classes.map(c => <Badge key={c} text={c} type="info" />)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Announcements ──────────────────────────────────────────────────────────────
function AnnouncementsPage() {
  const [newTitle, setNewTitle] = useState("");
  const [newBody, setNewBody] = useState("");
  const [list, setList] = useState(ANNOUNCEMENTS);

  const post = () => {
    if (!newTitle.trim()) return;
    setList(prev => [{ id: Date.now(), title: newTitle, body: newBody, author: "Faculty Portal", date: "2026-06-01", type: "general", pinned: false }, ...prev]);
    setNewTitle(""); setNewBody("");
  };

  const typeIcon = { exam: "📝", event: "🎉", general: "📣" };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20 }}>
      <div>
        <SectionTitle>Official Announcements</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {list.map(a => (
            <div key={a.id} style={{ background: COLORS.card, borderRadius: 16, padding: 20, border: `1px solid ${a.pinned ? COLORS.accent + "44" : COLORS.border}`, position: "relative", overflow: "hidden" }}>
              {a.pinned && <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: COLORS.accent }} />}
              <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
                <span style={{ fontSize: 28 }}>{typeIcon[a.type] || "📣"}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
                    <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: COLORS.primary }}>{a.title}</h3>
                    {a.pinned && <Badge text="📌 Pinned" type="danger" />}
                    <Badge text={a.type} type={a.type === "exam" ? "warning" : a.type === "event" ? "info" : "neutral"} />
                  </div>
                  <p style={{ margin: "0 0 8px", fontSize: 13, color: COLORS.primary, lineHeight: 1.6 }}>{a.body}</p>
                  <p style={{ margin: 0, fontSize: 12, color: COLORS.muted }}>Posted by <strong>{a.author}</strong> on {a.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Post Announcement */}
      <div style={{ background: COLORS.card, borderRadius: 16, padding: 22, border: `1px solid ${COLORS.border}`, height: "fit-content", position: "sticky", top: 0 }}>
        <SectionTitle>Post New Announcement</SectionTitle>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <input value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Announcement Title..." style={{ padding: "10px 14px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, fontFamily: "inherit", outline: "none", width: "100%", boxSizing: "border-box" }} />
          <textarea value={newBody} onChange={e => setNewBody(e.target.value)} placeholder="Write the announcement body here..." rows={5} style={{ padding: "10px 14px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, fontFamily: "inherit", outline: "none", resize: "vertical", width: "100%", boxSizing: "border-box" }} />
          <button onClick={post} style={{ padding: "12px", borderRadius: 10, background: COLORS.accent, color: "white", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700 }}>📢 Post Announcement</button>
        </div>
      </div>
    </div>
  );
}

// ── Chatbot (lecture ↔ student) ────────────────────────────────────────────────
function ChatPage() {
  const [activeStudent, setActiveStudent] = useState(STUDENTS[0]);
  const [convs, setConvs] = useState(MESSAGES);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  const key = `1-${activeStudent.id}`;
  const msgs = convs[key] || [];

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = async () => {
    if (!text.trim()) return;
    const userMsg = { from: "faculty", text, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) };
    const newMsgs = [...msgs, userMsg];
    setConvs(p => ({ ...p, [key]: newMsgs }));
    setText("");
    setLoading(true);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are ${activeStudent.name}, a college student. Reply naturally as a student would to their professor/lecturer. Keep responses short (1-3 sentences), friendly, and use student-appropriate language. You are enrolled in ${activeStudent.class} with ${activeStudent.attendance}% attendance and CGPA of ${activeStudent.cgpa}. Be realistic and human.`,
          messages: newMsgs.map(m => ({ role: m.from === "faculty" ? "user" : "assistant", content: m.text }))
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "Sorry, I'll reply later!";
      setConvs(p => ({ ...p, [key]: [...newMsgs, { from: "student", text: reply, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }] }));
    } catch {
      setConvs(p => ({ ...p, [key]: [...newMsgs, { from: "student", text: "Sorry sir, I'm having connectivity issues right now!", time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }] }));
    }
    setLoading(false);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "260px 1fr", gap: 0, height: 600, borderRadius: 16, overflow: "hidden", border: `1px solid ${COLORS.border}`, background: COLORS.card }}>
      {/* Sidebar */}
      <div style={{ background: COLORS.primary, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "16px 14px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <p style={{ margin: 0, color: "rgba(255,255,255,0.5)", fontSize: 11, letterSpacing: 1, textTransform: "uppercase" }}>Messages</p>
        </div>
        <div style={{ flex: 1, overflow: "auto" }}>
          {STUDENTS.map(s => (
            <div key={s.id} onClick={() => setActiveStudent(s)} style={{ padding: "12px 14px", display: "flex", gap: 10, alignItems: "center", cursor: "pointer", background: activeStudent.id === s.id ? "rgba(233,69,96,0.2)" : "transparent", borderLeft: activeStudent.id === s.id ? `3px solid ${COLORS.accent}` : "3px solid transparent" }}>
              <Avatar initials={s.avatar} size={34} color={activeStudent.id === s.id ? COLORS.accent : "#94a3b8"} />
              <div>
                <p style={{ margin: 0, color: "white", fontSize: 13, fontWeight: 600 }}>{s.name}</p>
                <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>{s.class}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "14px 18px", borderBottom: `1px solid ${COLORS.border}`, display: "flex", gap: 10, alignItems: "center" }}>
          <Avatar initials={activeStudent.avatar} size={38} color={COLORS.accent} />
          <div>
            <p style={{ margin: 0, fontWeight: 700, fontSize: 15, color: COLORS.primary }}>{activeStudent.name}</p>
            <p style={{ margin: 0, fontSize: 12, color: COLORS.success }}>● Online</p>
          </div>
        </div>
        <div style={{ flex: 1, overflow: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: 10, background: COLORS.soft }}>
          {msgs.map((m, i) => (
            <div key={i} style={{ display: "flex", justifyContent: m.from === "faculty" ? "flex-end" : "flex-start", gap: 8, alignItems: "flex-end" }}>
              {m.from === "student" && <Avatar initials={activeStudent.avatar} size={28} color={COLORS.accent} />}
              <div style={{ maxWidth: "68%" }}>
                <div style={{ background: m.from === "faculty" ? COLORS.accent : COLORS.card, color: m.from === "faculty" ? "white" : COLORS.primary, padding: "10px 14px", borderRadius: m.from === "faculty" ? "18px 18px 4px 18px" : "18px 18px 18px 4px", fontSize: 14, lineHeight: 1.5, border: m.from === "faculty" ? "none" : `1px solid ${COLORS.border}` }}>
                  {m.text}
                </div>
                <p style={{ margin: "3px 4px 0", fontSize: 11, color: COLORS.muted, textAlign: m.from === "faculty" ? "right" : "left" }}>{m.time}</p>
              </div>
              {m.from === "faculty" && <Avatar initials="PR" size={28} color={COLORS.teal} />}
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
              <Avatar initials={activeStudent.avatar} size={28} color={COLORS.accent} />
              <div style={{ background: COLORS.card, padding: "10px 14px", borderRadius: "18px 18px 18px 4px", border: `1px solid ${COLORS.border}` }}>
                <span style={{ color: COLORS.muted, fontSize: 13 }}>typing...</span>
              </div>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
        <div style={{ padding: "12px 14px", borderTop: `1px solid ${COLORS.border}`, display: "flex", gap: 10 }}>
          <input value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} placeholder={`Message ${activeStudent.name}...`} style={{ flex: 1, padding: "10px 14px", borderRadius: 24, border: `1px solid ${COLORS.border}`, fontSize: 14, fontFamily: "inherit", outline: "none" }} />
          <button onClick={send} disabled={loading} style={{ padding: "10px 20px", borderRadius: 24, background: COLORS.accent, color: "white", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700 }}>Send</button>
        </div>
      </div>
    </div>
  );
}

// ── Class Group ────────────────────────────────────────────────────────────────
function GroupPage() {
  const [activeGroup, setActiveGroup] = useState("CS-A");
  const [groups, setGroups] = useState(GROUP_MSGS);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const fileRef = useRef(null);

  const msgs = groups[activeGroup] || [];
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const sendMsg = async (msgText, fileObj = null) => {
    if (!msgText.trim() && !fileObj) return;
    const newMsg = { sender: "Dr. Ramesh Kumar", avatar: "RK", role: "faculty", text: msgText, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), file: fileObj };
    const newList = [...msgs, newMsg];
    setGroups(p => ({ ...p, [activeGroup]: newList }));
    setText("");
    if (!msgText.trim()) return;
    setLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are a student in class ${activeGroup}. A faculty member just posted in the class group chat. Reply naturally as a student — ask a question, thank them, or acknowledge. Keep it 1-2 sentences, casual student tone.`,
          messages: [{ role: "user", content: msgText }]
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "👍";
      const student = STUDENTS.find(s => s.class === activeGroup) || STUDENTS[0];
      setGroups(p => ({ ...p, [activeGroup]: [...newList, { sender: student.name, avatar: student.avatar, role: "student", text: reply, time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }), file: null }] }));
    } catch {}
    setLoading(false);
  };

  return (
    <div style={{ display: "grid", gridTemplateColumns: "220px 1fr", gap: 0, height: 620, borderRadius: 16, overflow: "hidden", border: `1px solid ${COLORS.border}`, background: COLORS.card }}>
      {/* Sidebar */}
      <div style={{ background: "#0f172a", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "16px 14px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: 0, color: "rgba(255,255,255,0.5)", fontSize: 11, letterSpacing: 1, textTransform: "uppercase" }}>Class Groups</p>
        </div>
        {["CS-A", "CS-B"].map(g => (
          <div key={g} onClick={() => setActiveGroup(g)} style={{ padding: "14px", cursor: "pointer", background: activeGroup === g ? "rgba(15,155,142,0.2)" : "transparent", borderLeft: activeGroup === g ? `3px solid ${COLORS.teal}` : "3px solid transparent" }}>
            <p style={{ margin: 0, color: "white", fontWeight: 700, fontSize: 14 }}>🏫 Class {g}</p>
            <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>{STUDENTS.filter(s => s.class === g).length} students</p>
          </div>
        ))}
        <div style={{ padding: "14px", marginTop: "auto", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <p style={{ margin: 0, fontSize: 11, color: "rgba(255,255,255,0.4)" }}>Share notes, PDFs & announcements with your entire class.</p>
        </div>
      </div>

      {/* Chat */}
      <div style={{ display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 18px", borderBottom: `1px solid ${COLORS.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <p style={{ margin: 0, fontWeight: 700, fontSize: 15, color: COLORS.primary }}>🏫 Class {activeGroup} Group</p>
            <p style={{ margin: 0, fontSize: 12, color: COLORS.muted }}>{STUDENTS.filter(s => s.class === activeGroup).length} students · {FACULTY.length} faculty</p>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            <Badge text="📌 Share Files" type="info" />
            <Badge text="📢 Announce" type="warning" />
          </div>
        </div>

        <div style={{ flex: 1, overflow: "auto", padding: "14px 18px", display: "flex", flexDirection: "column", gap: 12, background: "#f8fafc" }}>
          {msgs.map((m, i) => (
            <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
              <Avatar initials={m.avatar} size={34} color={m.role === "faculty" ? COLORS.teal : COLORS.accent} />
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 4 }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: COLORS.primary }}>{m.sender}</span>
                  <Badge text={m.role} type={m.role === "faculty" ? "info" : "neutral"} />
                  <span style={{ fontSize: 11, color: COLORS.muted }}>{m.time}</span>
                </div>
                {m.text && <p style={{ margin: "0 0 6px", fontSize: 14, color: COLORS.primary, lineHeight: 1.5 }}>{m.text}</p>}
                {m.file && (
                  <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "8px 14px", borderRadius: 10, background: COLORS.info + "15", border: `1px solid ${COLORS.info + "44"}` }}>
                    <span>📄</span>
                    <div>
                      <p style={{ margin: 0, fontSize: 13, fontWeight: 600, color: COLORS.info }}>{m.file.name}</p>
                      <p style={{ margin: 0, fontSize: 11, color: COLORS.muted }}>{m.file.size}</p>
                    </div>
                    <button style={{ padding: "4px 10px", borderRadius: 6, background: COLORS.info, color: "white", border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600 }}>↓ Download</button>
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && <p style={{ color: COLORS.muted, fontSize: 13, marginLeft: 44 }}>A student is typing...</p>}
          <div ref={bottomRef} />
        </div>

        <div style={{ padding: "12px 14px", borderTop: `1px solid ${COLORS.border}`, display: "flex", gap: 10, alignItems: "center" }}>
          <input ref={fileRef} type="file" style={{ display: "none" }} onChange={e => { const f = e.target.files[0]; if (f) sendMsg("", { name: f.name, size: `${(f.size / 1024 / 1024).toFixed(1)} MB` }); }} />
          <button onClick={() => fileRef.current.click()} style={{ padding: "10px 12px", borderRadius: 10, border: `1px solid ${COLORS.border}`, background: COLORS.soft, cursor: "pointer", fontSize: 16 }} title="Attach file">📎</button>
          <input value={text} onChange={e => setText(e.target.value)} onKeyDown={e => e.key === "Enter" && sendMsg(text)} placeholder={`Message Class ${activeGroup}...`} style={{ flex: 1, padding: "10px 14px", borderRadius: 24, border: `1px solid ${COLORS.border}`, fontSize: 14, fontFamily: "inherit", outline: "none" }} />
          <button onClick={() => sendMsg(text)} disabled={loading} style={{ padding: "10px 20px", borderRadius: 24, background: COLORS.teal, color: "white", border: "none", cursor: "pointer", fontSize: 14, fontWeight: 700 }}>Send</button>
        </div>
      </div>
    </div>
  );
}

// ── App Shell ──────────────────────────────────────────────────────────────────
const NAV = [
  { id: "dashboard", label: "Dashboard", icon: "🏠" },
  { id: "students", label: "Students", icon: "🎓" },
  { id: "assignments", label: "Assignments", icon: "📝" },
  { id: "faculty", label: "Faculty", icon: "👩‍🏫" },
  { id: "announcements", label: "Announcements", icon: "📢" },
  { id: "chat", label: "Messages", icon: "💬" },
  { id: "group", label: "Class Group", icon: "👥" },
];

export default function App() {
  const [page, setPage] = useState("dashboard");

  const pages = { dashboard: <Dashboard />, students: <Students />, assignments: <Assignments />, faculty: <FacultyPage />, announcements: <AnnouncementsPage />, chat: <ChatPage />, group: <GroupPage /> };

  return (
    <div style={{ display: "flex", minHeight: "100vh", fontFamily: "'Segoe UI', Tahoma, Geneva, sans-serif", background: COLORS.soft }}>
      {/* Sidebar */}
      <div style={{ width: 220, background: COLORS.primary, display: "flex", flexDirection: "column", flexShrink: 0, position: "sticky", top: 0, height: "100vh" }}>
        <div style={{ padding: "24px 18px 20px", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 36, height: 36, borderRadius: 10, background: COLORS.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18 }}>🎓</div>
            <div>
              <p style={{ margin: 0, color: "white", fontWeight: 800, fontSize: 14, fontFamily: "Georgia, serif" }}>CampusHub</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>Management System</p>
            </div>
          </div>
        </div>
        <nav style={{ flex: 1, padding: "12px 10px" }}>
          {NAV.map(n => (
            <button key={n.id} onClick={() => setPage(n.id)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, marginBottom: 4, background: page === n.id ? COLORS.accent : "transparent", border: "none", cursor: "pointer", textAlign: "left", color: page === n.id ? "white" : "rgba(255,255,255,0.6)", fontSize: 14, fontWeight: page === n.id ? 700 : 500, transition: "all 0.2s" }}>
              <span style={{ fontSize: 16 }}>{n.icon}</span> {n.label}
            </button>
          ))}
        </nav>
        <div style={{ padding: "14px 16px", borderTop: "1px solid rgba(255,255,255,0.08)" }}>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <Avatar initials="PR" size={32} color={COLORS.teal} />
            <div>
              <p style={{ margin: 0, color: "white", fontSize: 12, fontWeight: 600 }}>Prof. Ramesh</p>
              <p style={{ margin: 0, color: "rgba(255,255,255,0.4)", fontSize: 11 }}>Faculty · CS Dept.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ flex: 1, overflow: "auto" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 28px" }}>
          {pages[page]}
        </div>
      </div>
    </div>
  );
}
