import { useState, useRef, useEffect } from "react";

const T={navy:"#0a1628",navyMid:"#112240",navyLt:"#1e3a5f",gold:"#c9922a",goldLt:"#f0b84b",teal:"#0e9f8a",tealLt:"#1bbfa8",cream:"#fdf8f0",white:"#ffffff",border:"#e2ddd6",muted:"#7a8299",danger:"#d64045",success:"#1a9e6d",warn:"#d97706",info:"#2563eb",text:"#1a2340"};
const BC={CSE:{bg:"#1e3a5f",accent:"#4a9eff"},ISE:{bg:"#1a3d2b",accent:"#34d399"},EC:{bg:"#3d1a1a",accent:"#f87171"},AIML:{bg:"#2d1a4a",accent:"#a78bfa"}};
const BRANCHES=["CSE","ISE","EC","AIML"];
const SEMS=[1,2,3,4,5,6,7,8];
const SY={1:"1st Year",2:"1st Year",3:"2nd Year",4:"2nd Year",5:"3rd Year",6:"3rd Year",7:"4th Year",8:"4th Year"};
const BS={
  CSE:{1:["Engineering Mathematics-I","Engineering Physics","Engineering Chemistry","Basic Electrical Engineering","C Programming","Engineering Graphics"],2:["Engineering Mathematics-II","Data Structures","Digital Electronics","OOP with Java","Computer Organization","Soft Skills"],3:["Discrete Mathematics","Design & Analysis of Algorithms","Database Management Systems","Operating Systems","Computer Networks","Web Technologies"],4:["Software Engineering","Microprocessors","Compiler Design","Computer Graphics","Elective-I","Mini Project"],5:["Theory of Computation","Artificial Intelligence","Cloud Computing","Machine Learning","Elective-II","Seminar"],6:["Cryptography & Network Security","Big Data Analytics","IoT Systems","Deep Learning","Elective-III","Project Phase-I"],7:["Distributed Systems","Blockchain Technology","DevOps","Elective-IV","Internship","Project Phase-II"],8:["Research Methodology","Professional Ethics","Elective-V","Major Project","Placement Training"]},
  ISE:{1:["Engineering Mathematics-I","Engineering Physics","Engineering Chemistry","Basic Electrical Engineering","C Programming","Engineering Graphics"],2:["Engineering Mathematics-II","Data Structures","Digital Electronics","OOP with Java","Computer Organization","Soft Skills"],3:["Discrete Mathematics","Design & Analysis of Algorithms","DBMS","Operating Systems","Information Security","Web Technologies"],4:["Software Engineering","System Software","Compiler Design","Computer Graphics","Elective-I","Mini Project"],5:["Information Retrieval","Artificial Intelligence","Cloud Computing","Network Security","Elective-II","Seminar"],6:["Big Data Analytics","Cyber Security","IoT Systems","Deep Learning","Elective-III","Project Phase-I"],7:["Digital Forensics","Blockchain Technology","DevOps","Elective-IV","Internship","Project Phase-II"],8:["Research Methodology","Professional Ethics","Elective-V","Major Project","Placement Training"]},
  EC:{1:["Engineering Mathematics-I","Engineering Physics","Engineering Chemistry","Basic Electrical Engineering","C Programming","Engineering Graphics"],2:["Engineering Mathematics-II","Network Analysis","Electronic Devices","OOP with C++","Signals and Systems","Soft Skills"],3:["Analog Electronics","Digital Signal Processing","Electromagnetic Theory","Communication Theory","Microcontrollers","HDL Programming"],4:["VLSI Design","Antenna Theory","Wireless Communication","Embedded Systems","Elective-I","Mini Project"],5:["RF & Microwave Engineering","Optical Fiber Communication","Digital Image Processing","MEMS","Elective-II","Seminar"],6:["Radar and Navigation","Satellite Communication","Biomedical Electronics","IoT Systems","Elective-III","Project Phase-I"],7:["5G Technologies","Robotics","Elective-IV","Internship","Project Phase-II"],8:["Research Methodology","Professional Ethics","Elective-V","Major Project","Placement Training"]},
  AIML:{1:["Engineering Mathematics-I","Engineering Physics","Engineering Chemistry","Basic Electrical Engineering","C Programming","Engineering Graphics"],2:["Engineering Mathematics-II","Data Structures","Probability & Statistics","OOP with Python","Linear Algebra","Soft Skills"],3:["Discrete Mathematics","Design & Analysis of Algorithms","DBMS","Machine Learning Basics","Data Visualization","Web Technologies"],4:["Supervised Learning","Unsupervised Learning","Computer Vision","NLP Fundamentals","Elective-I","Mini Project"],5:["Deep Learning","Reinforcement Learning","Big Data Analytics","AI Ethics","Elective-II","Seminar"],6:["Generative AI","Speech Processing","Cloud AI Services","MLOps","Elective-III","Project Phase-I"],7:["Advanced NLP","AI in Healthcare","Elective-IV","Internship","Project Phase-II"],8:["Research Methodology","Professional Ethics","Elective-V","Major Project","Placement Training"]},
};
const SEED={students:[],pendingStudents:[],faculty:[],announcements:[{id:1,title:"Welcome to GEC Arsikere Portal!",body:"Official Student Management System for Government Engineering College, Arsikere. All students register and await admin approval.",author:"Admin",date:"2026-06-01",type:"general",pinned:true,branch:"All"},{id:2,title:"Semester Examination Schedule",body:"End semester examinations are scheduled. Check timetable on the notice board. Hall tickets at admin office.",author:"Examination Cell",date:"2026-06-01",type:"exam",pinned:false,branch:"All"}],assignments:[],attendance:{},groupMsgs:{CSE:[],ISE:[],EC:[],AIML:[]},messages:{},media:[]};

// Persistent storage via Claude artifact storage API
// Falls back to in-memory if storage unavailable
function gd(){
  try{
    // Try reading from storage API (async not possible here, use sync cache)
    if(window.__gecData)return window.__gecData;
    // Try localStorage as secondary
    const raw=localStorage.getItem("gec_arsikere_v9");
    if(raw){window.__gecData=JSON.parse(raw);return window.__gecData;}
  }catch(e){}
  window.__gecData=JSON.parse(JSON.stringify(SEED));
  return window.__gecData;
}
function sd(d){
  window.__gecData=d;
  // Persist to localStorage (works in hosted environment)
  try{localStorage.setItem("gec_arsikere_v9",JSON.stringify(d));}catch(e){}
  // Also persist to Claude artifact storage API
  try{
    if(window.storage){
      window.storage.set("gec_main",JSON.stringify(d)).catch(()=>{});
    }
  }catch(e){}
}
// On startup, try to load from artifact storage API if localStorage is empty
async function initStorage(){
  try{
    if(window.storage){
      const result=await window.storage.get("gec_main");
      if(result&&result.value){
        const parsed=JSON.parse(result.value);
        window.__gecData=parsed;
        // Also sync to localStorage as backup
        try{localStorage.setItem("gec_arsikere_v9",result.value);}catch(e){}
      }
    }
  }catch(e){}
}
// Run async init immediately
initStorage().catch(()=>{});
function toast(msg,type="success"){const el=document.createElement("div");el.textContent=msg;el.style.cssText="position:fixed;bottom:24px;right:24px;background:"+(type==="success"?T.success:T.danger)+";color:white;padding:12px 22px;border-radius:12px;font-weight:700;font-size:14px;z-index:9999;box-shadow:0 4px 20px rgba(0,0,0,0.2);font-family:inherit";document.body.appendChild(el);setTimeout(()=>el.remove(),3000);}
function calcAtt(sid,branch,sem){const d=gd();const att=d.attendance||{};const subs=BS[branch]?.[parseInt(sem)]||[];return subs.map(sub=>{const keys=Object.keys(att).filter(k=>k.startsWith(sid+"_"+sub+"_"));if(!keys.length)return{sub,pct:null,present:0,total:0};const present=keys.filter(k=>att[k]==="present").length;return{sub,pct:Math.round((present/keys.length)*100),present,total:keys.length};});}

function Av({initials,size=36,color=T.gold}){return <div style={{width:size,height:size,borderRadius:"50%",background:color+"22",border:"2px solid "+color,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:size*0.32,color,flexShrink:0}}>{(initials||"?").slice(0,2).toUpperCase()}</div>;}
function Badge({text,type="info"}){const m={info:[T.info+"18",T.info],success:[T.success+"18",T.success],warning:[T.warn+"18",T.warn],danger:[T.danger+"18",T.danger],neutral:[T.muted+"18",T.muted],gold:[T.gold+"22",T.gold]};const[bg,fg]=m[type]||m.info;return<span style={{background:bg,color:fg,padding:"3px 10px",borderRadius:20,fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{text}</span>;}
function Card({children,style}){return<div style={{background:T.white,borderRadius:16,padding:20,border:"1px solid "+T.border,...style}}>{children}</div>;}
function ST({children,sub}){return<div style={{marginBottom:20}}><div style={{display:"flex",alignItems:"center",gap:10}}><div style={{width:4,height:24,borderRadius:2,background:"linear-gradient(180deg,"+T.gold+","+T.goldLt+")"}}/><h2 style={{margin:0,fontSize:20,fontWeight:800,color:T.navy,fontFamily:"Georgia,serif"}}>{children}</h2></div>{sub&&<p style={{margin:"4px 0 0 14px",fontSize:13,color:T.muted}}>{sub}</p>}</div>;}
function Inp({label,...p}){return<div style={{display:"flex",flexDirection:"column",gap:5}}>{label&&<label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase"}}>{label}</label>}<input {...p} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid "+T.border,fontSize:14,fontFamily:"inherit",outline:"none",background:"#fff",color:T.text,...(p.style||{})}} onFocus={e=>e.target.style.borderColor=T.gold} onBlur={e=>e.target.style.borderColor=T.border}/></div>;}
function Sel({label,children,...p}){return<div style={{display:"flex",flexDirection:"column",gap:5}}>{label&&<label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase"}}>{label}</label>}<select {...p} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid "+T.border,fontSize:14,fontFamily:"inherit",outline:"none",background:"#fff",color:"#1a2340",cursor:"pointer"}}>{children}</select></div>;}
function Btn({children,onClick,variant="primary",style={},disabled}){const vs={primary:{background:"linear-gradient(135deg,"+T.navy+","+T.navyMid+")",color:T.white,border:"none"},gold:{background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",color:T.white,border:"none"},outline:{background:"transparent",color:T.navy,border:"1.5px solid "+T.border},danger:{background:T.danger,color:T.white,border:"none"},teal:{background:T.teal,color:T.white,border:"none"},success:{background:T.success,color:T.white,border:"none"},warn:{background:T.warn,color:T.white,border:"none"}};return<button onClick={onClick} disabled={disabled} style={{padding:"10px 20px",borderRadius:10,cursor:disabled?"not-allowed":"pointer",fontSize:13,fontWeight:700,opacity:disabled?.5:1,fontFamily:"inherit",...vs[variant],...style}}>{children}</button>;}
function DI({label,...p}){return<div style={{display:"flex",flexDirection:"column",gap:5}}>{label&&<label style={{fontSize:12,fontWeight:700,color:"rgba(255,255,255,0.8)",letterSpacing:.5,textTransform:"uppercase"}}>{label}</label>}<input {...p} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid rgba(255,255,255,0.25)",fontSize:14,fontFamily:"inherit",background:"#fff",color:"#1a2340",outline:"none",...(p.style||{})}}/></div>;}
function DS({label,children,...p}){return<div style={{display:"flex",flexDirection:"column",gap:5}}>{label&&<label style={{fontSize:12,fontWeight:700,color:"rgba(255,255,255,0.8)",letterSpacing:.5,textTransform:"uppercase"}}>{label}</label>}<select {...p} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid rgba(255,255,255,0.25)",fontSize:14,fontFamily:"inherit",background:"#fff",color:"#1a2340",cursor:"pointer",outline:"none"}}>{children}</select></div>;}

function Sidebar({tabs,active,onSelect,user,onLogout,role}){
  const rc={admin:T.gold,faculty:T.teal,student:(BC[user.branch]||BC.CSE).accent}[role]||T.gold;
  return(
    <div style={{width:220,background:T.navy,display:"flex",flexDirection:"column",flexShrink:0,position:"sticky",top:0,height:"100vh",overflowY:"auto"}}>
      <div style={{padding:"16px 14px 12px",borderBottom:"1px solid rgba(255,255,255,0.08)"}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:12}}>
          <div style={{width:34,height:34,borderRadius:10,background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>🏛️</div>
          <div><p style={{margin:0,color:T.white,fontWeight:800,fontSize:12,fontFamily:"Georgia,serif"}}>GEC Arsikere</p><p style={{margin:0,color:rc,fontSize:10,fontWeight:600}}>{role==="admin"?"Admin Panel":role==="faculty"?"Faculty Portal":"Student Portal"}</p></div>
        </div>
        <div style={{display:"flex",gap:8,alignItems:"center",padding:"8px 10px",borderRadius:10,background:"rgba(255,255,255,0.05)"}}>
          <Av initials={(user.avatar||user.name||"?").slice(0,2)} size={30} color={rc}/>
          <div style={{overflow:"hidden"}}><p style={{margin:0,color:T.white,fontSize:12,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.name||"User"}</p><p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:10}}>{role==="student"?(user.branch+" · Sem "+user.sem):role==="faculty"?((user.designation||"Faculty")+" · "+user.branch):"Administrator"}</p></div>
        </div>
      </div>
      <nav style={{flex:1,padding:"8px 8px"}}>{tabs.map(([id,label])=><button key={id} onClick={()=>onSelect(id)} style={{width:"100%",display:"flex",alignItems:"center",gap:8,padding:"9px 10px",borderRadius:8,marginBottom:2,background:active===id?rc+"33":"transparent",border:active===id?"1px solid "+rc+"55":"1px solid transparent",cursor:"pointer",textAlign:"left",color:active===id?rc:"rgba(255,255,255,0.55)",fontSize:12,fontWeight:active===id?700:500,fontFamily:"inherit"}}>{label}</button>)}</nav>
      <div style={{padding:"10px",borderTop:"1px solid rgba(255,255,255,0.08)"}}><button onClick={onLogout} style={{width:"100%",padding:"8px",borderRadius:8,background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.1)",color:"rgba(255,255,255,0.5)",cursor:"pointer",fontSize:12,fontFamily:"inherit"}}>← Sign Out</button></div>
    </div>
  );
}

function StudentProfileModal({student,onClose}){
  const att=calcAtt(student.id,student.branch,student.sem);
  const valid=att.filter(x=>x.pct!==null);
  const overall=valid.length?Math.round(valid.reduce((a,x)=>a+x.pct,0)/valid.length):null;
  const bc=BC[student.branch]||BC.CSE;
  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000,padding:20}} onClick={onClose}>
      <div style={{background:T.white,borderRadius:20,width:"100%",maxWidth:640,maxHeight:"90vh",overflowY:"auto",padding:28,boxShadow:"0 20px 60px rgba(0,0,0,0.3)"}} onClick={e=>e.stopPropagation()}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20}}>
          <div style={{display:"flex",gap:14,alignItems:"center"}}>
            <Av initials={student.avatar} size={62} color={bc.accent}/>
            <div>
              <h2 style={{margin:"0 0 4px",fontSize:19,fontWeight:900,color:T.navy,fontFamily:"Georgia,serif"}}>{student.name}</h2>
              <p style={{margin:"0 0 6px",color:T.muted,fontSize:13}}>{student.usn} · {student.branch} · Sem {student.sem} · Sec {student.section}</p>
              <div style={{display:"flex",gap:6,flexWrap:"wrap"}}><Badge text={student.branch} type="info"/><Badge text={SY[student.sem]||""} type="neutral"/>{overall!==null&&<Badge text={overall+"% Overall"} type={overall>=75?"success":"danger"}/>}</div>
            </div>
          </div>
          <button onClick={onClose} style={{background:"none",border:"none",fontSize:22,cursor:"pointer",color:T.muted}}>✕</button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:18}}>
          {[["📧 Email",student.email],["📱 Phone",student.phone],["🎂 DOB",student.dob],["📍 Address",student.address],["👨 Father",student.fatherName],["👩 Mother",student.motherName]].map(([k,v])=>v?<div key={k} style={{padding:"9px 12px",borderRadius:10,background:T.cream,border:"1px solid "+T.border}}><p style={{margin:"0 0 2px",fontSize:11,color:T.muted,fontWeight:700,textTransform:"uppercase"}}>{k}</p><p style={{margin:0,fontSize:13,fontWeight:600,color:T.text}}>{v}</p></div>:null)}
        </div>
        <div style={{background:T.cream,borderRadius:14,padding:16,border:"1px solid "+T.border}}>
          <h3 style={{margin:"0 0 14px",fontSize:14,fontWeight:800,color:T.navy}}>📊 Subject-wise Attendance — Sem {student.sem}</h3>
          {att.map((a,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:i<att.length-1?"1px solid "+T.border:"none"}}>
              <span style={{flex:1,fontSize:13,color:T.text}}>{a.sub}</span>
              {a.pct===null?<span style={{fontSize:12,color:T.muted,fontStyle:"italic"}}>No data</span>:<>
                <div style={{width:120,height:8,borderRadius:4,background:T.border}}><div style={{width:a.pct+"%",height:"100%",background:a.pct>=75?T.success:T.danger,borderRadius:4}}/></div>
                <span style={{fontSize:12,fontWeight:800,color:a.pct>=75?T.success:T.danger,minWidth:42,textAlign:"right"}}>{a.pct}%</span>
                <span style={{fontSize:11,color:T.muted}}>{a.present}/{a.total}</span>
              </>}
            </div>
          ))}
          {att.every(a=>a.pct===null)&&<p style={{color:T.muted,fontSize:13,margin:0,textAlign:"center"}}>No attendance marked yet.</p>}
        </div>
      </div>
    </div>
  );
}

function MediaGallery({media}){
  const [preview,setPreview]=useState(null);
  if(!media||!media.length)return<Card style={{textAlign:"center",padding:40}}><p style={{fontSize:36,margin:"0 0 8px"}}>🖼️</p><p style={{color:T.muted,fontSize:14,margin:0}}>No event media yet. Admin will post college photos here.</p></Card>;
  return(
    <>
      {preview&&<div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:2000,padding:20}} onClick={()=>setPreview(null)}>
        <div style={{maxWidth:"90vw",maxHeight:"90vh",position:"relative",display:"flex",flexDirection:"column",alignItems:"center",gap:12}} onClick={e=>e.stopPropagation()}>
          <button onClick={()=>setPreview(null)} style={{position:"absolute",top:-40,right:0,background:"rgba(255,255,255,0.15)",border:"none",color:"white",fontSize:20,cursor:"pointer",borderRadius:"50%",width:36,height:36}}>✕</button>
          {preview.type==="video"?<video src={preview.url} controls autoPlay style={{maxWidth:"85vw",maxHeight:"78vh",borderRadius:12}}/>:<img src={preview.url} style={{maxWidth:"85vw",maxHeight:"78vh",borderRadius:12,objectFit:"contain"}} alt={preview.caption}/>}
          {preview.caption&&<div style={{background:"rgba(255,255,255,0.12)",padding:"8px 20px",borderRadius:30}}><p style={{color:"white",margin:0,fontSize:14,fontWeight:600,textAlign:"center"}}>{preview.caption}</p>{preview.event&&<p style={{color:"rgba(255,255,255,0.6)",margin:"2px 0 0",fontSize:12,textAlign:"center"}}>{preview.event}</p>}</div>}
        </div>
      </div>}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:14}}>
        {media.map((m,i)=>(
          <div key={i} onClick={()=>setPreview(m)} style={{borderRadius:14,overflow:"hidden",cursor:"pointer",border:"1px solid "+T.border,background:T.white,transition:"transform .2s,box-shadow .2s"}} onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-3px)";e.currentTarget.style.boxShadow="0 8px 24px rgba(0,0,0,0.12)"}} onMouseLeave={e=>{e.currentTarget.style.transform="";e.currentTarget.style.boxShadow=""}}>
            <div style={{height:130,background:"#1a1a2e",display:"flex",alignItems:"center",justifyContent:"center",position:"relative",overflow:"hidden"}}>
              {m.type==="video"?<div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:6}}><span style={{fontSize:32}}>▶️</span><span style={{color:"rgba(255,255,255,0.5)",fontSize:11}}>VIDEO</span></div>:<img src={m.url} style={{width:"100%",height:"100%",objectFit:"cover"}} alt={m.caption} onError={e=>{e.target.style.display="none";}}/>}
              <div style={{position:"absolute",top:8,right:8}}><Badge text={m.type==="video"?"🎥 Video":"📷 Photo"} type={m.type==="video"?"info":"success"}/></div>
            </div>
            <div style={{padding:"10px 12px"}}><p style={{margin:"0 0 2px",fontSize:13,fontWeight:700,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{m.caption||"College Event"}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{m.event?m.event+" · ":""}{m.date}</p></div>
          </div>
        ))}
      </div>
    </>
  );
}

function AdminMediaUpload({onPost}){
  const [form,setForm]=useState({type:"photo",caption:"",event:"",url:"",mode:"file"});
  const [preview,setPreview]=useState(null);
  const [loading,setLoading]=useState(false);
  const fileRef=useRef(null);
  const sf=(k,v)=>setForm(p=>({...p,[k]:v}));
  const handleFile=(e)=>{
    const file=e.target.files[0];if(!file)return;
    const isVid=file.type.startsWith("video/");sf("type",isVid?"video":"photo");setLoading(true);
    const r=new FileReader();r.onload=ev=>{const b64=ev.target.result;sf("url",b64);setPreview(b64);setLoading(false);};r.readAsDataURL(file);
  };
  const post=()=>{
    if(!form.url){toast("Upload a file or paste a URL","error");return;}
    if(!form.caption.trim()){toast("Please add a caption","error");return;}
    onPost({type:form.type,url:form.url,caption:form.caption,event:form.event});
    setForm({type:"photo",caption:"",event:"",url:"",mode:"file"});setPreview(null);
    if(fileRef.current)fileRef.current.value="";
  };
  return(
    <Card>
      <ST>📤 Upload Event Media</ST>
      <p style={{margin:"-12px 0 14px",fontSize:12,color:T.muted,lineHeight:1.6}}>Photos/videos posted here appear on every student and faculty dashboard instantly.</p>
      <div style={{display:"flex",flexDirection:"column",gap:13}}>
        <div style={{display:"flex",borderRadius:10,overflow:"hidden",border:"1px solid "+T.border}}>
          {[["file","📁 Upload File"],["url","🔗 Paste URL"]].map(([m,l])=><button key={m} onClick={()=>{sf("mode",m);setPreview(null);sf("url","");}} style={{flex:1,padding:"9px",border:"none",background:form.mode===m?T.navy:T.white,color:form.mode===m?T.white:T.muted,cursor:"pointer",fontSize:13,fontWeight:700,fontFamily:"inherit"}}>{l}</button>)}
        </div>
        {form.mode==="file"?(
          <div>
            <input ref={fileRef} type="file" accept="image/*,video/*" style={{display:"none"}} onChange={handleFile}/>
            <button onClick={()=>fileRef.current.click()} style={{width:"100%",padding:"20px 14px",borderRadius:12,border:"2px dashed "+(form.url?T.teal:T.border),background:form.url?T.teal+"08":T.cream,cursor:"pointer",fontSize:13,fontFamily:"inherit",color:form.url?T.teal:T.muted,fontWeight:600,display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
              {loading?<><span style={{fontSize:28}}>⏳</span><span>Processing...</span></>:form.url?<><span style={{fontSize:28}}>✅</span><span>File ready — click to change</span></>:<><span style={{fontSize:34}}>📸</span><span>Click to select photo or video</span><span style={{fontSize:11,opacity:.6}}>JPG, PNG, GIF, MP4, MOV</span></>}
            </button>
          </div>
        ):(
          <div>
            <Inp label="Image / Video URL" placeholder="https://i.imgur.com/example.jpg" value={form.url} onChange={e=>{sf("url",e.target.value);setPreview(e.target.value);}}/>
            <p style={{margin:"5px 0 0",fontSize:11,color:T.muted}}>💡 Upload to <strong>imgur.com</strong> → right-click image → Copy image address</p>
          </div>
        )}
        {preview&&form.type==="photo"&&<div style={{borderRadius:10,overflow:"hidden",border:"1px solid "+T.border}}><img src={preview} style={{width:"100%",height:150,objectFit:"cover",display:"block"}} alt="preview" onError={e=>{e.target.style.display="none";}}/><p style={{margin:0,padding:"5px 10px",fontSize:11,color:T.muted,background:T.cream}}>Preview</p></div>}
        {form.url&&form.type==="video"&&<div style={{padding:"12px",borderRadius:10,background:T.navy+"10",border:"1px solid "+T.navy+"22",display:"flex",gap:10,alignItems:"center"}}><span style={{fontSize:26}}>🎥</span><div><p style={{margin:0,fontSize:13,fontWeight:700,color:T.navy}}>Video ready to post</p><p style={{margin:0,fontSize:11,color:T.muted}}>Playable by all members</p></div></div>}
        <div style={{display:"flex",gap:8}}>
          {[["photo","📷 Photo"],["video","🎥 Video"]].map(([t,l])=><button key={t} onClick={()=>sf("type",t)} style={{flex:1,padding:"8px",borderRadius:8,border:"2px solid "+(form.type===t?T.gold:T.border),background:form.type===t?T.gold+"18":"transparent",color:form.type===t?T.gold:T.muted,cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit"}}>{l}</button>)}
        </div>
        <Inp label="Caption *" placeholder="e.g. Prize distribution at Annual Day 2026" value={form.caption} onChange={e=>sf("caption",e.target.value)}/>
        <Inp label="Event Name" placeholder="e.g. Sports Day, Freshers Party, Hackathon" value={form.event} onChange={e=>sf("event",e.target.value)}/>
        <button onClick={post} style={{padding:"13px",borderRadius:12,background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",color:T.white,border:"none",cursor:"pointer",fontSize:15,fontWeight:800,fontFamily:"inherit"}}>🚀 Post to All Dashboards</button>
        <p style={{margin:0,fontSize:11,color:T.muted,textAlign:"center"}}>Visible instantly to all students and faculty.</p>
      </div>
    </Card>
  );
}

function AuthPage({onLogin}){
  const [mode,setMode]=useState("login");
  const [role,setRole]=useState("student");
  const [form,setForm]=useState({});
  const f=(k,v)=>setForm(p=>({...p,[k]:v}));
  const login=()=>{
    if(role==="admin"){if(form.password==="GECARSIKERE2026"){onLogin({role:"admin",name:"Admin",avatar:"AD"});return;}toast("Wrong admin password","error");return;}
    if(role==="faculty"){const fac=gd().faculty.find(x=>x.email===form.email&&x.password===form.password);if(fac){onLogin({role:"faculty",...fac});return;}toast("Faculty not found. Please register first.","error");return;}
    const stu=gd().students.find(x=>x.usn===form.usn?.toUpperCase()&&x.password===form.password);
    if(!stu){toast("USN or password incorrect","error");return;}
    if(stu.status==="pending"){toast("Account pending admin approval","error");return;}
    onLogin({role:"student",...stu});
  };
  const regStudent=()=>{
    if(!form.name||!form.usn||!form.email||!form.phone||!form.dob||!form.branch||!form.sem||!form.section||!form.password){toast("Fill all required (*) fields","error");return;}
    if(form.password!==form.confirmPassword){toast("Passwords do not match","error");return;}
    const d=gd();
    if(d.students.find(x=>x.usn===form.usn.toUpperCase())||d.pendingStudents.find(x=>x.usn===form.usn.toUpperCase())){toast("USN already registered","error");return;}
    d.pendingStudents.push({...form,usn:form.usn.toUpperCase(),id:Date.now(),status:"pending",avatar:form.name.trim().split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),joinedOn:new Date().toISOString().slice(0,10)});
    sd(d);toast("Registration submitted! Awaiting admin approval.");setMode("login");
  };
  const regFaculty=()=>{
    if(!form.name||!form.email||!form.phone||!form.branch||!form.designation||!form.subjects||!form.password){toast("Fill all required (*) fields","error");return;}
    const d=gd();
    if(d.faculty.find(x=>x.email===form.email)){toast("Email already registered","error");return;}
    d.faculty.push({...form,id:Date.now(),avatar:form.name.trim().split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),joinedOn:new Date().toISOString().slice(0,10)});
    sd(d);toast("Faculty registered!");setMode("login");setRole("faculty");
  };
  const g2={display:"grid",gridTemplateColumns:"1fr 1fr",gap:12};
  const fc={gridColumn:"1/-1"};
  return(
    <div style={{minHeight:"100vh",background:"linear-gradient(145deg,"+T.navy+" 0%,"+T.navyMid+" 55%,"+T.navyLt+" 100%)",display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
      <div style={{position:"fixed",top:-80,left:-80,width:300,height:300,borderRadius:"50%",background:T.gold+"12",pointerEvents:"none"}}/>
      <div style={{position:"fixed",bottom:-100,right:-60,width:400,height:400,borderRadius:"50%",background:T.teal+"10",pointerEvents:"none"}}/>
      <div style={{background:"rgba(255,255,255,0.04)",backdropFilter:"blur(20px)",borderRadius:24,border:"1px solid rgba(255,255,255,0.12)",padding:"28px 32px",width:"100%",maxWidth:500,maxHeight:"94vh",overflowY:"auto"}}>
        <div style={{textAlign:"center",marginBottom:22}}>
          <div style={{width:54,height:54,borderRadius:14,background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,margin:"0 auto 10px"}}>🏛️</div>
          <h1 style={{margin:"0 0 3px",color:T.white,fontSize:20,fontWeight:900,fontFamily:"Georgia,serif"}}>GEC Arsikere</h1>
          <p style={{margin:"0 0 2px",color:T.goldLt,fontSize:13,fontWeight:600}}>Government Engineering College</p>
          <p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:11}}>Arsikere, Hassan District, Karnataka</p>
        </div>
        {mode==="login"&&<>
          <div style={{display:"flex",gap:4,marginBottom:18,background:"rgba(255,255,255,0.06)",padding:4,borderRadius:12}}>
            {["student","faculty","admin"].map(r=><button key={r} onClick={()=>setRole(r)} style={{flex:1,padding:"8px 0",borderRadius:8,border:"none",background:role===r?T.gold:"transparent",color:role===r?T.white:"rgba(255,255,255,0.5)",fontWeight:700,fontSize:12,cursor:"pointer",textTransform:"capitalize",fontFamily:"inherit"}}>{r}</button>)}
          </div>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            {role==="student"&&<DI label="USN *" placeholder="e.g. 4GA22CS001" onChange={e=>f("usn",e.target.value)}/>}
            {role==="faculty"&&<DI label="Email *" placeholder="yourname@gecarsikere.ac.in" onChange={e=>f("email",e.target.value)}/>}
            {role==="admin"&&<div style={{padding:"10px 14px",borderRadius:10,background:"rgba(201,146,42,0.15)",border:"1.5px solid rgba(201,146,42,0.3)",color:T.goldLt,fontSize:13}}>🔑 Enter master admin password below</div>}
            <DI label="Password *" type="password" placeholder="••••••••" onChange={e=>f("password",e.target.value)}/>
            <button onClick={login} style={{padding:"12px",borderRadius:12,background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",color:T.white,border:"none",cursor:"pointer",fontSize:15,fontWeight:800,fontFamily:"inherit"}}>Sign In →</button>
          </div>
          <div style={{marginTop:16,textAlign:"center"}}>
            <p style={{color:"rgba(255,255,255,0.35)",fontSize:12,margin:"0 0 8px"}}>First time here?</p>
            <div style={{display:"flex",gap:8,justifyContent:"center"}}>
              <button onClick={()=>{setMode("register");setForm({});}} style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.15)",color:"rgba(255,255,255,0.7)",padding:"7px 12px",borderRadius:8,cursor:"pointer",fontSize:12,fontFamily:"inherit",fontWeight:600}}>🎓 Student Register</button>
              <button onClick={()=>{setMode("faculty-register");setForm({});}} style={{background:"rgba(255,255,255,0.08)",border:"1px solid rgba(255,255,255,0.15)",color:"rgba(255,255,255,0.7)",padding:"7px 12px",borderRadius:8,cursor:"pointer",fontSize:12,fontFamily:"inherit",fontWeight:600}}>👩‍🏫 Faculty Register</button>
            </div>
          </div>
        </>}
        {mode==="register"&&<>
          <h3 style={{color:T.white,margin:"0 0 14px",fontSize:14,fontWeight:800}}>📋 Student Registration</h3>
          <div style={g2}>
            {[["name","Full Name *","text"],["usn","USN *","text"],["email","Email *","email"],["phone","Phone *","tel"],["dob","Date of Birth *","date"]].map(([k,l,t])=><DI key={k} label={l} type={t} onChange={e=>f(k,e.target.value)}/>)}
            <DS label="Branch *" onChange={e=>f("branch",e.target.value)}><option value="">Select Branch</option>{BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}</DS>
            <DS label="Semester *" onChange={e=>f("sem",e.target.value)}><option value="">Select Semester</option>{SEMS.map(s=><option key={s} value={s}>Sem {s} – {SY[s]}</option>)}</DS>
            <DS label="Section *" onChange={e=>f("section",e.target.value)}><option value="">Select Section</option>{["A","B","C"].map(s=><option key={s} value={s}>Section {s}</option>)}</DS>
            <DI label="Father's Name" onChange={e=>f("fatherName",e.target.value)}/>
            <DI label="Mother's Name" onChange={e=>f("motherName",e.target.value)}/>
            <div style={fc}><DI label="Permanent Address" placeholder="City, District, State" onChange={e=>f("address",e.target.value)}/></div>
            <DI label="Password *" type="password" onChange={e=>f("password",e.target.value)}/>
            <DI label="Confirm Password *" type="password" onChange={e=>f("confirmPassword",e.target.value)}/>
          </div>
          <div style={{display:"flex",gap:10,marginTop:14}}>
            <button onClick={()=>setMode("login")} style={{flex:1,padding:"10px",borderRadius:10,background:"rgba(255,255,255,0.07)",border:"1px solid rgba(255,255,255,0.15)",color:"rgba(255,255,255,0.65)",cursor:"pointer",fontFamily:"inherit",fontWeight:600}}>← Back</button>
            <button onClick={regStudent} style={{flex:2,padding:"10px",borderRadius:10,background:"linear-gradient(135deg,"+T.gold+","+T.goldLt+")",border:"none",color:T.white,cursor:"pointer",fontWeight:800,fontSize:13,fontFamily:"inherit"}}>Submit Registration</button>
          </div>
        </>}
        {mode==="faculty-register"&&<>
          <h3 style={{color:T.white,margin:"0 0 14px",fontSize:14,fontWeight:800}}>👩‍🏫 Faculty Registration</h3>
          <div style={g2}>
            {[["name","Full Name *"],["email","Email *"],["phone","Phone *"],["designation","Designation *"],["qualification","Qualification"],["experience","Years of Experience"]].map(([k,l])=><DI key={k} label={l} onChange={e=>f(k,e.target.value)}/>)}
            <DS label="Branch *" onChange={e=>f("branch",e.target.value)}><option value="">Select Branch</option>{BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}</DS>
            <div style={fc}><DI label="Subjects Teaching * (comma-separated)" placeholder="e.g. Data Structures, DBMS" onChange={e=>f("subjects",e.target.value)}/></div>
            <DI label="Password *" type="password" onChange={e=>f("password",e.target.value)}/>
          </div>
          <div style={{display:"flex",gap:10,marginTop:14}}>
            <button onClick={()=>setMode("login")} style={{flex:1,padding:"10px",borderRadius:10,background:"rgba(255,255,255,0.07)",border:"1px solid rgba(255,255,255,0.15)",color:"rgba(255,255,255,0.65)",cursor:"pointer",fontFamily:"inherit"}}>← Back</button>
            <button onClick={regFaculty} style={{flex:2,padding:"10px",borderRadius:10,background:"linear-gradient(135deg,"+T.teal+","+T.tealLt+")",border:"none",color:T.white,cursor:"pointer",fontWeight:800,fontSize:13,fontFamily:"inherit"}}>Register as Faculty</button>
          </div>
        </>}
      </div>
    </div>
  );
}

function AdminStudents({data,setProfileModal,removeStudent}){
  const [q,setQ]=useState("");const [fb,setFb]=useState("All");const [fs,setFs]=useState("All");
  const all=data.students||[];
  const shown=all.filter(s=>{
    const mq=!q||s.name?.toLowerCase().includes(q.toLowerCase())||s.usn?.toLowerCase().includes(q.toLowerCase());
    return mq&&(fb==="All"||s.branch===fb)&&(fs==="All"||String(s.sem)===String(fs));
  });
  return(<>
    <div style={{display:"flex",gap:12,marginBottom:18,flexWrap:"wrap",alignItems:"flex-end"}}>
      <div style={{flex:1,minWidth:180}}>
        <label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase",display:"block",marginBottom:5}}>Search</label>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Name, USN or email..." style={{width:"100%",padding:"10px 14px",borderRadius:10,border:"1.5px solid "+T.border,fontSize:14,fontFamily:"inherit",outline:"none",background:"#fff",color:T.text,boxSizing:"border-box"}}/>
      </div>
      <Sel label="Branch" value={fb} onChange={e=>setFb(e.target.value)}><option value="All">All Branches</option>{BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}</Sel>
      <Sel label="Semester" value={fs} onChange={e=>setFs(e.target.value)}><option value="All">All Sems</option>{SEMS.map(s=><option key={s} value={s}>Sem {s}</option>)}</Sel>
      <div style={{padding:"10px 14px",borderRadius:10,background:T.navy+"12",border:"1px solid "+T.navy+"20",fontSize:13,fontWeight:700,color:T.navy,alignSelf:"flex-end"}}>{shown.length}/{all.length} students</div>
    </div>
    {!all.length&&<Card style={{textAlign:"center",padding:48}}><p style={{fontSize:36,margin:"0 0 8px"}}>🎓</p><p style={{color:T.muted}}>No approved students yet.</p></Card>}
    {all.length>0&&!shown.length&&<Card style={{textAlign:"center",padding:40}}><p style={{fontSize:28,margin:"0 0 8px"}}>🔍</p><p style={{color:T.muted}}>No students match your filters.</p></Card>}
    {BRANCHES.map(b=>{const bs=shown.filter(s=>s.branch===b);if(!bs.length)return null;return(
      <div key={b} style={{marginBottom:26}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}><div style={{width:10,height:10,borderRadius:"50%",background:BC[b].accent}}/><h3 style={{margin:0,fontSize:15,fontWeight:800,color:T.navy}}>{b} — {bs.length} students</h3></div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
          {bs.map(s=><Card key={s.id} style={{padding:14}}>
            <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:10}}>
              <Av initials={s.avatar} size={38} color={BC[b].accent}/>
              <div style={{flex:1,minWidth:0}}><p style={{margin:0,fontWeight:700,fontSize:13,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.name}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{s.usn}</p><p style={{margin:0,fontSize:11,color:T.muted}}>Sem {s.sem} · Sec {s.section}</p></div>
            </div>
            <div style={{display:"flex",gap:6}}>
              <button onClick={()=>setProfileModal(s)} style={{flex:1,padding:"6px 8px",borderRadius:8,border:"1.5px solid "+T.border,background:"transparent",color:T.navy,cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>👁 Profile</button>
              <button onClick={()=>removeStudent(s.id)} style={{padding:"6px 10px",borderRadius:8,border:"none",background:T.danger+"15",color:T.danger,cursor:"pointer",fontSize:11,fontWeight:700,fontFamily:"inherit"}}>🗑 Remove</button>
            </div>
          </Card>)}
        </div>
      </div>
    );})}
  </>);
}

function AdminPanel({user,onLogout}){
  const [tab,setTab]=useState("overview");
  const [data,setData]=useState(gd);
  const [profileModal,setProfileModal]=useState(null);
  const [ann,setAnn]=useState({title:"",body:"",type:"general",branch:"All",pinned:false});
  const R=()=>setData(gd());
  const approve=(id)=>{const d=gd();const s=d.pendingStudents.find(x=>x.id===id);if(!s)return;s.status="approved";d.students.push(s);d.pendingStudents=d.pendingStudents.filter(x=>x.id!==id);sd(d);R();toast(s.name+" approved!");};
  const reject=(id)=>{const d=gd();const s=d.pendingStudents.find(x=>x.id===id);d.pendingStudents=d.pendingStudents.filter(x=>x.id!==id);sd(d);R();toast((s?.name||"Student")+" rejected","error");};
  const removeStudent=(id)=>{if(!window.confirm("Remove this student permanently?"))return;const d=gd();const s=d.students.find(x=>x.id===id);d.students=d.students.filter(x=>x.id!==id);sd(d);R();toast((s?.name||"Student")+" removed","error");};
  const removeFaculty=(id)=>{if(!window.confirm("Remove this faculty?"))return;const d=gd();const f=d.faculty.find(x=>x.id===id);d.faculty=d.faculty.filter(x=>x.id!==id);sd(d);R();toast((f?.name||"Faculty")+" removed","error");};
  const deleteAnn=(id)=>{if(!window.confirm("Delete this announcement?"))return;const d=gd();d.announcements=d.announcements.filter(x=>x.id!==id);sd(d);R();toast("Announcement deleted","error");};
  const postAnn=()=>{if(!ann.title.trim()){toast("Title required","error");return;}const d=gd();d.announcements.unshift({...ann,id:Date.now(),author:"Admin",date:new Date().toISOString().slice(0,10)});sd(d);R();setAnn({title:"",body:"",type:"general",branch:"All",pinned:false});toast("Announcement posted!");};
  const postMedia=(item)=>{const d=gd();if(!d.media)d.media=[];d.media.unshift({...item,id:Date.now(),date:new Date().toISOString().slice(0,10),postedBy:"Admin"});sd(d);R();};
  const deleteMedia=(id)=>{if(!window.confirm("Remove this media?"))return;const d=gd();d.media=(d.media||[]).filter(x=>x.id!==id);sd(d);R();toast("Media removed","error");};
  const TABS=[["overview","📊 Overview"],["pending","⏳ Pending ("+(data.pendingStudents?.length||0)+")"],["students","🎓 Students"],["faculty","👩‍🏫 Faculty"],["announce","📢 Announcements"],["media","🖼️ Event Media"]];
  return(
    <div style={{minHeight:"100vh",display:"flex",fontFamily:"'Segoe UI',Georgia,sans-serif",background:T.cream}}>
      <Sidebar tabs={TABS} active={tab} onSelect={setTab} user={{name:"Admin",avatar:"AD",branch:""}} onLogout={onLogout} role="admin"/>
      <div style={{flex:1,padding:"22px 26px",overflowY:"auto"}}>
        {profileModal&&<StudentProfileModal student={profileModal} onClose={()=>setProfileModal(null)}/>}
        {tab==="overview"&&<>
          <ST sub="Government Engineering College, Arsikere — Admin Control Centre">Admin Dashboard</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:22}}>
            {[["Total Students",data.students?.length||0,"🎓",T.info],["Pending",data.pendingStudents?.length||0,"⏳",T.warn],["Faculty",data.faculty?.length||0,"👩‍🏫",T.teal],["Announcements",data.announcements?.length||0,"📢",T.gold]].map(([l,v,ic,c])=><Card key={l} style={{textAlign:"center",borderTop:"3px solid "+c}}><p style={{fontSize:24,margin:"0 0 4px"}}>{ic}</p><p style={{margin:0,fontSize:28,fontWeight:900,color:c}}>{v}</p><p style={{margin:"3px 0 0",fontSize:12,color:T.muted,fontWeight:600}}>{l}</p></Card>)}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:22}}>
            {BRANCHES.map(b=>{const cnt=(data.students||[]).filter(s=>s.branch===b).length;return<div key={b} style={{borderRadius:16,padding:16,background:BC[b].bg,border:"1px solid "+BC[b].accent+"33"}}><p style={{margin:"0 0 4px",color:BC[b].accent,fontWeight:800,fontSize:16,fontFamily:"Georgia,serif"}}>{b}</p><p style={{margin:"0 0 8px",color:"rgba(255,255,255,0.45)",fontSize:12}}>Department</p><p style={{margin:0,color:T.white,fontSize:26,fontWeight:900}}>{cnt}</p><p style={{margin:0,color:"rgba(255,255,255,0.45)",fontSize:12}}>students</p></div>;})}
          </div>
          <Card><h3 style={{margin:"0 0 14px",fontSize:15,fontWeight:800,color:T.navy}}>🎉 Recent Event Media</h3><MediaGallery media={(data.media||[]).slice(0,6)}/></Card>
        </>}
        {tab==="pending"&&<>
          <ST sub="Approve or reject student registrations">Pending Approvals</ST>
          {!data.pendingStudents?.length?<Card style={{textAlign:"center",padding:48}}><p style={{fontSize:40,margin:"0 0 8px"}}>✅</p><p style={{color:T.muted}}>All caught up!</p></Card>
          :data.pendingStudents.map(s=><Card key={s.id} style={{marginBottom:12}}>
            <div style={{display:"flex",alignItems:"center",gap:12}}>
              <Av initials={s.avatar} size={44} color={BC[s.branch]?.accent||T.gold}/>
              <div style={{flex:1}}>
                <div style={{display:"flex",gap:8,alignItems:"center",marginBottom:4,flexWrap:"wrap"}}><p style={{margin:0,fontWeight:800,fontSize:14,color:T.text}}>{s.name}</p><Badge text={s.branch} type="info"/><Badge text={"Sem "+s.sem} type="neutral"/><Badge text={"Sec "+s.section} type="neutral"/></div>
                <p style={{margin:0,fontSize:12,color:T.muted}}>{s.usn} · {s.email} · {s.phone}</p>
              </div>
              <div style={{display:"flex",gap:8,flexShrink:0}}>
                <Btn onClick={()=>setProfileModal(s)} variant="outline" style={{fontSize:12,padding:"7px 12px"}}>👁 View</Btn>
                <Btn onClick={()=>approve(s.id)} variant="teal" style={{fontSize:12,padding:"7px 12px"}}>✓ Approve</Btn>
                <Btn onClick={()=>reject(s.id)} variant="danger" style={{fontSize:12,padding:"7px 12px"}}>✗ Reject</Btn>
              </div>
            </div>
          </Card>)}
        </>}
        {tab==="students"&&<><ST sub={(data.students?.length||0)+" approved students"}>All Students</ST><AdminStudents data={data} setProfileModal={setProfileModal} removeStudent={removeStudent}/></>}
        {tab==="faculty"&&<>
          <ST sub={(data.faculty?.length||0)+" registered faculty"}>Faculty Directory</ST>
          {BRANCHES.map(b=>{const bf=(data.faculty||[]).filter(f=>f.branch===b);if(!bf.length)return null;return<div key={b} style={{marginBottom:22}}>
            <h3 style={{margin:"0 0 10px",fontSize:15,fontWeight:800,color:T.navy}}>{b} — {bf.length} faculty</h3>
            <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:12}}>
              {bf.map(f=><Card key={f.id} style={{padding:14}}><div style={{display:"flex",gap:12,alignItems:"flex-start"}}><Av initials={f.avatar} size={44} color={T.teal}/><div style={{flex:1}}><p style={{margin:"0 0 2px",fontWeight:800,fontSize:14,color:T.text}}>{f.name}</p><p style={{margin:"0 0 1px",fontSize:12,color:T.muted}}>{f.designation}{f.qualification?" · "+f.qualification:""}</p><p style={{margin:"0 0 1px",fontSize:12,color:T.info}}>{f.email}</p><p style={{margin:"4px 0 0",fontSize:12,color:T.muted}}>Subjects: {f.subjects}</p></div><button onClick={()=>removeFaculty(f.id)} style={{background:"none",border:"none",cursor:"pointer",color:T.danger,fontSize:18,padding:4}}>🗑</button></div></Card>)}
            </div>
          </div>;})}
          {!data.faculty?.length&&<Card style={{textAlign:"center",padding:40}}><p style={{color:T.muted}}>No faculty registered yet.</p></Card>}
        </>}
        {tab==="announce"&&<div style={{display:"grid",gridTemplateColumns:"1fr 360px",gap:20}}>
          <div>
            <ST>All Announcements</ST>
            {(data.announcements||[]).map(a=><Card key={a.id} style={{marginBottom:12}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:10}}>
                <div style={{flex:1}}><div style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}><Badge text={a.type} type={a.type==="exam"?"warning":a.type==="event"?"info":"neutral"}/><Badge text={a.branch} type="neutral"/>{a.pinned&&<Badge text="📌 Pinned" type="gold"/>}</div><p style={{margin:"0 0 4px",fontWeight:700,color:T.text,fontSize:14}}>{a.title}</p><p style={{margin:"0 0 6px",fontSize:13,color:T.text,lineHeight:1.5}}>{a.body}</p><p style={{margin:0,fontSize:12,color:T.muted}}>{a.author} · {a.date}</p></div>
                <button onClick={()=>deleteAnn(a.id)} style={{background:"none",border:"none",cursor:"pointer",color:T.danger,fontSize:18,padding:"0 0 0 8px",flexShrink:0}}>🗑</button>
              </div>
            </Card>)}
          </div>
          <div style={{position:"sticky",top:0,height:"fit-content"}}>
            <Card>
              <ST>Post Announcement</ST>
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                <Inp label="Title *" value={ann.title} onChange={e=>setAnn(p=>({...p,title:e.target.value}))} placeholder="Announcement title..."/>
                <div style={{display:"flex",flexDirection:"column",gap:5}}><label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase"}}>Body</label><textarea value={ann.body} onChange={e=>setAnn(p=>({...p,body:e.target.value}))} rows={4} placeholder="Write details here..." style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid "+T.border,fontSize:14,fontFamily:"inherit",resize:"vertical",outline:"none",color:T.text}}/></div>
                <Sel label="Type" value={ann.type} onChange={e=>setAnn(p=>({...p,type:e.target.value}))}><option value="general">📣 General</option><option value="exam">📝 Exam</option><option value="event">🎉 Event</option></Sel>
                <Sel label="For Branch" value={ann.branch} onChange={e=>setAnn(p=>({...p,branch:e.target.value}))}><option value="All">All Branches</option>{BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}</Sel>
                <label style={{display:"flex",alignItems:"center",gap:10,cursor:"pointer"}}><input type="checkbox" checked={ann.pinned} onChange={e=>setAnn(p=>({...p,pinned:e.target.checked}))} style={{width:16,height:16,accentColor:T.gold}}/><span style={{fontSize:13,color:T.text,fontWeight:600}}>📌 Pin this announcement</span></label>
                <Btn onClick={postAnn} variant="gold" style={{width:"100%",padding:"12px"}}>📢 Post Announcement</Btn>
              </div>
            </Card>
          </div>
        </div>}
        {tab==="media"&&<div style={{display:"grid",gridTemplateColumns:"1fr 380px",gap:20}}>
          <div>
            <ST sub="Visible to all students and faculty on their dashboards">Event Media Gallery</ST>
            <MediaGallery media={data.media||[]}/>
            {(data.media||[]).length>0&&<div style={{marginTop:18}}>
              <h3 style={{margin:"0 0 10px",fontSize:14,fontWeight:800,color:T.navy}}>Manage Media</h3>
              {(data.media||[]).map(m=><div key={m.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 14px",borderRadius:10,background:T.white,border:"1px solid "+T.border,marginBottom:8}}>
                <div style={{width:44,height:44,borderRadius:8,overflow:"hidden",flexShrink:0,background:"#1a1a2e",display:"flex",alignItems:"center",justifyContent:"center"}}>{m.type==="video"?<span style={{fontSize:20}}>🎥</span>:<img src={m.url} style={{width:"100%",height:"100%",objectFit:"cover"}} alt="" onError={e=>{e.target.style.display="none";}}/>}</div>
                <div style={{flex:1,minWidth:0}}><p style={{margin:0,fontSize:13,fontWeight:700,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{m.caption||"(No caption)"}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{m.event||"—"} · {m.date}</p></div>
                <button onClick={()=>deleteMedia(m.id)} style={{background:T.danger+"15",border:"none",cursor:"pointer",color:T.danger,fontSize:12,fontWeight:700,padding:"6px 10px",borderRadius:8,fontFamily:"inherit"}}>🗑 Delete</button>
              </div>)}
            </div>}
          </div>
          <div style={{position:"sticky",top:0,height:"fit-content"}}><AdminMediaUpload onPost={postMedia}/></div>
        </div>}
      </div>
    </div>
  );
}

function FacultyDash({user:init,onLogout}){
  const [tab,setTab]=useState("home");
  const [data,setData]=useState(gd);
  const [lu,setLu]=useState(init);
  const [profileModal,setProfileModal]=useState(null);
  const [editP,setEditP]=useState(false);
  const [pf,setPf]=useState({...init,newPassword:""});
  const [asgn,setAsgn]=useState({title:"",subject:"",dueDate:"",branch:init.branch,sem:"",description:""});
  const [attF,setAttF]=useState({branch:init.branch,sem:"",subject:"",date:new Date().toISOString().slice(0,10)});
  const [marked,setMarked]=useState({});
  const R=()=>setData(gd());
  const user=lu;
  const myStudents=(data.students||[]).filter(s=>s.branch===user.branch);
  const filtStu=attF.sem?myStudents.filter(s=>String(s.sem)===String(attF.sem)):myStudents;
  const myAsgns=(data.assignments||[]).filter(a=>a.branch===user.branch);
  const allSemSubs=attF.branch&&attF.sem?BS[attF.branch]?.[parseInt(attF.sem)]||[]:[];
  const mySubList=(user.subjects||"").split(",").map(s=>s.trim()).filter(Boolean);
  const isMySub=(s)=>mySubList.some(ms=>s.toLowerCase().includes(ms.toLowerCase())||ms.toLowerCase().includes(s.toLowerCase()));
  const bc=BC[user.branch]||BC.CSE;
  const saveP=()=>{
    if(!pf.name?.trim()){toast("Name cannot be empty","error");return;}
    const d=gd();const idx=d.faculty.findIndex(x=>x.id===user.id);
    if(idx>=0){const up={...d.faculty[idx],...pf};if(pf.newPassword?.trim())up.password=pf.newPassword.trim();delete up.newPassword;delete up.confirmNewPassword;d.faculty[idx]=up;sd(d);R();setLu(up);setPf({...up,newPassword:""});setEditP(false);toast("Profile updated!");}
  };
  const postAsgn=()=>{
    if(!asgn.title||!asgn.dueDate||!asgn.sem){toast("Fill title, due date and semester","error");return;}
    const d=gd();d.assignments.push({...asgn,id:Date.now(),postedBy:user.name,postedOn:new Date().toISOString().slice(0,10)});sd(d);R();setAsgn({title:"",subject:"",dueDate:"",branch:user.branch,sem:"",description:""});toast("Assignment posted!");
  };
  const saveAtt=()=>{
    if(!attF.subject||!attF.sem){toast("Select semester and subject","error");return;}
    if(!Object.keys(marked).length){toast("Mark at least one student","error");return;}
    const d=gd();if(!d.attendance)d.attendance={};
    Object.entries(marked).forEach(([sid,status])=>{d.attendance[sid+"_"+attF.subject+"_"+attF.date]=status;});
    sd(d);R();setMarked({});toast("Attendance saved for "+Object.keys(marked).length+" students!");
  };
  const TABS=[["home","🏠 Home"],["students","🎓 My Students"],["attendance","📅 Mark Attendance"],["assignments","📝 Assignments"],["announce","📢 Notices"],["profile","⚙️ My Profile"]];
  return(
    <div style={{minHeight:"100vh",display:"flex",fontFamily:"'Segoe UI',Georgia,sans-serif",background:T.cream}}>
      <Sidebar tabs={TABS} active={tab} onSelect={setTab} user={user} onLogout={onLogout} role="faculty"/>
      <div style={{flex:1,padding:"22px 26px",overflowY:"auto"}}>
        {profileModal&&<StudentProfileModal student={profileModal} onClose={()=>setProfileModal(null)}/>}
        {tab==="home"&&<>
          <div style={{borderRadius:18,padding:"22px 26px",background:"linear-gradient(135deg,"+T.navyLt+","+T.navy+")",color:T.white,marginBottom:20,position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:-30,right:-30,width:140,height:140,borderRadius:"50%",background:T.teal+"20"}}/>
            <p style={{margin:"0 0 4px",opacity:.5,fontSize:12,textTransform:"uppercase",letterSpacing:1}}>Faculty Dashboard</p>
            <h1 style={{margin:"0 0 6px",fontSize:21,fontWeight:900,fontFamily:"Georgia,serif"}}>Welcome, {(user.name||"Faculty").split(" ").slice(-1)[0]}! 👋</h1>
            <p style={{margin:0,opacity:.65,fontSize:13}}>{user.designation||"Faculty"} · {user.branch} Dept · GEC Arsikere</p>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14,marginBottom:20}}>
            <Card style={{borderTop:"3px solid "+bc.accent}}><p style={{margin:"0 0 3px",color:T.muted,fontSize:12,fontWeight:600}}>My Students</p><p style={{margin:0,fontSize:26,fontWeight:900,color:bc.accent}}>{myStudents.length}</p></Card>
            <Card style={{borderTop:"3px solid "+T.gold}}><p style={{margin:"0 0 3px",color:T.muted,fontSize:12,fontWeight:600}}>Assignments Posted</p><p style={{margin:0,fontSize:26,fontWeight:900,color:T.gold}}>{myAsgns.length}</p></Card>
            <Card style={{borderTop:"3px solid "+T.teal}}><p style={{margin:"0 0 3px",color:T.muted,fontSize:12,fontWeight:600}}>Subjects</p><p style={{margin:0,fontSize:13,fontWeight:700,color:T.teal,lineHeight:1.5}}>{user.subjects||"—"}</p></Card>
          </div>
          <Card><h3 style={{margin:"0 0 12px",fontSize:14,fontWeight:800,color:T.navy}}>🎉 College Event Gallery</h3><MediaGallery media={(data.media||[]).slice(0,6)}/></Card>
        </>}
        {tab==="students"&&<>
          <ST sub={myStudents.length+" students in "+user.branch}>My Students</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
            {myStudents.map(s=><Card key={s.id} style={{padding:14}}>
              <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:10}}><Av initials={s.avatar} size={36} color={bc.accent}/><div style={{flex:1,minWidth:0}}><p style={{margin:0,fontWeight:700,fontSize:13,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.name}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{s.usn} · Sem {s.sem}{s.section}</p></div></div>
              <Btn onClick={()=>setProfileModal(s)} variant="outline" style={{width:"100%",fontSize:11,padding:"7px"}}>👁 View Profile & Attendance</Btn>
            </Card>)}
            {!myStudents.length&&<Card style={{gridColumn:"1/-1",textAlign:"center",padding:40}}><p style={{color:T.muted}}>No students registered in {user.branch} yet.</p></Card>}
          </div>
        </>}
        {tab==="attendance"&&<div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:20}}>
          <div>
            <ST sub="Select your subject and mark — students see % instantly">Mark Attendance</ST>
            <Card style={{marginBottom:14}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
                <Sel label="Branch" value={attF.branch} onChange={e=>setAttF(p=>({...p,branch:e.target.value,subject:""}))}>
                  {BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}
                </Sel>
                <Sel label="Semester" value={attF.sem} onChange={e=>setAttF(p=>({...p,sem:e.target.value,subject:""}))}>
                  <option value="">Select Semester</option>{SEMS.map(s=><option key={s} value={s}>Sem {s} — {SY[s]}</option>)}
                </Sel>
                <div style={{gridColumn:"1/-1",display:"flex",flexDirection:"column",gap:5}}>
                  <label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase"}}>Subject</label>
                  <select value={attF.subject} onChange={e=>setAttF(p=>({...p,subject:e.target.value}))} disabled={!attF.sem} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid "+(attF.subject?T.teal:T.border),fontSize:14,fontFamily:"inherit",outline:"none",background:"#fff",color:"#1a2340",cursor:"pointer"}}>
                    <option value="">— Select Subject —</option>
                    {allSemSubs.map(s=><option key={s} value={s}>{isMySub(s)?"★ ":""}{s}{isMySub(s)?" (My Subject)":""}</option>)}
                  </select>
                  {attF.subject&&<p style={{margin:"4px 0 0",fontSize:12,fontWeight:600,color:isMySub(attF.subject)?T.success:T.warn}}>{isMySub(attF.subject)?"✓ This is one of your subjects":"⚠ Not in your subject list (can still mark)"}</p>}
                </div>
                <Inp label="Date" type="date" value={attF.date} onChange={e=>setAttF(p=>({...p,date:e.target.value}))}/>
                <div style={{display:"flex",alignItems:"flex-end"}}>{attF.subject&&<div style={{padding:"8px 12px",borderRadius:10,background:T.teal+"15",border:"1px solid "+T.teal+"33",fontSize:12,color:T.teal,fontWeight:700}}>📚 {filtStu.length} students</div>}</div>
              </div>
              {attF.subject&&attF.sem&&<>
                <div style={{display:"flex",gap:8,marginBottom:12}}>
                  <Btn onClick={()=>{const m={};filtStu.forEach(s=>{m[s.id]="present";});setMarked(m);}} variant="teal" style={{fontSize:12,padding:"7px 14px"}}>✓ All Present</Btn>
                  <Btn onClick={()=>{const m={};filtStu.forEach(s=>{m[s.id]="absent";});setMarked(m);}} variant="danger" style={{fontSize:12,padding:"7px 14px"}}>✗ All Absent</Btn>
                  <Btn onClick={()=>setMarked({})} variant="outline" style={{fontSize:12,padding:"7px 14px"}}>↺ Clear</Btn>
                  <span style={{marginLeft:"auto",fontSize:12,color:T.muted,alignSelf:"center"}}>{Object.keys(marked).length}/{filtStu.length} marked</span>
                </div>
                {filtStu.map(s=>{
                  const prev=calcAtt(s.id,s.branch,s.sem).find(a=>a.sub===attF.subject);
                  return<div key={s.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:10,background:marked[s.id]==="present"?T.success+"0d":marked[s.id]==="absent"?T.danger+"0d":T.cream,border:"1px solid "+(marked[s.id]==="present"?T.success+"44":marked[s.id]==="absent"?T.danger+"44":T.border),marginBottom:6}}>
                    <Av initials={s.avatar} size={32} color={bc.accent}/>
                    <div style={{flex:1}}><p style={{margin:0,fontSize:13,fontWeight:700,color:T.text}}>{s.name}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{s.usn}</p></div>
                    {prev&&prev.pct!==null&&<div style={{textAlign:"center",marginRight:6}}><p style={{margin:0,fontSize:10,color:T.muted}}>Current</p><p style={{margin:0,fontSize:13,fontWeight:800,color:prev.pct>=75?T.success:T.danger}}>{prev.pct}%</p></div>}
                    <div style={{display:"flex",gap:6}}>
                      <button onClick={()=>setMarked(p=>({...p,[s.id]:"present"}))} style={{padding:"6px 14px",borderRadius:8,border:"2px solid "+(marked[s.id]==="present"?T.success:T.border),background:marked[s.id]==="present"?T.success:"transparent",color:marked[s.id]==="present"?T.white:T.muted,cursor:"pointer",fontWeight:700,fontSize:12}}>✓ P</button>
                      <button onClick={()=>setMarked(p=>({...p,[s.id]:"absent"}))} style={{padding:"6px 14px",borderRadius:8,border:"2px solid "+(marked[s.id]==="absent"?T.danger:T.border),background:marked[s.id]==="absent"?T.danger:"transparent",color:marked[s.id]==="absent"?T.white:T.muted,cursor:"pointer",fontWeight:700,fontSize:12}}>✗ A</button>
                    </div>
                  </div>;
                })}
                {filtStu.length>0&&<Btn onClick={saveAtt} variant="gold" style={{width:"100%",marginTop:12,padding:"12px"}}>💾 Save Attendance for {attF.subject}</Btn>}
                {!filtStu.length&&<p style={{color:T.muted,fontSize:13,textAlign:"center",padding:"16px 0"}}>No students for {attF.branch} Sem {attF.sem}.</p>}
              </>}
              {(!attF.subject||!attF.sem)&&<div style={{textAlign:"center",padding:"20px 0"}}><p style={{fontSize:28,margin:"0 0 6px"}}>📅</p><p style={{color:T.muted,fontSize:13,margin:0}}>Select branch, semester and subject to begin</p></div>}
            </Card>
          </div>
          <Card style={{height:"fit-content",position:"sticky",top:0}}>
            <h3 style={{margin:"0 0 4px",fontSize:14,fontWeight:800,color:T.navy}}>📊 Class Summary</h3>
            <p style={{margin:"0 0 12px",fontSize:12,color:T.muted}}>Click to view full breakdown</p>
            <div style={{display:"flex",flexDirection:"column",gap:8,maxHeight:440,overflowY:"auto"}}>
              {myStudents.map(s=>{const att=calcAtt(s.id,s.branch,s.sem);const valid=att.filter(x=>x.pct!==null);const ov=valid.length?Math.round(valid.reduce((a,x)=>a+x.pct,0)/valid.length):null;return(
                <div key={s.id} onClick={()=>setProfileModal(s)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:10,background:T.cream,border:"1px solid "+T.border,cursor:"pointer"}} onMouseEnter={e=>e.currentTarget.style.boxShadow="0 2px 8px rgba(0,0,0,0.08)"} onMouseLeave={e=>e.currentTarget.style.boxShadow=""}>
                  <Av initials={s.avatar} size={28} color={ov===null?T.muted:ov>=75?T.success:T.danger}/>
                  <div style={{flex:1,minWidth:0}}><p style={{margin:0,fontSize:12,fontWeight:700,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.name}</p><p style={{margin:0,fontSize:10,color:T.muted}}>{s.usn}</p></div>
                  <p style={{margin:0,fontSize:14,fontWeight:900,color:ov===null?T.muted:ov>=75?T.success:T.danger}}>{ov===null?"—":ov+"%"}</p>
                </div>
              );})}
              {!myStudents.length&&<p style={{color:T.muted,fontSize:12,textAlign:"center",padding:"12px 0"}}>No students yet.</p>}
            </div>
          </Card>
        </div>}
        {tab==="assignments"&&<div style={{display:"grid",gridTemplateColumns:"1fr 340px",gap:20}}>
          <div>
            <ST>Posted Assignments</ST>
            {!myAsgns.length?<Card style={{textAlign:"center",padding:40}}><p style={{fontSize:34}}>📋</p><p style={{color:T.muted}}>No assignments yet.</p></Card>
            :myAsgns.map(a=><Card key={a.id} style={{marginBottom:12}}>
              <p style={{margin:"0 0 6px",fontWeight:800,fontSize:14,color:T.text}}>{a.title}</p>
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:6}}>{a.subject&&<Badge text={a.subject} type="info"/>}<Badge text={a.branch+" · Sem "+a.sem} type="neutral"/><Badge text={"Due: "+a.dueDate} type="warning"/></div>
              {a.description&&<p style={{margin:"0 0 6px",fontSize:13,color:T.text}}>{a.description}</p>}
              <p style={{margin:0,fontSize:12,color:T.muted}}>By {a.postedBy} · {a.postedOn}</p>
            </Card>)}
          </div>
          <Card style={{height:"fit-content"}}>
            <ST>Post Assignment</ST>
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              <Inp label="Title *" value={asgn.title} onChange={e=>setAsgn(p=>({...p,title:e.target.value}))}/>
              <Sel label="Branch" value={asgn.branch} onChange={e=>setAsgn(p=>({...p,branch:e.target.value,sem:"",subject:""}))}>
                {BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}
              </Sel>
              <Sel label="Semester *" value={asgn.sem} onChange={e=>setAsgn(p=>({...p,sem:e.target.value,subject:""}))}>
                <option value="">Select Semester</option>{SEMS.map(s=><option key={s} value={s}>Sem {s}</option>)}
              </Sel>
              {asgn.sem&&<Sel label="Subject" value={asgn.subject} onChange={e=>setAsgn(p=>({...p,subject:e.target.value}))}>
                <option value="">Select Subject</option>
                {(BS[asgn.branch]?.[parseInt(asgn.sem)]||[]).map(s=><option key={s} value={s}>{isMySub(s)?"★ ":""}{s}</option>)}
              </Sel>}
              <Inp label="Due Date *" type="date" value={asgn.dueDate} onChange={e=>setAsgn(p=>({...p,dueDate:e.target.value}))}/>
              <div style={{display:"flex",flexDirection:"column",gap:5}}><label style={{fontSize:12,fontWeight:700,color:T.muted,letterSpacing:.5,textTransform:"uppercase"}}>Description</label><textarea value={asgn.description} onChange={e=>setAsgn(p=>({...p,description:e.target.value}))} rows={3} style={{padding:"10px 14px",borderRadius:10,border:"1.5px solid "+T.border,fontSize:14,fontFamily:"inherit",resize:"vertical",outline:"none",color:T.text}}/></div>
              <Btn onClick={postAsgn} variant="teal" style={{width:"100%",padding:"12px"}}>📝 Post Assignment</Btn>
            </div>
          </Card>
        </div>}
        {tab==="announce"&&<>
          <ST>College Announcements</ST>
          {(data.announcements||[]).filter(a=>a.branch==="All"||a.branch===user.branch).map(a=><Card key={a.id} style={{marginBottom:12,borderLeft:a.pinned?"4px solid "+T.gold:"1px solid "+T.border}}>
            <div style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}><Badge text={a.type} type={a.type==="exam"?"warning":a.type==="event"?"info":"neutral"}/><Badge text={a.branch} type="neutral"/>{a.pinned&&<Badge text="📌 Pinned" type="gold"/>}</div>
            <p style={{margin:"0 0 4px",fontWeight:700,color:T.text,fontSize:14}}>{a.title}</p>
            <p style={{margin:"0 0 6px",fontSize:13,color:T.text,lineHeight:1.5}}>{a.body}</p>
            <p style={{margin:0,fontSize:12,color:T.muted}}>{a.author} · {a.date}</p>
          </Card>)}
        </>}
        {tab==="profile"&&<div style={{maxWidth:600}}>
          <ST sub="Update your information and settings">My Profile</ST>
          <Card>
            <div style={{display:"flex",gap:16,alignItems:"center",marginBottom:20,paddingBottom:16,borderBottom:"1px solid "+T.border}}>
              <Av initials={user.avatar} size={62} color={T.teal}/>
              <div style={{flex:1}}>
                <h2 style={{margin:"0 0 4px",fontSize:19,fontWeight:900,color:T.navy,fontFamily:"Georgia,serif"}}>{user.name}</h2>
                <p style={{margin:"0 0 6px",color:T.muted,fontSize:13}}>{user.designation||"Faculty"} · {user.branch}</p>
                <Badge text="✓ Verified Faculty" type="teal"/>
              </div>
              {!editP&&<Btn onClick={()=>setEditP(true)} variant="outline" style={{fontSize:12,padding:"7px 14px"}}>✏️ Edit</Btn>}
            </div>
            {editP?(
              <div>
                <div style={{background:T.cream,borderRadius:10,padding:"10px 14px",marginBottom:14,border:"1px solid "+T.border}}><p style={{margin:0,fontSize:12,color:T.warn,fontWeight:700}}>✏️ Editing — save when done</p></div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12,marginBottom:14}}>
                  <Inp label="Full Name *" value={pf.name||""} onChange={e=>setPf(p=>({...p,name:e.target.value}))}/>
                  <Inp label="Email" value={pf.email||""} onChange={e=>setPf(p=>({...p,email:e.target.value}))}/>
                  <Inp label="Phone" value={pf.phone||""} onChange={e=>setPf(p=>({...p,phone:e.target.value}))}/>
                  <Inp label="Designation" value={pf.designation||""} onChange={e=>setPf(p=>({...p,designation:e.target.value}))}/>
                  <Inp label="Qualification" value={pf.qualification||""} onChange={e=>setPf(p=>({...p,qualification:e.target.value}))}/>
                  <Inp label="Experience (years)" value={pf.experience||""} onChange={e=>setPf(p=>({...p,experience:e.target.value}))}/>
                  <Sel label="Branch" value={pf.branch||""} onChange={e=>setPf(p=>({...p,branch:e.target.value}))}>{BRANCHES.map(b=><option key={b} value={b}>{b}</option>)}</Sel>
                  <div/>
                  <div style={{gridColumn:"1/-1"}}><Inp label="Subjects Teaching (comma-separated)" value={pf.subjects||""} onChange={e=>setPf(p=>({...p,subjects:e.target.value}))} placeholder="e.g. Data Structures, DBMS"/></div>
                  <div style={{gridColumn:"1/-1",padding:"12px 14px",borderRadius:10,background:"#fff7ed",border:"1px solid "+T.warn+"44"}}>
                    <p style={{margin:"0 0 10px",fontSize:13,fontWeight:700,color:T.warn}}>🔑 Change Password (optional)</p>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
                      <Inp label="New Password" type="password" placeholder="Leave blank to keep current" value={pf.newPassword||""} onChange={e=>setPf(p=>({...p,newPassword:e.target.value}))}/>
                      <Inp label="Confirm Password" type="password" placeholder="Re-enter new password" onChange={e=>setPf(p=>({...p,confirmNewPassword:e.target.value}))}/>
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",gap:10}}>
                  <Btn onClick={saveP} variant="gold" style={{flex:2,padding:"12px"}}>💾 Save All Changes</Btn>
                  <Btn onClick={()=>{setEditP(false);setPf({...user,newPassword:""}); }} variant="outline" style={{flex:1}}>✕ Cancel</Btn>
                </div>
              </div>
            ):(
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                {[["📧 Email",user.email],["📱 Phone",user.phone],["🎓 Qualification",user.qualification],["💼 Designation",user.designation],["⏱ Experience",user.experience?user.experience+" years":null],["📚 Subjects",user.subjects],["🏛 Branch",user.branch],["📅 Joined",user.joinedOn]].map(([k,v])=>v?<div key={k} style={{padding:"10px 12px",borderRadius:10,background:T.cream,border:"1px solid "+T.border}}><p style={{margin:"0 0 2px",fontSize:11,color:T.muted,fontWeight:700,textTransform:"uppercase",letterSpacing:.4}}>{k}</p><p style={{margin:0,fontSize:13,fontWeight:600,color:T.text}}>{v}</p></div>:null)}
              </div>
            )}
          </Card>
        </div>}
      </div>
    </div>
  );
}

function StudentDash({user,onLogout}){
  const [tab,setTab]=useState("home");
  const [data,setData]=useState(gd);
  const [chatTarget,setCT]=useState(null);
  const [chatText,setCTxt]=useState("");
  const [chatLoad,setCL]=useState(false);
  const [grpText,setGT]=useState("");
  const [grpLoad,setGL]=useState(false);
  const [activeGrp,setAG]=useState(user.branch);
  const chatBR=useRef(null);
  const grpBR=useRef(null);
  const fileRef=useRef(null);
  const R=()=>setData(gd());
  const subs=BS[user.branch]?.[parseInt(user.sem)]||[];
  const anns=(data.announcements||[]).filter(a=>a.branch==="All"||a.branch===user.branch);
  const fac=(data.faculty||[]).filter(f=>f.branch===user.branch);
  const attData=calcAtt(user.id,user.branch,user.sem);
  const validAtt=attData.filter(x=>x.pct!==null);
  const overallAtt=validAtt.length?Math.round(validAtt.reduce((a,x)=>a+x.pct,0)/validAtt.length):null;
  const bc=BC[user.branch]||BC.CSE;
  const chatKey=chatTarget?"fac_"+chatTarget.id+"_stu_"+user.id:null;
  const chatMsgs=chatKey?(data.messages||{})[chatKey]||[]:[];
  useEffect(()=>{chatBR.current?.scrollIntoView({behavior:"smooth"});},[chatMsgs]);
  const grpMsgs=(data.groupMsgs||{})[activeGrp]||[];
  useEffect(()=>{grpBR.current?.scrollIntoView({behavior:"smooth"});},[grpMsgs]);
  const sendChat=async()=>{
    if(!chatText.trim()||!chatTarget)return;
    const msg={from:"student",text:chatText,time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})};
    const d=gd();if(!d.messages)d.messages={};d.messages[chatKey]=[...(d.messages[chatKey]||[]),msg];sd(d);R();setCTxt("");setCL(true);
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:800,system:"You are "+chatTarget.name+", a "+( chatTarget.designation||"professor")+" at GEC Arsikere teaching "+chatTarget.subjects+". Reply as a warm helpful professor to a student. 2-3 sentences.",messages:[...(d.messages[chatKey]||[])].map(m=>({role:m.from==="student"?"user":"assistant",content:m.text}))})});const r=await res.json();const rep=r.content?.[0]?.text||"I will respond soon.";const d2=gd();if(!d2.messages)d2.messages={};d2.messages[chatKey]=[...(d2.messages[chatKey]||[]),{from:"faculty",text:rep,time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"})}];sd(d2);R();}catch{}setCL(false);
  };
  const sendGrp=async(txt,file=null)=>{
    if(!txt.trim()&&!file)return;
    const msg={sender:user.name,avatar:user.avatar,role:"student",text:txt,time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),file};
    const d=gd();d.groupMsgs[activeGrp]=[...(d.groupMsgs[activeGrp]||[]),msg];sd(d);R();setGT("");
    if(!txt.trim())return;setGL(true);
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:600,system:"You are a classmate in the "+activeGrp+" branch at GEC Arsikere. Reply casually as a student in 1-2 sentences.",messages:[{role:"user",content:txt}]})});const r=await res.json();const rep=r.content?.[0]?.text||"👍";const peer=(data.students||[]).find(s=>s.branch===activeGrp&&s.id!==user.id);if(peer){const d2=gd();d2.groupMsgs[activeGrp]=[...(d2.groupMsgs[activeGrp]||[]),{sender:peer.name,avatar:peer.avatar,role:"student",text:rep,time:new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"}),file:null}];sd(d2);R();}}catch{}setGL(false);
  };
  const TABS=[["home","🏠 Home"],["attendance","📅 My Attendance"],["subjects","📚 Subjects"],["assignments","📝 Assignments"],["announcements","📢 Notices"],["media","🎉 Events"],["faculty","👩‍🏫 Faculty"],["chat","💬 Messages"],["group","👥 Class Group"],["profile","👤 Profile"]];
  return(
    <div style={{minHeight:"100vh",display:"flex",fontFamily:"'Segoe UI',Georgia,sans-serif",background:T.cream}}>
      <Sidebar tabs={TABS} active={tab} onSelect={setTab} user={user} onLogout={onLogout} role="student"/>
      <div style={{flex:1,padding:"22px 26px",overflowY:"auto"}}>
        {tab==="home"&&<>
          <div style={{borderRadius:18,padding:"22px 26px",background:"linear-gradient(135deg,"+bc.bg+","+T.navy+")",color:T.white,marginBottom:20,position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:-30,right:-30,width:140,height:140,borderRadius:"50%",background:bc.accent+"15"}}/>
            <p style={{margin:"0 0 4px",opacity:.55,fontSize:12,letterSpacing:1,textTransform:"uppercase"}}>{new Date().toDateString()}</p>
            <h1 style={{margin:"0 0 6px",fontSize:21,fontWeight:900,fontFamily:"Georgia,serif"}}>Hello, {user.name.split(" ")[0]}! 👋</h1>
            <p style={{margin:"0 0 12px",opacity:.7,fontSize:13}}>{user.usn} · {user.branch} · Sem {user.sem} · Section {user.section}</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><Badge text={user.branch} type="info"/>{overallAtt!==null&&<Badge text={overallAtt+"% Attendance"} type={overallAtt>=75?"success":"danger"}/>}</div>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:20}}>
            <Card style={{borderTop:"3px solid "+bc.accent,textAlign:"center"}}><p style={{margin:"0 0 2px",color:T.muted,fontSize:11,fontWeight:600}}>Attendance</p><p style={{margin:0,fontSize:22,fontWeight:900,color:overallAtt===null?T.muted:overallAtt>=75?T.success:T.danger}}>{overallAtt===null?"—":overallAtt+"%"}</p></Card>
            <Card style={{borderTop:"3px solid "+T.gold,textAlign:"center"}}><p style={{margin:"0 0 2px",color:T.muted,fontSize:11,fontWeight:600}}>Subjects</p><p style={{margin:0,fontSize:22,fontWeight:900,color:T.gold}}>{subs.length}</p></Card>
            <Card style={{borderTop:"3px solid "+T.teal,textAlign:"center"}}><p style={{margin:"0 0 2px",color:T.muted,fontSize:11,fontWeight:600}}>Notices</p><p style={{margin:0,fontSize:22,fontWeight:900,color:T.teal}}>{anns.length}</p></Card>
            <Card style={{borderTop:"3px solid "+T.info,textAlign:"center"}}><p style={{margin:"0 0 2px",color:T.muted,fontSize:11,fontWeight:600}}>Assignments</p><p style={{margin:0,fontSize:22,fontWeight:900,color:T.info}}>{(data.assignments||[]).filter(a=>a.branch===user.branch).length}</p></Card>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:18,marginBottom:18}}>
            <Card><h3 style={{margin:"0 0 12px",fontSize:14,fontWeight:800,color:T.navy}}>📢 Latest Notices</h3>{anns.slice(0,3).map(a=><div key={a.id} style={{padding:"9px 12px",borderRadius:10,background:a.pinned?T.gold+"0d":T.cream,border:"1px solid "+(a.pinned?T.gold+"44":T.border),marginBottom:7}}>{a.pinned&&<Badge text="📌 Pinned" type="gold"/>}<p style={{margin:a.pinned?"5px 0 2px":"0 0 2px",fontSize:13,fontWeight:700,color:T.text}}>{a.title}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{a.author} · {a.date}</p></div>)}{!anns.length&&<p style={{color:T.muted,fontSize:13}}>No announcements yet.</p>}</Card>
            <Card><h3 style={{margin:"0 0 12px",fontSize:14,fontWeight:800,color:T.navy}}>📅 Attendance Snapshot</h3>{attData.slice(0,5).map((a,i)=><div key={i} style={{display:"flex",alignItems:"center",gap:8,marginBottom:7}}><span style={{flex:1,fontSize:12,color:T.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{a.sub}</span>{a.pct===null?<span style={{fontSize:11,color:T.muted}}>—</span>:<><div style={{width:70,height:6,borderRadius:3,background:T.border}}><div style={{width:a.pct+"%",height:"100%",background:a.pct>=75?T.success:T.danger,borderRadius:3}}/></div><span style={{fontSize:11,fontWeight:800,color:a.pct>=75?T.success:T.danger,minWidth:34}}>{a.pct}%</span></>}</div>)}{!validAtt.length&&<p style={{color:T.muted,fontSize:12}}>No attendance data yet.</p>}</Card>
          </div>
          <Card><h3 style={{margin:"0 0 12px",fontSize:14,fontWeight:800,color:T.navy}}>🎉 College Events</h3><MediaGallery media={(data.media||[]).slice(0,6)}/></Card>
        </>}
        {tab==="attendance"&&<>
          <ST sub="Your subject-wise attendance — updated live by faculty">My Attendance</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14,marginBottom:20}}>
            <Card style={{textAlign:"center",borderTop:"3px solid "+(overallAtt===null?T.muted:overallAtt>=75?T.success:T.danger)}}><p style={{fontSize:28,margin:"0 0 4px"}}>{overallAtt===null?"📅":overallAtt>=75?"✅":"⚠️"}</p><p style={{margin:0,fontSize:28,fontWeight:900,color:overallAtt===null?T.muted:overallAtt>=75?T.success:T.danger}}>{overallAtt===null?"—":overallAtt+"%"}</p><p style={{margin:"3px 0 0",fontSize:12,color:T.muted,fontWeight:600}}>Overall Attendance</p>{overallAtt!==null&&<p style={{margin:"3px 0 0",fontSize:11,color:overallAtt>=75?T.success:T.danger,fontWeight:700}}>{overallAtt>=75?"Good Standing ✓":"Below Minimum ⚠️"}</p>}</Card>
            <Card style={{textAlign:"center",borderTop:"3px solid "+T.warn}}><p style={{fontSize:28,margin:"0 0 4px"}}>📏</p><p style={{margin:0,fontSize:28,fontWeight:900,color:T.warn}}>75%</p><p style={{margin:"3px 0 0",fontSize:12,color:T.muted,fontWeight:600}}>VTU Minimum</p><p style={{margin:"3px 0 0",fontSize:11,color:T.muted}}>Below this = exam bar</p></Card>
            <Card style={{textAlign:"center",borderTop:"3px solid "+T.info}}><p style={{fontSize:28,margin:"0 0 4px"}}>📚</p><p style={{margin:0,fontSize:28,fontWeight:900,color:T.info}}>{validAtt.length}/{subs.length}</p><p style={{margin:"3px 0 0",fontSize:12,color:T.muted,fontWeight:600}}>Subjects Tracked</p></Card>
          </div>
          <Card>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}><h3 style={{margin:0,fontSize:14,fontWeight:800,color:T.navy}}>📊 Subject-wise Breakdown</h3>{validAtt.length>0&&<Badge text={attData.filter(a=>a.pct!==null&&a.pct<75).length+" below 75%"} type={attData.filter(a=>a.pct!==null&&a.pct<75).length>0?"danger":"success"}/>}</div>
            {attData.map((a,i)=>{
              const need=a.pct!==null&&a.pct<75&&a.total>0?Math.ceil((0.75*a.total-a.present)/(1-0.75)):null;
              const canMiss=a.pct!==null&&a.pct>=75&&a.total>0?Math.floor(a.present-0.75*a.total):null;
              return<div key={i} style={{padding:"12px 0",borderBottom:i<attData.length-1?"1px solid "+T.border:"none"}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:a.pct!==null?8:0}}>
                  <span style={{width:24,height:24,borderRadius:"50%",background:(a.pct===null?T.muted:a.pct>=75?T.success:T.danger)+"20",color:a.pct===null?T.muted:a.pct>=75?T.success:T.danger,fontSize:11,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{i+1}</span>
                  <span style={{flex:1,fontSize:13,fontWeight:700,color:T.text}}>{a.sub}</span>
                  {a.pct===null?<span style={{fontSize:12,color:T.muted,fontStyle:"italic",background:T.cream,padding:"2px 10px",borderRadius:20}}>Not marked yet</span>:<>
                    <span style={{fontSize:11,color:T.muted}}>{a.present}/{a.total} classes</span>
                    <span style={{fontSize:14,fontWeight:900,color:a.pct>=75?T.success:T.danger,minWidth:48,textAlign:"right"}}>{a.pct}%</span>
                    <span style={{fontSize:14}}>{a.pct>=75?"✅":"⚠️"}</span>
                  </>}
                </div>
                {a.pct!==null&&<div style={{marginLeft:34}}>
                  <div style={{height:10,borderRadius:5,background:T.border,overflow:"hidden",marginBottom:5}}><div style={{width:Math.min(a.pct,100)+"%",height:"100%",borderRadius:5,background:a.pct>=75?"linear-gradient(90deg,"+T.success+","+T.teal+")":a.pct>=60?"linear-gradient(90deg,"+T.warn+","+T.gold+")":"linear-gradient(90deg,"+T.danger+",#f87171)",transition:"width .6s ease"}}/></div>
                  <div style={{display:"flex",justifyContent:"space-between"}}><span style={{fontSize:11,color:a.pct>=75?T.success:T.danger,fontWeight:600}}>{a.pct>=75?"On track ✓":"Needs improvement"}</span>{need!==null&&<span style={{fontSize:11,color:T.danger,fontWeight:700,background:T.danger+"12",padding:"2px 8px",borderRadius:10}}>Attend {need} more to reach 75%</span>}{canMiss!==null&&canMiss>=0&&<span style={{fontSize:11,color:T.success}}>Can miss {canMiss} more class{canMiss!==1?"es":""}</span>}</div>
                </div>}
              </div>;
            })}
            {!validAtt.length&&<div style={{textAlign:"center",padding:"28px 0"}}><p style={{fontSize:34,margin:"0 0 8px"}}>📅</p><p style={{fontSize:14,fontWeight:700,color:T.navy,margin:"0 0 4px"}}>No attendance data yet</p><p style={{fontSize:13,color:T.muted,margin:0}}>Faculty will mark attendance after each class.</p></div>}
          </Card>
        </>}
        {tab==="subjects"&&<>
          <ST sub={subs.length+" subjects · Sem "+user.sem+" · "+SY[user.sem]+" · "+user.branch}>Subjects</ST>
          <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14}}>
            {subs.map((s,i)=>{const at=attData.find(a=>a.sub===s);return<Card key={i} style={{borderLeft:"4px solid "+bc.accent}}>
              <div style={{display:"flex",gap:12,alignItems:"flex-start"}}>
                <div style={{width:36,height:36,borderRadius:10,background:bc.accent+"20",display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,flexShrink:0}}>📘</div>
                <div style={{flex:1}}><p style={{margin:"0 0 4px",fontWeight:700,fontSize:14,color:T.text}}>{s}</p><div style={{display:"flex",gap:6}}><Badge text={user.branch} type="info"/><Badge text={"Sem "+user.sem} type="neutral"/></div>
                  {at&&at.pct!==null&&<div style={{display:"flex",alignItems:"center",gap:8,marginTop:8}}><div style={{flex:1,height:6,borderRadius:3,background:T.border}}><div style={{width:at.pct+"%",height:"100%",background:at.pct>=75?T.success:T.danger,borderRadius:3}}/></div><span style={{fontSize:12,fontWeight:700,color:at.pct>=75?T.success:T.danger}}>{at.pct}%</span></div>}
                </div>
              </div>
            </Card>;})}
          </div>
        </>}
        {tab==="assignments"&&<>
          <ST sub="Assignments from faculty">Assignments</ST>
          {!(data.assignments||[]).filter(a=>a.branch===user.branch).length?<Card style={{textAlign:"center",padding:48}}><p style={{fontSize:36,margin:"0 0 8px"}}>📋</p><p style={{color:T.muted}}>No assignments posted yet.</p></Card>
          :(data.assignments||[]).filter(a=>a.branch===user.branch).map(a=><Card key={a.id} style={{marginBottom:12}}>
            <p style={{margin:"0 0 6px",fontWeight:800,fontSize:14,color:T.text}}>{a.title}</p>
            <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:6}}>{a.subject&&<Badge text={a.subject} type="info"/>}<Badge text={a.branch+" · Sem "+a.sem} type="neutral"/><Badge text={"Due: "+a.dueDate} type="warning"/></div>
            {a.description&&<p style={{margin:"0 0 6px",fontSize:13,color:T.text}}>{a.description}</p>}
            <p style={{margin:0,fontSize:12,color:T.muted}}>By {a.postedBy} · {a.postedOn}</p>
          </Card>)}
        </>}
        {tab==="announcements"&&<>
          <ST sub="Official notices from GEC Arsikere">Announcements</ST>
          {!anns.length?<Card style={{textAlign:"center",padding:48}}><p style={{fontSize:34,margin:"0 0 8px"}}>📢</p><p style={{color:T.muted}}>No announcements yet.</p></Card>
          :anns.map(a=><Card key={a.id} style={{marginBottom:12,borderLeft:a.pinned?"4px solid "+T.gold:"1px solid "+T.border}}>
            <div style={{display:"flex",gap:6,marginBottom:6,flexWrap:"wrap"}}><Badge text={a.type} type={a.type==="exam"?"warning":a.type==="event"?"info":"neutral"}/>{a.pinned&&<Badge text="📌 Pinned" type="gold"/>}</div>
            <h3 style={{margin:"0 0 6px",fontSize:14,fontWeight:800,color:T.text}}>{a.title}</h3>
            <p style={{margin:"0 0 6px",fontSize:13,color:T.text,lineHeight:1.5}}>{a.body}</p>
            <p style={{margin:0,fontSize:12,color:T.muted}}>{a.author} · {a.date}</p>
          </Card>)}
        </>}
        {tab==="media"&&<><ST sub="Photos and videos from college events">College Events Gallery</ST><MediaGallery media={data.media||[]}/></>}
        {tab==="faculty"&&<>
          <ST sub={user.branch+" Department — "+fac.length+" faculty"}>Faculty</ST>
          {!fac.length?<Card style={{textAlign:"center",padding:48}}><p style={{fontSize:36}}>👩‍🏫</p><p style={{color:T.muted}}>No faculty registered for {user.branch} yet.</p></Card>
          :<div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:14}}>
            {fac.map(f=><Card key={f.id}><div style={{display:"flex",gap:12,alignItems:"flex-start"}}><Av initials={f.avatar} size={48} color={T.teal}/><div style={{flex:1}}><p style={{margin:"0 0 2px",fontWeight:800,fontSize:14,color:T.text}}>{f.name}</p><p style={{margin:"0 0 2px",fontSize:12,color:T.muted}}>{f.designation}{f.qualification?" · "+f.qualification:""}</p><p style={{margin:"0 0 6px",fontSize:12,color:T.info}}>{f.email}</p><p style={{margin:"0 0 10px",fontSize:12,color:T.muted}}>📚 {f.subjects}</p><Btn onClick={()=>{setCT(f);setTab("chat");}} variant="teal" style={{fontSize:12,padding:"7px 14px"}}>💬 Message</Btn></div></div></Card>)}
          </div>}
        </>}
        {tab==="chat"&&<div style={{display:"grid",gridTemplateColumns:"220px 1fr",gap:0,height:560,borderRadius:16,overflow:"hidden",border:"1px solid "+T.border}}>
          <div style={{background:T.navy,display:"flex",flexDirection:"column"}}>
            <div style={{padding:"12px",borderBottom:"1px solid rgba(255,255,255,0.08)"}}><p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:11,textTransform:"uppercase",letterSpacing:1}}>Faculty Messages</p></div>
            <div style={{flex:1,overflowY:"auto"}}>
              {!fac.length?<p style={{color:"rgba(255,255,255,0.3)",fontSize:12,padding:12}}>No faculty in {user.branch}</p>
              :fac.map(f=><div key={f.id} onClick={()=>setCT(f)} style={{padding:"10px 12px",display:"flex",gap:8,alignItems:"center",cursor:"pointer",background:chatTarget?.id===f.id?T.teal+"33":"transparent",borderLeft:chatTarget?.id===f.id?"3px solid "+T.teal:"3px solid transparent"}}>
                <Av initials={f.avatar} size={30} color={chatTarget?.id===f.id?T.tealLt:"#94a3b8"}/>
                <div style={{minWidth:0}}><p style={{margin:0,color:T.white,fontSize:12,fontWeight:700,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{f.name}</p><p style={{margin:0,color:"rgba(255,255,255,0.35)",fontSize:10}}>{f.designation||"Faculty"}</p></div>
              </div>)}
            </div>
          </div>
          <div style={{display:"flex",flexDirection:"column",background:T.white}}>
            {chatTarget?<>
              <div style={{padding:"10px 14px",borderBottom:"1px solid "+T.border,display:"flex",gap:10,alignItems:"center"}}><Av initials={chatTarget.avatar} size={34} color={T.teal}/><div><p style={{margin:0,fontWeight:700,fontSize:13,color:T.text}}>{chatTarget.name}</p><p style={{margin:0,fontSize:12,color:T.success}}>● Available</p></div></div>
              <div style={{flex:1,overflowY:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,background:"#f8fafc"}}>
                {!chatMsgs.length&&<div style={{textAlign:"center",padding:20,color:T.muted}}><p style={{fontSize:26,margin:"0 0 6px"}}>💬</p><p style={{fontSize:13,margin:0}}>Message {chatTarget.name.split(" ").slice(-1)[0]} sir/ma'am</p></div>}
                {chatMsgs.map((m,i)=><div key={i} style={{display:"flex",justifyContent:m.from==="student"?"flex-end":"flex-start",gap:6,alignItems:"flex-end"}}>
                  {m.from==="faculty"&&<Av initials={chatTarget.avatar} size={24} color={T.teal}/>}
                  <div style={{maxWidth:"70%",background:m.from==="student"?bc.accent:T.white,color:m.from==="student"?T.white:T.text,padding:"9px 13px",borderRadius:m.from==="student"?"16px 16px 4px 16px":"16px 16px 16px 4px",fontSize:13,lineHeight:1.5,border:m.from==="student"?"none":"1px solid "+T.border}}>{m.text}<p style={{margin:"3px 0 0",fontSize:10,opacity:.6,textAlign:"right"}}>{m.time}</p></div>
                  {m.from==="student"&&<Av initials={user.avatar} size={24} color={bc.accent}/>}
                </div>)}
                {chatLoad&&<div style={{display:"flex",gap:6,alignItems:"center"}}><Av initials={chatTarget.avatar} size={24} color={T.teal}/><span style={{color:T.muted,fontSize:12}}>typing...</span></div>}
                <div ref={chatBR}/>
              </div>
              <div style={{padding:"10px 12px",borderTop:"1px solid "+T.border,display:"flex",gap:8}}>
                <input value={chatText} onChange={e=>setCTxt(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendChat()} placeholder={"Message "+chatTarget.name.split(" ").slice(-1)[0]+" sir/ma'am..."} style={{flex:1,padding:"9px 14px",borderRadius:24,border:"1px solid "+T.border,fontSize:13,fontFamily:"inherit",outline:"none"}}/>
                <button onClick={sendChat} disabled={chatLoad} style={{padding:"9px 18px",borderRadius:24,background:T.teal,color:T.white,border:"none",cursor:"pointer",fontSize:13,fontWeight:700}}>Send</button>
              </div>
            </>:<div style={{display:"flex",flex:1,alignItems:"center",justifyContent:"center",flexDirection:"column",gap:8,color:T.muted}}><p style={{fontSize:36,margin:0}}>💬</p><p style={{fontSize:13,margin:0}}>Select a faculty to start chatting</p></div>}
          </div>
        </div>}
        {tab==="group"&&<div style={{display:"grid",gridTemplateColumns:"190px 1fr",gap:0,height:580,borderRadius:16,overflow:"hidden",border:"1px solid "+T.border}}>
          <div style={{background:"#0f172a",display:"flex",flexDirection:"column"}}>
            <div style={{padding:"12px",borderBottom:"1px solid rgba(255,255,255,0.08)"}}><p style={{margin:0,color:"rgba(255,255,255,0.4)",fontSize:11,textTransform:"uppercase",letterSpacing:1}}>Class Groups</p></div>
            {BRANCHES.map(b=><div key={b} onClick={()=>setAG(b)} style={{padding:"10px 12px",cursor:"pointer",background:activeGrp===b?BC[b].accent+"22":"transparent",borderLeft:activeGrp===b?"3px solid "+BC[b].accent:"3px solid transparent"}}>
              <p style={{margin:0,color:T.white,fontWeight:700,fontSize:12}}>🏫 {b}</p>
              <p style={{margin:0,color:"rgba(255,255,255,0.35)",fontSize:10}}>{(data.students||[]).filter(s=>s.branch===b).length} students</p>
            </div>)}
          </div>
          <div style={{display:"flex",flexDirection:"column",background:T.white}}>
            <div style={{padding:"10px 14px",borderBottom:"1px solid "+T.border}}><p style={{margin:0,fontWeight:800,fontSize:13,color:T.text}}>🏫 {activeGrp} Group</p><p style={{margin:0,fontSize:11,color:T.muted}}>Share notes, PDFs, messages</p></div>
            <div style={{flex:1,overflow:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:10,background:"#f8fafc"}}>
              {!grpMsgs.length&&<div style={{textAlign:"center",padding:36,color:T.muted}}><p style={{fontSize:28,margin:"0 0 6px"}}>👥</p><p style={{fontSize:13,margin:0}}>No messages yet — say something!</p></div>}
              {grpMsgs.map((m,i)=><div key={i} style={{display:"flex",gap:10,alignItems:"flex-start"}}>
                <Av initials={m.avatar} size={30} color={m.role==="faculty"?T.teal:BC[activeGrp]?.accent||T.gold}/>
                <div style={{flex:1}}>
                  <div style={{display:"flex",gap:6,alignItems:"center",marginBottom:3,flexWrap:"wrap"}}><span style={{fontSize:13,fontWeight:700,color:T.text}}>{m.sender}</span><Badge text={m.role} type={m.role==="faculty"?"info":"neutral"}/><span style={{fontSize:10,color:T.muted}}>{m.time}</span></div>
                  {m.text&&<p style={{margin:"0 0 5px",fontSize:13,color:T.text,lineHeight:1.5,background:T.white,padding:"8px 12px",borderRadius:10,border:"1px solid "+T.border,display:"inline-block"}}>{m.text}</p>}
                  {m.file&&<div style={{display:"inline-flex",alignItems:"center",gap:8,padding:"7px 12px",borderRadius:10,background:T.info+"12",border:"1px solid "+T.info+"33"}}><span>📄</span><div><p style={{margin:0,fontSize:13,fontWeight:700,color:T.info}}>{m.file.name}</p><p style={{margin:0,fontSize:11,color:T.muted}}>{m.file.size}</p></div><button style={{padding:"4px 10px",borderRadius:6,background:T.info,color:T.white,border:"none",cursor:"pointer",fontSize:11,fontWeight:700}}>↓</button></div>}
                </div>
              </div>)}
              {grpLoad&&<p style={{color:T.muted,fontSize:13,marginLeft:40}}>A classmate is typing...</p>}
              <div ref={grpBR}/>
            </div>
            <div style={{padding:"10px 12px",borderTop:"1px solid "+T.border,display:"flex",gap:8,alignItems:"center"}}>
              <input ref={fileRef} type="file" style={{display:"none"}} onChange={e=>{const f=e.target.files[0];if(f)sendGrp("",{name:f.name,size:(f.size/1024/1024).toFixed(1)+" MB"});}}/>
              <button onClick={()=>fileRef.current.click()} style={{padding:"9px 12px",borderRadius:10,border:"1px solid "+T.border,background:T.cream,cursor:"pointer",fontSize:16}}>📎</button>
              <input value={grpText} onChange={e=>setGT(e.target.value)} onKeyDown={e=>e.key==="Enter"&&sendGrp(grpText)} placeholder={"Message "+activeGrp+" group..."} style={{flex:1,padding:"9px 14px",borderRadius:24,border:"1px solid "+T.border,fontSize:13,fontFamily:"inherit",outline:"none"}}/>
              <button onClick={()=>sendGrp(grpText)} disabled={grpLoad} style={{padding:"9px 16px",borderRadius:24,background:BC[activeGrp]?.accent||T.gold,color:T.white,border:"none",cursor:"pointer",fontSize:13,fontWeight:700}}>Send</button>
            </div>
          </div>
        </div>}
        {tab==="profile"&&<div style={{maxWidth:620}}>
          <ST>My Profile</ST>
          <Card>
            <div style={{display:"flex",gap:18,alignItems:"center",marginBottom:20,paddingBottom:16,borderBottom:"1px solid "+T.border}}>
              <Av initials={user.avatar} size={64} color={bc.accent}/>
              <div>
                <h2 style={{margin:"0 0 4px",fontSize:20,fontWeight:900,color:T.navy,fontFamily:"Georgia,serif"}}>{user.name}</h2>
                <p style={{margin:"0 0 8px",color:T.muted,fontSize:14}}>{user.usn}</p>
                <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><Badge text={user.branch} type="info"/><Badge text={"Sem "+user.sem+" — "+SY[user.sem]} type="neutral"/><Badge text={"Section "+user.section} type="neutral"/><Badge text="✓ Approved" type="success"/></div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              {[["📧 Email",user.email],["📱 Phone",user.phone],["🎂 Date of Birth",user.dob],["📍 Address",user.address],["👨 Father's Name",user.fatherName],["👩 Mother's Name",user.motherName],["📅 Registered",user.joinedOn]].map(([k,v])=>v?<div key={k} style={{padding:"10px 12px",borderRadius:10,background:T.cream,border:"1px solid "+T.border}}><p style={{margin:"0 0 2px",fontSize:11,color:T.muted,fontWeight:700,textTransform:"uppercase"}}>{k}</p><p style={{margin:0,fontSize:13,fontWeight:600,color:T.text}}>{v}</p></div>:null)}
            </div>
          </Card>
        </div>}
      </div>
    </div>
  );
}

export default function App(){
  const [user,setUser]=useState(null);
  const [ready,setReady]=useState(false);

  useEffect(()=>{
    // Load from Claude artifact storage on mount
    async function load(){
      try{
        if(window.storage){
          const result=await window.storage.get("gec_main");
          if(result&&result.value){
            const parsed=JSON.parse(result.value);
            window.__gecData=parsed;
            try{localStorage.setItem("gec_arsikere_v9",result.value);}catch(e){}
          }
        }
      }catch(e){}
      // Also try localStorage fallback
      try{
        if(!window.__gecData){
          const raw=localStorage.getItem("gec_arsikere_v9");
          if(raw)window.__gecData=JSON.parse(raw);
        }
      }catch(e){}
      setReady(true);
    }
    load();
  },[]);

  if(!ready)return(
    <div style={{minHeight:"100vh",background:"linear-gradient(145deg,#0a1628,#112240)",display:"flex",alignItems:"center",justifyContent:"center",flexDirection:"column",gap:16}}>
      <div style={{width:54,height:54,borderRadius:14,background:"linear-gradient(135deg,#c9922a,#f0b84b)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:26}}>🏛️</div>
      <p style={{color:"rgba(255,255,255,0.8)",fontSize:15,fontWeight:700,fontFamily:"Georgia,serif"}}>GEC Arsikere Portal</p>
      <p style={{color:"rgba(255,255,255,0.4)",fontSize:13}}>Loading your data...</p>
      <div style={{width:40,height:4,borderRadius:2,background:"rgba(255,255,255,0.1)",overflow:"hidden"}}>
        <div style={{width:"60%",height:"100%",background:"#c9922a",borderRadius:2,animation:"pulse 1s infinite"}}/>
      </div>
    </div>
  );

  const logout=()=>setUser(null);
  if(!user)return<AuthPage onLogin={setUser}/>;
  if(user.role==="admin")return<AdminPanel user={user} onLogout={logout}/>;
  if(user.role==="faculty")return<FacultyDash user={user} onLogout={logout}/>;
  return<StudentDash user={user} onLogout={logout}/>;
}
